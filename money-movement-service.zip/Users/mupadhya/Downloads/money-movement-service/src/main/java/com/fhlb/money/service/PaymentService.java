package com.fhlb.money.service;

import com.fhlb.money.mapper.PaymentMapper;
import com.fhlb.money.model.dto.Payment;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.PaymentResponse;
import com.fhlb.money.model.entity.PaymentEntity;
import com.fhlb.money.repository.PaymentRepository;
import com.fhlb.money.service.client.CoreBankingFeignClient;
import com.fhlb.money.util.TransactionStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Date;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final CoreBankingFeignClient cbsFeignClient;

    private final PaymentMapper mapper = new PaymentMapper();


    public PaymentResponse fundTransfer(PaymentRequest request) {
        log.info("Sending fund transfer request {}" + request.toString());

        PaymentEntity entity = new PaymentEntity();
        BeanUtils.copyProperties(request, entity);
        entity.setStatus(TransactionStatus.PENDING.name());
        PaymentEntity optFundTransfer = paymentRepository.save(entity);
        //sending txn id
        request.setId(String.valueOf(optFundTransfer.getId()));

        PaymentResponse fundTransferResponse = cbsFeignClient.fundTransfer(request);

        optFundTransfer.setTransactionReference(fundTransferResponse.getTransactionReference());

        optFundTransfer.setStatus(TransactionStatus.SUCCESS.name());
        paymentRepository.save(optFundTransfer);

        fundTransferResponse.setMessage("Fund Transfer Successfully Completed");
        return fundTransferResponse;

    }

    public PaymentResponse transfer(PaymentRequest request) {
        log.info("Sending fund transfer request {}" + request.toString());


        SecureRandom sr = new SecureRandom();
        Date dateMsg = new Date();
        String uuidStr = dateMsg.getTime() + "-" + sr.nextInt(1000000);


        PaymentResponse fundTransferResponse = new PaymentResponse();

        fundTransferResponse.setTransactionId(request.getId());
        fundTransferResponse.setTransactionReference(uuidStr);
        fundTransferResponse.setMessage("Fund Transfer Successfully Completed"+request.getId()+"_"+uuidStr);
        return fundTransferResponse;

    }

    public List<Payment> readAllTransfers(Pageable pageable) {
        return mapper.convertToDtoList(paymentRepository.findAll(pageable)
                .getContent());
    }
}