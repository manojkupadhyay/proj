package com.fhlb.money.delegate;

import com.fhlb.money.exception.ErrorCodes;
import com.fhlb.money.exception.ServiceException;
import com.fhlb.money.model.dto.Payment;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.PaymentResponse;
import com.fhlb.money.service.PaymentService;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.List;


@Component
public class PaymentDelegate {
    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentDelegate.class);
    public static final String SUCCESS_STR = "success";
    public static final String FAILURE_STR = "failure";

    @Autowired
    @Setter
    PaymentService paymentService;


    public PaymentResponse fundTransfer(@Valid PaymentRequest paymentRequest) throws ServiceException {

        String processCode = null;
        PaymentResponse searchResponse = null;
        try {
//                validateRequest
            searchResponse = paymentService.fundTransfer(paymentRequest);
            processCode = SUCCESS_STR;
            return searchResponse;

        } catch (Exception e) {
            processCode = FAILURE_STR;
            throw new ServiceException(ErrorCodes.FAILURE_STR, e);
        } finally {
            //to run audit event processing as background task asynchronously
            // and don't want to return anything from the task
            try {
                // audit the request
            } catch (Exception e) {
                LOGGER.warn("Exception occurred sending audit message: ", e);
            }
        }
    }


    public PaymentResponse transfer(PaymentRequest paymentRequest) throws ServiceException {
        String processCode = null;
        PaymentResponse searchResponse = null;
        try {
            //                validateRequest
            searchResponse = paymentService.transfer(paymentRequest);
            processCode = SUCCESS_STR;
            return searchResponse;
        } catch (Exception e) {
            processCode = FAILURE_STR;
            throw new ServiceException(ErrorCodes.FAILURE_STR, e);
        } finally {
            //to run audit event processing as background task asynchronously
            // and don't want to return anything from the task
            try {
                //  sendAuditMessage(
            } catch (Exception e) {
                LOGGER.warn("Exception occurred sending audit message: ", e);
            }
        }
    }

    public List<Payment> accountDetails(Pageable pageable) {
        //TBD lots cases left for later
        return paymentService.readAllTransfers(pageable);
    }
}