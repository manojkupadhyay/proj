package com.fhlb.money.contoller;

import com.fhlb.money.api.PaymentApiV1;
import com.fhlb.money.delegate.PaymentDelegate;
import com.fhlb.money.exception.ServiceException;
import com.fhlb.money.model.dto.Payment;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.PaymentResponse;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PaymentApiControllerV1<T> implements PaymentApiV1 {

    @Autowired
    @Setter
    private PaymentDelegate paymentDelegate;

    @Override
    public ResponseEntity<PaymentResponse> transfer(
            PaymentRequest paymentRequest) throws ServiceException {
        PaymentResponse response = paymentDelegate.transfer(paymentRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PaymentResponse> moveMoney(
            PaymentRequest paymentRequest) throws ServiceException {
        PaymentResponse response = paymentDelegate.fundTransfer(paymentRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @Override
    public ResponseEntity<List<Payment>> accountDetails(
            Pageable pageable) throws ServiceException {
        List<Payment> response =  paymentDelegate.accountDetails(pageable);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }




}
