package com.fhlb.money.model.dto.response;

import lombok.Data;

@Data
public class PaymentResponse {
    private String message;
    private String transactionId;
    private String transactionReference;
}
