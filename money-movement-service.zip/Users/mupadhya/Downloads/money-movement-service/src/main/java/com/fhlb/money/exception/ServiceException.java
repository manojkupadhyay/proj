package com.fhlb.money.exception;


import java.io.Serializable;

public class ServiceException extends Exception implements Serializable {

    private static final long serialVersionUID = -4927470992670407994L;

    private ErrorCodes errorCode;

    private String errorDescription;

    public ServiceException(Exception e) {
        super(e);
    }

    public ServiceException(ErrorCodes errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.errorDescription = message;
    }

    public ServiceException(ErrorCodes errorCode, Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
    }

    public ServiceException(ErrorCodes errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.errorDescription = message;
    }

    public ServiceException(ErrorCodes errorCode, String message, Throwable cause, boolean enableSuppression,
                            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.errorCode = errorCode;
        this.errorDescription = message;
    }

    public ErrorCodes getErrorCode() {
        return errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }
}
