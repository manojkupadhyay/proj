package com.fhlb.money.model.dto.request;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentRequest {

    private String fromAccount;
    private String toAccount;
    private BigDecimal amount;
    private String authID;
    private String id;
}