package com.fhlb.money.util;

public enum TransactionStatus {
    PENDING, PROCESSING, SUCCESS, FAILED
}

