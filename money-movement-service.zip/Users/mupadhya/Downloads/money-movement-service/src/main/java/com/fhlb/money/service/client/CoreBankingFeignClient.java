package com.fhlb.money.service.client;

import com.fhlb.money.config.FeignClientConfig;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.AccountResponse;
import com.fhlb.money.model.dto.response.PaymentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "core-banking-service", url = "${core-service.url}" ,configuration = FeignClientConfig.class)
public interface CoreBankingFeignClient {

    @RequestMapping(path = "/v1/money/bank-account/{account_number}", method = RequestMethod.GET)
    AccountResponse readAccount(@PathVariable("account_number") String accountNumber);

    @RequestMapping(path = "/v1/money/transfer", method = RequestMethod.POST)
    PaymentResponse fundTransfer(@RequestBody PaymentRequest fundTransferRequest);

}
