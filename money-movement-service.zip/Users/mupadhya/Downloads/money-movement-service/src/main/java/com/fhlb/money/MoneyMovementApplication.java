package com.fhlb.money;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@EnableFeignClients
@EnableCaching
@EnableEurekaClient
@EnableAspectJAutoProxy(proxyTargetClass = true)
@SpringBootApplication
@ComponentScan(basePackages = {"com.fhlb.money"})
public class MoneyMovementApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(MoneyMovementApplication.class);
    public static void main(String[] args)  throws Exception {
        SpringApplication.run(MoneyMovementApplication.class, args);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

}
