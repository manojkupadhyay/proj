package com.fhlb.money.mapper;

import com.fhlb.money.model.dto.Payment;
import com.fhlb.money.model.entity.PaymentEntity;
import org.springframework.beans.BeanUtils;

public class PaymentMapper extends BaseMapper<PaymentEntity, Payment> {
    @Override
    public PaymentEntity convertToEntity(Payment dto, Object... args) {
        PaymentEntity entity = new PaymentEntity();
        if (dto != null) {
            BeanUtils.copyProperties(dto, entity);
        }
        return entity;
    }

    @Override
    public Payment convertToDto(PaymentEntity entity, Object... args) {
        Payment dto = new Payment();
        if (entity != null) {
            BeanUtils.copyProperties(entity, dto);
        }
        return dto;
    }
}
