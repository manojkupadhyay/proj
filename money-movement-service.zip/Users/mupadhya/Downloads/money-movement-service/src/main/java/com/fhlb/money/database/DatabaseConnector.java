package com.fhlb.money.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 * Connection for database
 */
@Configuration
public class DatabaseConnector {

    @Autowired
    private Environment environment;
    /**
     * Get db connection (application.properties)
     * @return Connection
     * @throws SQLException
     */
    public  Connection getConnection() throws SQLException {
        try {
            Class.forName( environment.getProperty("spring_datasource_driver-class-name"));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return DriverManager.getConnection(environment.getProperty("spring_datasource_url"),
                environment.getProperty("spring_datasource_username"), environment.getProperty("spring_datasource_password"));
    }

    /**
     * Rollback transaction
     * @param conn connection
     */
    public  boolean rollbackTransaction(Connection conn) {
        try {
            if (conn != null) {
                conn.rollback();
                return true;
            }
        } catch (SQLException re) {
            throw new RuntimeException("Rollback failed!", re);
        }
        return false;
    }
}
