package com.fhlb.money.exception;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ErrorCodes {
    // Bad Request codes
    DUPLICATE_ENTITY("Duplicate.Entity"),
    SUCCESS_STR("Successful"),
    FAILURE_STR("Failed"),
    DUPLICATE_NAME("Duplicate.Name"),
    // Service
    UNEXPECTED_ERROR("UnexpectedError"),
    //validation Error
    DATA_FORMAT_ERROR("DataFormatError"),
    //validation null Error
    VALIDATION_ERROR("ValidationError");
    //validation null Error


    private final String value;

    ErrorCodes(String value) {
        this.value = value;
    }

    @JsonCreator
    public static ErrorCodes fromValue(String text) {
        for (ErrorCodes errorCodeEnum : values()) {
            if (String.valueOf(errorCodeEnum.value)
                    .equals(text)) {
                return errorCodeEnum;
            }
        }
        return null;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }
}