package com.fhlb.money.api;

import com.fhlb.money.exception.ServiceException;
import com.fhlb.money.model.dto.Payment;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.PaymentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;

import static org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE;

@Tag(name = "MoveMoney", description = "MoveMoneyApi")
@RequestMapping(value = {"/v1/money"})
public interface PaymentApiV1 {
    @Operation(
            summary = "Move money API",
            description = "move money",
            tags = {"move money"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "message", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PaymentResponse.class)))}),
            @ApiResponse(responseCode = "400", description = "Request failed due to unknown or invalid details"),
            @ApiResponse(responseCode = "401", description = "Unauthorized to retrievedata"),
            @ApiResponse(responseCode = "403", description = "The user does not have permission to retrieve data")})
    @PostMapping(value = "/payment", produces = MediaType.APPLICATION_JSON_VALUE)
   default ResponseEntity<PaymentResponse> moveMoney(
            @Parameter(description = "A request to move money")
            @Valid @RequestBody PaymentRequest paymentRequest) throws ServiceException{
        return new ResponseEntity<>(SERVICE_UNAVAILABLE);
    }

    @Operation(
            summary = "Transfer API",
            description = "call to core banking API",
            tags = {"transfer money"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "message", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PaymentResponse.class)))}),
            @ApiResponse(responseCode = "400", description = "Request failed due to unknown or invalid details"),
            @ApiResponse(responseCode = "401", description = "Unauthorized to retrievedata"),
            @ApiResponse(responseCode = "403", description = "The user does not have permission to retrieve data")})
    @PostMapping(value = "/transfer", produces = MediaType.APPLICATION_JSON_VALUE)
    default ResponseEntity<PaymentResponse> transfer(
            @Parameter(description = "A request to move money")
            @Valid @RequestBody PaymentRequest paymentRequest) throws ServiceException{
        return new ResponseEntity<>(SERVICE_UNAVAILABLE);
    }

    @Operation(
            summary = "Account API",
            description = "Account API",
            tags = {"Account details"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "message", content = {@Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PaymentResponse.class)))}),
            @ApiResponse(responseCode = "400", description = "Request failed due to unknown or invalid details"),
            @ApiResponse(responseCode = "401", description = "Unauthorized to retrieve data"),
            @ApiResponse(responseCode = "403", description = "The user does not have permission to retrieve data")})
    @GetMapping(value = "account/{account_number}/details", produces = MediaType.APPLICATION_JSON_VALUE)
   default ResponseEntity<List<Payment>> accountDetails(
            Pageable pageable) throws ServiceException{
        return new ResponseEntity<>(SERVICE_UNAVAILABLE);
    }

}
