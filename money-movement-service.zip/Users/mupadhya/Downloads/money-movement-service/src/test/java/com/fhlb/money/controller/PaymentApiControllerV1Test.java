package com.fhlb.money.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fhlb.money.contoller.PaymentApiControllerV1;
import com.fhlb.money.delegate.PaymentDelegate;
import com.fhlb.money.model.dto.request.PaymentRequest;
import com.fhlb.money.model.dto.response.PaymentResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ActiveProfiles({"test", "reporting"})
@ContextConfiguration(classes = PaymentApiControllerV1.class)
//@TestPropertySource(locations = {
//        "file:./config/config-test.properties",
//        "classpath:application-test.properties"})
@WebMvcTest
@AutoConfigureWebMvc
@EnableAutoConfiguration
@DirtiesContext
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PaymentApiControllerV1Test {

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private PaymentDelegate paymentDelegate;

    private PaymentApiControllerV1 checkImageApiControllerV2 = new PaymentApiControllerV1();

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    @Qualifier("restTemplate")
    private RestTemplate restTemplate;

    private final static String PAYMENT_RESPONSE = "{\n" +
            "    \"message\": \"Fund Transfer Successfully Completed\",\n" +
            "    \"transactionId\": \"1\",\n" +
            "    \"transactionReference\": \"1681099732471-479393\"\n" +
            "}";
    private final static String PAYMENT_REQUEST = "{\n" +
            "    \"fromAccount\": \"100015003001\",\n" +
            "    \"toAccount\": \"100015003000\",\n" +
            "    \"amount\": 1250.34\n" +
            "}";

    @BeforeEach
    public void before() {
        mockMvc = MockMvcBuilders
                .standaloneSetup(checkImageApiControllerV2, paymentDelegate)
                .build();

    }

    @Test
    public void test_successful_transfer() throws Exception {
        checkImageApiControllerV2.setPaymentDelegate(paymentDelegate);
        PaymentResponse paymentResponse = objectMapper.readValue(PAYMENT_RESPONSE,PaymentResponse.class);

        when(paymentDelegate.fundTransfer(any(PaymentRequest.class))).thenReturn(paymentResponse);

        MvcResult mvcResult = mockMvc.perform(post("/v1/money/payment")
                        .contentType("application/json")
                        .content(PAYMENT_REQUEST))
                .andExpect(status().isOk())
                .andReturn();

        String actualResponse = mvcResult.getResponse()
                .getContentAsString();
        PaymentResponse actualResponseObj = objectMapper.readValue(actualResponse, PaymentResponse.class);
        assertEquals(paymentResponse, actualResponseObj);

    }



}
