# System Design & Architecture Specification

## Distributed Dynamic Database Scheduler & Object Storage Service

---

## 1. Executive Summary

This document details the system design, architecture, component interaction, distributed concurrency controls, execution lifecycles, and REST interfaces for the **Distributed Dynamic Database Scheduler and Object Storage System**. 

The system enables users and external services to dynamically configure, trigger, pause, resume, backfill, and monitor recurring batch reporting tasks with Quartz, MyBatis, Oracle/H2, and AWS S3/MinIO.

---

## 2. High-Level System Architecture

The architecture is partitioned into clean abstraction tiers:
- **Client & Ingestion Layer**: Web dashboards, microservices, and automated Quartz cron timers.
- **REST Controller Layer**: Spring MVC controllers exposing management, execution history, metrics, and file upload/download endpoints.
- **Quartz Orchestration Layer**: Dynamic in-memory / clustered Quartz scheduler managed by `QuartzSchedulerService` with Spring dependency injection via `AutowiringSpringBeanJobFactory`.
- **Distributed Concurrency & Execution**: `DynamicDatabaseJob` managing optimistic/pessimistic lease locks, stale crash recovery, debounce timing, and a 5-step lifecycle.
- **Pluggable Task Handler Subsystem**: SPI registry (`JobTaskHandlerRegistry`) dispatching tasks to specialized workers (`ReportJobHandler`, `HttpWebhookJobHandler`, `CustomBeanJobHandler`).
- **Storage Layer**: Direct and multipart streaming S3 integration via AWS SDK v2 `S3Client`.
- **Relational Persistence Layer**: MyBatis mappers targeting Oracle and H2 databases with optimized composite indexes.

```mermaid
flowchart TB
    subgraph Clients["Clients & External Triggers"]
        WebUI["Web UI / Admin Portal"]
        APIClient["API Consumers / Microservices"]
        CronClock["Quartz Timer Engine"]
    end

    subgraph APILayer["REST Controller Layer"]
        ScheduleCtrl["JobScheduleController<br/>(/api/schedules)"]
        FileCtrl["FileController<br/>(/api/files)"]
    end

    subgraph ServiceLayer["Quartz Orchestration & Synchronization"]
        QuartzSvc["QuartzSchedulerService"]
        StartupRunner["SchedulerStartupRunner<br/>(ApplicationReady Sync)"]
        QuartzEngine["Quartz Scheduler Engine<br/>(In-Memory / Clustered)"]
        JobFactory["AutowiringSpringBeanJobFactory"]
    end

    subgraph ExecutionLayer["Dynamic Job Execution & Concurrency"]
        JobExecutor["DynamicDatabaseJob"]
        LockManager["Distributed DB Lock Manager<br/>(claimLock / releaseLock / breakLease)"]
        StaleRecovery["Stale Crash Log Recovery<br/>(markStaleExecutionsAsFailed)"]
    end

    subgraph HandlerRegistryLayer["Pluggable Task Handler Subsystem"]
        Registry["JobTaskHandlerRegistry"]
        ReportHandler["ReportJobHandler<br/>(FINANCIAL, AUDIT, METRICS)"]
        HttpHandler["HttpWebhookJobHandler<br/>(HTTP POST Webhook)"]
        CustomHandler["CustomBeanJobHandler<br/>(Spring Bean Reflection)"]
        Dispatcher["JobRequestDispatcher<br/>(Name sanitize, format, S3 Key)"]
    end

    subgraph StorageLayer["Object Storage Layer"]
        S3Client["AWS SDK S3Client / S3Service"]
        S3Bucket[("Amazon S3 / MinIO<br/>Target Bucket")]
    end

    subgraph DBLayer["Relational Database & MyBatis Layer (Oracle / H2)"]
        direction TB
        DetailTbl[("REPORT_SCHEDULE_DETAIL<br/>- schedule_id (PK)<br/>- cron_expression<br/>- status (ACTIVE/PAUSED)<br/>- is_locked, lock_expire_at")]
        RequestTbl[("REPORT_SCHEDULE_REQUEST<br/>- request_id (PK)<br/>- report_name, report_type<br/>- processing_status<br/>- file_status")]
        LogTbl[("SCHEDULE_REPORT_EXECUTION_LOG<br/>- execution_id (PK)<br/>- status, file_status<br/>- s3_bucket, s3_object_key<br/>- start_time, end_time<br/>- error_message")]
    end

    %% Connections
    WebUI --> ScheduleCtrl
    APIClient --> ScheduleCtrl
    WebUI --> FileCtrl

    ScheduleCtrl --> QuartzSvc
    ScheduleCtrl --> DetailTbl
    ScheduleCtrl --> LogTbl
    FileCtrl --> S3Client

    StartupRunner --> QuartzSvc
    QuartzSvc --> QuartzEngine
    QuartzSvc --> DetailTbl
    QuartzSvc --> RequestTbl

    CronClock -.->|Triggers Cron| QuartzEngine
    QuartzEngine --> JobFactory
    JobFactory --> JobExecutor

    JobExecutor --> LockManager
    JobExecutor --> StaleRecovery
    LockManager <--> DetailTbl
    StaleRecovery --> LogTbl

    JobExecutor --> Registry
    Registry --> ReportHandler
    Registry --> HttpHandler
    Registry --> CustomHandler

    ReportHandler --> Dispatcher
    Dispatcher --> S3Client
    S3Client --> S3Bucket

    JobExecutor --> RequestTbl
    JobExecutor --> LogTbl
```

---

## 3. Database Schema & Data Models

### 3.1 Entity Relationship Diagram

```mermaid
erDiagram
    REPORT_SCHEDULE_DETAIL ||--|| REPORT_SCHEDULE_REQUEST : "defines"
    REPORT_SCHEDULE_DETAIL ||--o{ SCHEDULE_REPORT_EXECUTION_LOG : "generates history"

    REPORT_SCHEDULE_DETAIL {
        BIGINT schedule_id PK
        VARCHAR2 user_id
        VARCHAR2 cron_expression
        VARCHAR2 status
        VARCHAR2 is_locked
        TIMESTAMP lock_time
        TIMESTAMP lock_expire_at
        VARCHAR2 locked_by
        TIMESTAMP last_updated_ts
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    REPORT_SCHEDULE_REQUEST {
        BIGINT request_id PK
        BIGINT schedule_id FK
        VARCHAR2 report_name
        VARCHAR2 report_type
        VARCHAR2 output_format
        VARCHAR2 rpt_criteria_payload
        VARCHAR2 processing_status
        VARCHAR2 file_status
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    SCHEDULE_REPORT_EXECUTION_LOG {
        BIGINT execution_id PK
        BIGINT schedule_id FK
        VARCHAR2 report_id
        TIMESTAMP start_time
        TIMESTAMP end_time
        VARCHAR2 status
        VARCHAR2 file_status
        VARCHAR2 generated_report_id
        BIGINT record_count
        VARCHAR2 storage_provider
        VARCHAR2 s3_bucket
        VARCHAR2 s3_object_key
        VARCHAR2 file_name
        VARCHAR2 file_format
        BIGINT file_size_bytes
        VARCHAR2 report_type
        VARCHAR2 user_id
        NUMBER retry_count
        VARCHAR2 error_message
        TIMESTAMP create_at
        TIMESTAMP updated_at
    }
```

### 3.2 Performance Indexes
To guarantee high-throughput queries under concurrent execution, the following database indexes are applied:
* `IDX_EXEC_LOG_SCHED`: `(SCHEDULE_ID, START_TIME DESC)` — Optimizes history log queries for individual schedules.
* `IDX_EXEC_LOG_STATUS`: `(STATUS)` — Optimizes dashboard aggregate counting for system health metrics.
* `IDX_EXEC_LOG_FILE_STATUS`: `(FILE_STATUS)` — Accelerates file status filtering.
* `IDX_EXEC_LOG_START`: `(START_TIME DESC)` — Accelerates chronological backfill and audit scans.

---

## 4. Execution State Machine & 5-Step Lifecycle

Each scheduled or on-demand execution progresses through discrete, synchronized states across `REPORT_SCHEDULE_REQUEST` and `SCHEDULE_REPORT_EXECUTION_LOG`:

```mermaid
stateDiagram-v2
    [*] --> TRIGGERED: 1. Job Triggers & Acquires Lock
    note right of TRIGGERED
      Execution Log: TRIGGERED
      File Status: PENDING
      Request: TRIGGERED / PENDING
    end note

    TRIGGERED --> PROCESSING: 2. Preparing Context & Resolving Handler
    note right of PROCESSING
      Execution Log: PROCESSING
      File Status: PREPARING
      Request: PROCESSING / PREPARING
    end note

    PROCESSING --> GENERATING: 3. Invoking Handler Execution
    note right of GENERATING
      Execution Log: GENERATING
      File Status: GENERATING
      Request: GENERATING / GENERATING
    end note

    GENERATING --> UPLOADING: 4. Uploading Generated Artifact to S3
    note right of UPLOADING
      Execution Log: UPLOADING
      File Status: UPLOADING
      Request: UPLOADING / UPLOADING
    end note

    GENERATING --> SUCCESS: Direct / Non-S3 Task Completed
    UPLOADING --> SUCCESS: 5. S3 Upload Successful
    note right of SUCCESS
      Execution Log: SUCCESS
      File Status: UPLOADED (or NOT_APPLICABLE)
      Request: READY / UPLOADED
    end note

    TRIGGERED --> FAILED: On Exception or Handler Failure
    PROCESSING --> FAILED: On Exception or Handler Failure
    GENERATING --> FAILED: On Exception or Handler Failure
    UPLOADING --> FAILED: On Exception or Handler Failure
    note right of FAILED
      Execution Log: FAILED
      File Status: FAILED
      Request: FAILED / FAILED
      Error safely unwrapped & truncated (<= 3,900 chars)
    end note
```

---

## 5. Sequence Diagrams

### 5.1 End-to-End Trigger Execution Flow

Demonstrates the execution path of a triggered job, including distributed lock verification, stale crash recovery, stepwise progress tracking, S3 upload, and `try-finally` lock release.

```mermaid
sequenceDiagram
    autonumber
    participant Quartz as "Quartz Engine / Trigger"
    participant Job as "DynamicDatabaseJob"
    participant DetailMapper as "ReportScheduleDetailMapper"
    participant LogMapper as "ScheduleReportExecutionLogMapper"
    participant ReqMapper as "ReportScheduleRequestMapper"
    participant Registry as "JobTaskHandlerRegistry"
    participant Handler as "ReportJobHandler / Target Handler"
    participant Dispatcher as "JobRequestDispatcher"
    participant S3 as "S3Service / AWS S3"

    Quartz->>Job: execute(JobExecutionContext)
    Job->>DetailMapper: findById(scheduleId)
    
    alt Schedule Missing or Inactive (PAUSED/DISABLED)
        Job-->>Quartz: Bail out immediately (No lock acquired)
    end

    Job->>Job: Check Debounce Window (lastUpdatedTs within 5s)
    
    Job->>DetailMapper: claimLock(scheduleId, lockTimeout=5min)
    alt Lock Acquisition Failed (claimedCount == 0)
        Job->>DetailMapper: breakStaleLeaseIfExpired(scheduleId)
        alt Lease Was Broken (reclaimedCount > 0)
            Job->>LogMapper: markStaleExecutionsAsFailed(scheduleId)
            Note over Job,LogMapper: Rescued abandoned executions from crashed node
        else Lock Held by Another Healthy Node
            Job-->>Quartz: Return (Skip overlapping execution)
        end
    end

    critical Execution Body with try-finally Lock Release
        Note over Job,LogMapper: Step 1: TRIGGERED / PENDING
        Job->>LogMapper: insert(status='TRIGGERED', fileStatus='PENDING')
        Job->>ReqMapper: updateStatus(requestId, 'TRIGGERED', 'PENDING')

        Note over Job,LogMapper: Step 2: PROCESSING / PREPARING
        Job->>LogMapper: updateExecution(status='PROCESSING', fileStatus='PREPARING')
        Job->>ReqMapper: updateStatus(requestId, 'PROCESSING', 'PREPARING')

        Note over Job,Handler: Step 3: GENERATING
        Job->>LogMapper: updateExecution(status='GENERATING', fileStatus='GENERATING')
        Job->>ReqMapper: updateStatus(requestId, 'GENERATING', 'GENERATING')
        Job->>Registry: getHandler(reportType / taskType)
        Registry-->>Job: ReportJobHandler
        Job->>Handler: execute(context, detail, request)

        Note over Handler,S3: Step 4: UPLOADING (if target is S3)
        Handler->>Dispatcher: dispatchReport(request, detail)
        Dispatcher->>Dispatcher: Generate Payload, Sanitize Name & Build S3 Key
        Dispatcher->>Job: Callback onUploadStart()
        Job->>LogMapper: updateExecution(status='UPLOADING', fileStatus='UPLOADING')
        Job->>ReqMapper: updateStatus(requestId, 'UPLOADING', 'UPLOADING')
        Dispatcher->>S3: uploadFile(bucket, key, byteContent)
        S3-->>Dispatcher: Upload Successful
        Dispatcher-->>Handler: JobExecutionOutcome(SUCCESS, recordCount, s3Key, s3Bucket)
        Handler-->>Job: JobExecutionOutcome

        Note over Job,LogMapper: Step 5: SUCCESS / UPLOADED
        Job->>LogMapper: updateExecution(status='SUCCESS', fileStatus='UPLOADED', endTime=now)
        Job->>ReqMapper: updateStatus(requestId, 'READY', 'UPLOADED')
    end

    Job->>DetailMapper: releaseLock(scheduleId)
    Note over Job,DetailMapper: Lock always released in finally block
```

---

### 5.2 Schedule Registration & Lifecycle Control Flow

Shows how clients create, update, pause, resume, and unschedule triggers dynamically at runtime.

```mermaid
sequenceDiagram
    autonumber
    actor Admin as "Client / Admin"
    participant API as "JobScheduleController"
    participant Service as "QuartzSchedulerService"
    participant DetailMapper as "ReportScheduleDetailMapper"
    participant ReqMapper as "ReportScheduleRequestMapper"
    participant Quartz as "Quartz Scheduler Engine"

    Admin->>API: POST /api/schedules (ScheduleRequestDto)
    API->>Service: createAndSchedule(detail, request)
    
    Service->>DetailMapper: insert(detail)
    DetailMapper-->>Service: scheduleId generated
    
    Service->>ReqMapper: insert(request with scheduleId)
    ReqMapper-->>Service: requestId generated
    
    Service->>Quartz: checkExists(JobKey("DB_JOB_scheduleId"))
    Service->>Quartz: scheduleJob(JobDetail, CronTrigger(cronExpression))
    Quartz-->>Service: Job Scheduled in Engine
    
    Service-->>API: Persisted ReportScheduleDetail
    API-->>Admin: 201 Created (Schedule JSON)

    opt Pause Schedule
        Admin->>API: POST /api/schedules/{id}/pause
        API->>Service: pauseJob(id)
        Service->>Quartz: pauseTrigger(TriggerKey)
        Service->>DetailMapper: updateStatus(id, "PAUSED")
        API-->>Admin: 200 OK ("Paused")
    end

    opt Resume Schedule
        Admin->>API: POST /api/schedules/{id}/resume
        API->>Service: resumeJob(id)
        Service->>Quartz: resumeTrigger(TriggerKey)
        Service->>DetailMapper: updateStatus(id, "ACTIVE")
        API-->>Admin: 200 OK ("Resumed")
    end

    opt Inactivate / Disable Schedule
        Admin->>API: PUT /api/schedules/{id} (status="INACTIVE")
        API->>Service: updateAndReschedule(id, detail, request)
        Service->>Quartz: unscheduleJob(TriggerKey)
        Note over Service,Quartz: Trigger detached from engine so threads aren't wasted
        Service->>DetailMapper: update(detail)
        API-->>Admin: 200 OK ("Updated and unscheduled")
    end
```

---

### 5.3 Historical Backfill Flow

Shows how past downtime windows are replayed sequentially without disrupting live cron timers.

```mermaid
sequenceDiagram
    autonumber
    actor Admin as "Client / Admin"
    participant API as "JobScheduleController"
    participant Service as "QuartzSchedulerService"
    participant DetailMapper as "ReportScheduleDetailMapper"
    participant Job as "DynamicDatabaseJob"
    participant LogMapper as "ScheduleReportExecutionLogMapper"

    Admin->>API: POST /api/schedules/{id}/backfill<br/>{ from: "2026-10-20T01:00", to: "2026-10-20T04:30" }
    API->>Service: backfillSchedule(id, from, to, payload)
    Service->>DetailMapper: findById(id)
    Service->>Service: Parse CronExpression & calculate all valid execution timestamps
    Note over Service: E.g., Hourly cron -> 01:00, 02:00, 03:00, 04:00 (4 slices)

    loop For each calculated slice
        Service->>Job: executeSlice(schedule, scheduledTime, customPayload)
        Job->>LogMapper: insert(status='TRIGGERED', fileStatus='PENDING', isBackfill=true)
        Job->>Job: Run Full 5-Step Lifecycle
        Job->>LogMapper: updateExecution(status='SUCCESS', fileStatus='UPLOADED')
    end

    Service-->>API: List of Execution Reference IDs (4 slices)
    API-->>Admin: 200 OK { message: "Backfill completed successfully", slicesExecutedCount: 4 }
```

---

### 5.4 Operational Monitoring & Paginated History Flow

Shows how monitoring dashboards fetch health summaries and filtered execution history.

```mermaid
sequenceDiagram
    autonumber
    actor Dashboard as "Admin Monitoring Dashboard"
    participant API as "JobScheduleController"
    participant DetailMapper as "ReportScheduleDetailMapper"
    participant LogMapper as "ScheduleReportExecutionLogMapper"

    Dashboard->>API: GET /api/schedules/summary
    API->>DetailMapper: countTotal() & countByStatus("ACTIVE") & countByStatus("PAUSED")
    API->>LogMapper: countTotal() & countByStatus("SUCCESS") & countByStatus("FAILED")
    API->>API: Compute successRatePercent
    API-->>Dashboard: 200 OK { status: "UP", totalSchedules, activeSchedules, successRatePercent: 98.5% }

    Dashboard->>API: GET /api/schedules/{id}/logs?status=FAILED&limit=10
    API->>LogMapper: findByScheduleIdWithFilters(id, "FAILED", null, 10)
    LogMapper-->>API: 10 most recent failed execution rows (SQL FETCH FIRST 10 ROWS ONLY)
    API-->>Dashboard: 200 OK [ List of execution logs ]
```

---

## 6. Concurrency, Locking & Reliability Architecture

| Mechanism | Description | Implementation File |
| :--- | :--- | :--- |
| **Distributed Lease Lock** | Atomic DB update (`claimLock`) setting `IS_LOCKED='Y'`, `LOCK_TIME=NOW`, and `LOCK_EXPIRE_AT=NOW + 5 MIN`. Prevents duplicate multi-node triggers. | `ReportScheduleDetailMapper.claimLock` |
| **Stale Lease Breaking** | If a node crashes mid-execution, surviving nodes break the expired lease via `breakStaleLeaseIfExpired` (`LOCK_EXPIRE_AT < NOW`). | `ReportScheduleDetailMapper.breakStaleLeaseIfExpired` |
| **Crash Execution Recovery** | Orphaned logs (`STATUS NOT IN ('SUCCESS', 'FAILED')` and `END_TIME IS NULL`) older than 15 mins are marked `FAILED` with recovery reasons. | `ScheduleReportExecutionLogMapper.markStaleExecutionsAsFailed` |
| **Guaranteed Lock Release** | Execution is wrapped in a strict `try-finally` block ensuring `releaseLock` is invoked regardless of unchecked runtime exceptions. | `DynamicDatabaseJob.java` |
| **Debounce Window** | Fast repetitive triggers within 5 seconds of the schedule's `LAST_UPDATED_TS` are skipped. | `DynamicDatabaseJob.java` |
| **Error Message Truncation** | Exception stack traces are unwrapped to their root cause and safely truncated to $\le 3,900$ characters to avoid DB column overflow. | `DynamicDatabaseJob.java` |
| **Trigger Unschedule Cleanup** | When a schedule is marked `INACTIVE`, `COMPLETED`, or `DISABLED`, the Quartz cron trigger is removed from the engine to save thread cycles. | `QuartzSchedulerService.updateAndReschedule` |

---

## 7. REST API Reference

| Method | Path | Description | Query / Body Parameters |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/schedules` | Create new schedule & register Quartz trigger | `ScheduleRequestDto` (JSON) |
| `GET` | `/api/schedules` | List all schedules | None |
| `GET` | `/api/schedules/{id}` | Get schedule detail by ID | Path variable `id` |
| `PUT` | `/api/schedules/{id}` | Update cron, metadata or status | Path variable `id`, `ScheduleRequestDto` |
| `POST` | `/api/schedules/{id}/pause` | Pause Quartz trigger and mark status `PAUSED` | Path variable `id` |
| `POST` | `/api/schedules/{id}/resume` | Resume Quartz trigger and mark status `ACTIVE` | Path variable `id` |
| `POST` | `/api/schedules/{id}/trigger` | Ad-hoc immediate manual trigger | Path variable `id` |
| `DELETE` | `/api/schedules/{id}` | Delete schedule from DB & Quartz engine | Path variable `id` |
| `POST` | `/api/schedules/sync` | Sync all active DB schedules to Quartz | None |
| `GET` | `/api/schedules/summary` | Scheduler health metrics & execution stats | None |
| `GET` | `/api/schedules/{id}/logs` | Execution history logs with pagination | `status`, `fileStatus`, `limit` (Optional) |
| `GET` | `/api/schedules/job-types` | List registered job task handlers | None |
| `POST` | `/api/schedules/{id}/backfill` | Replay missed cron slices over time window | `from`, `to`, `customPayload` (JSON) |
| `POST` | `/api/files/upload` | Multipart file upload to S3 | `MultipartFile file` |
| `POST` | `/api/files/stream-upload` | Low-memory streaming upload to S3 | `InputStream`, `X-File-Name` |
| `GET` | `/api/files/download/{fileName}` | Download file from S3 | Path variable `fileName` |
| `GET` | `/api/files/stream-download/{fileName}` | Streaming file download from S3 | Path variable `fileName` |
