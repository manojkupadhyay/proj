package com.example.s3ontap.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class S3ServiceTest {

    @Mock
    private S3Client s3Client;

    private S3Service s3Service;
    private final String testBucket = "my-test-bucket";

    @BeforeEach
    void setUp() {
        s3Service = new S3Service(s3Client, testBucket);
    }

    @Test
    void testUploadFileBuildsCorrectPutObjectRequest() {
        String key = "test-folder/sample.pdf";
        byte[] content = "Hello S3 ONTAP".getBytes();
        InputStream inputStream = new ByteArrayInputStream(content);
        long length = content.length;
        String contentType = "application/pdf";

        s3Service.uploadFile(key, inputStream, length, contentType);

        ArgumentCaptor<PutObjectRequest> requestCaptor = ArgumentCaptor.forClass(PutObjectRequest.class);
        verify(s3Client, times(1)).putObject(requestCaptor.capture(), any(RequestBody.class));

        PutObjectRequest capturedRequest = requestCaptor.getValue();
        assertEquals(testBucket, capturedRequest.bucket());
        assertEquals(key, capturedRequest.key());
        assertEquals(contentType, capturedRequest.contentType());
    }

    @Test
    void testDownloadFileBuildsCorrectGetObjectRequest() {
        String key = "reports/annual.csv";
        GetObjectResponse response = GetObjectResponse.builder().contentLength(100L).build();
        ResponseInputStream<GetObjectResponse> mockStream = new ResponseInputStream<>(response, new ByteArrayInputStream("data".getBytes()));

        when(s3Client.getObject(any(GetObjectRequest.class))).thenReturn(mockStream);

        ResponseInputStream<GetObjectResponse> resultStream = s3Service.downloadFile(key);

        assertNotNull(resultStream);
        assertSame(mockStream, resultStream);

        ArgumentCaptor<GetObjectRequest> requestCaptor = ArgumentCaptor.forClass(GetObjectRequest.class);
        verify(s3Client, times(1)).getObject(requestCaptor.capture());

        GetObjectRequest captured = requestCaptor.getValue();
        assertEquals(testBucket, captured.bucket());
        assertEquals(key, captured.key());
    }
}
