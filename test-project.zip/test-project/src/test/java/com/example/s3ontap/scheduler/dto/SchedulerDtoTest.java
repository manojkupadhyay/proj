package com.example.s3ontap.scheduler.dto;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class SchedulerDtoTest {

    @Test
    void testScheduleRequestDtoDefaultsAndMapping() {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        dto.setUserId("usr_100");
        dto.setCronExpression("0 0/15 * * * ?");
        dto.setStatus("ACTIVE");
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime expires = start.plusDays(30);
        dto.setStartAt(start);
        dto.setExpiresAt(expires);
        dto.setSystemDefined("Y");
        dto.setCreatedBy("admin");
        dto.setUpdatedBy("editor");

        dto.setReportName("FinancialQuarterly");
        dto.setReportType("FINANCIAL");
        dto.setOlbId("OLB_99");
        dto.setClientId("CL_55");
        dto.setPageId("PG_1");
        dto.setRptCriteriaPayload("{\"year\":2026}");
        dto.setRptCriteriaHeader("HeaderAuth");
        dto.setOutputFormat("EXCEL");

        assertEquals("usr_100", dto.getUserId());
        assertEquals("0 0/15 * * * ?", dto.getCronExpression());
        assertEquals("ACTIVE", dto.getStatus());
        assertEquals(start, dto.getStartAt());
        assertEquals(expires, dto.getExpiresAt());
        assertEquals("Y", dto.getSystemDefined());
        assertEquals("admin", dto.getCreatedBy());
        assertEquals("editor", dto.getUpdatedBy());
        assertEquals("FinancialQuarterly", dto.getReportName());
        assertEquals("FINANCIAL", dto.getReportType());
        assertEquals("OLB_99", dto.getOlbId());
        assertEquals("CL_55", dto.getClientId());
        assertEquals("PG_1", dto.getPageId());
        assertEquals("{\"year\":2026}", dto.getRptCriteriaPayload());
        assertEquals("HeaderAuth", dto.getRptCriteriaHeader());
        assertEquals("EXCEL", dto.getOutputFormat());

        // Test entity conversions
        ReportScheduleDetail scheduleEntity = dto.toScheduleEntity();
        assertNotNull(scheduleEntity);
        assertEquals("usr_100", scheduleEntity.getUserId());
        assertEquals("0 0/15 * * * ?", scheduleEntity.getCronExpression());
        assertEquals("ACTIVE", scheduleEntity.getStatus());
        assertEquals(start, scheduleEntity.getStartAt());
        assertEquals(expires, scheduleEntity.getExpiresAt());
        assertEquals("Y", scheduleEntity.getSystemDefined());

        ReportScheduleRequest requestEntity = dto.toRequestEntity();
        assertNotNull(requestEntity);
        assertEquals("FinancialQuarterly", requestEntity.getReportName());
        assertEquals("FINANCIAL", requestEntity.getReportType());
        assertEquals("OLB_99", requestEntity.getOlbId());
        assertEquals("CL_55", requestEntity.getClientId());
        assertEquals("PG_1", requestEntity.getPageId());
        assertEquals("{\"year\":2026}", requestEntity.getRptCriteriaPayload());
        assertEquals("HeaderAuth", requestEntity.getRptCriteriaHeader());
        assertEquals("EXCEL", requestEntity.getOutputFormat());
        assertEquals("READY", requestEntity.getStatus());
        assertEquals("READY", requestEntity.getFileStatus());
        assertEquals("QUEUED", requestEntity.getProcessingStatus());
    }

    @Test
    void testScheduleRequestDtoFallbackDefaults() {
        ScheduleRequestDto emptyDto = new ScheduleRequestDto();
        ReportScheduleDetail schedule = emptyDto.toScheduleEntity();
        assertEquals("ACTIVE", schedule.getStatus());
        assertEquals("N", schedule.getSystemDefined());

        ReportScheduleRequest request = emptyDto.toRequestEntity();
        assertEquals("Report_STANDARD", request.getReportName());
        assertEquals("STANDARD", request.getReportType());
        assertEquals("PDF", request.getOutputFormat());
        assertEquals("READY", request.getFileStatus());
    }

    @Test
    void testBackfillRequestDto() {
        LocalDateTime from = LocalDateTime.of(2026, 1, 1, 0, 0);
        LocalDateTime to = LocalDateTime.of(2026, 1, 2, 0, 0);

        BackfillRequestDto dto = new BackfillRequestDto(from, to);
        dto.setCustomPayload("{\"replay\":true}");

        assertEquals(from, dto.getFrom());
        assertEquals(to, dto.getTo());
        assertEquals("{\"replay\":true}", dto.getCustomPayload());

        BackfillRequestDto emptyDto = new BackfillRequestDto();
        emptyDto.setFrom(from);
        emptyDto.setTo(to);
        assertEquals(from, emptyDto.getFrom());
        assertEquals(to, emptyDto.getTo());
    }
}
