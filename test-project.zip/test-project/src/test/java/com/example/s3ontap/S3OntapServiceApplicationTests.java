package com.example.s3ontap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3OntapServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
