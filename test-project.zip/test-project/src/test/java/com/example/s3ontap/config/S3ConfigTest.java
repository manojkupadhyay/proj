package com.example.s3ontap.config;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.s3.S3Client;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class S3ConfigTest {

    @Test
    void testS3ClientBeanCreation() {
        S3Config config = new S3Config();
        ReflectionTestUtils.setField(config, "endpoint", "http://127.0.0.1:9000");
        ReflectionTestUtils.setField(config, "accessKey", "testAccessKey");
        ReflectionTestUtils.setField(config, "secretKey", "testSecretKey");
        ReflectionTestUtils.setField(config, "region", "us-east-1");

        S3Client client = config.s3Client();
        assertNotNull(client, "S3Client bean should be created successfully");
        client.close();
    }
}
