package com.example.s3ontap.controller;

import com.example.s3ontap.service.S3Service;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileControllerTest {

    @Mock
    private S3Service s3Service;

    @Mock
    private HttpServletRequest httpServletRequest;

    private FileController fileController;

    @BeforeEach
    void setUp() {
        fileController = new FileController(s3Service);
    }

    @Test
    void testUploadFileEmpty() {
        MockMultipartFile emptyFile = new MockMultipartFile("file", "test.txt", "text/plain", new byte[0]);
        ResponseEntity<String> response = fileController.uploadFile(emptyFile);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("Uploaded file is empty"));
        verifyNoInteractions(s3Service);
    }

    @Test
    void testUploadFileSuccess() {
        MockMultipartFile file = new MockMultipartFile("file", "sample.txt", "text/plain", "Hello S3".getBytes());
        doNothing().when(s3Service).uploadFile(eq("sample.txt"), any(InputStream.class), eq(8L), eq("text/plain"));

        ResponseEntity<String> response = fileController.uploadFile(file);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertTrue(response.getBody().contains("File uploaded successfully: sample.txt"));
        verify(s3Service).uploadFile(eq("sample.txt"), any(InputStream.class), eq(8L), eq("text/plain"));
    }

    @Test
    void testUploadFileNullFileNameFallback() {
        MockMultipartFile file = new MockMultipartFile("file", null, "text/plain", "Content".getBytes());

        ResponseEntity<String> response = fileController.uploadFile(file);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertTrue(response.getBody().contains("File uploaded successfully: uploaded-file-"));
        verify(s3Service).uploadFile(startsWith("uploaded-file-"), any(InputStream.class), eq(7L), eq("text/plain"));
    }

    @Test
    void testUploadFileS3ExceptionReturns500() {
        MockMultipartFile file = new MockMultipartFile("file", "sample.txt", "text/plain", "Hello S3".getBytes());
        doThrow(new RuntimeException("S3 connection failed")).when(s3Service)
                .uploadFile(anyString(), any(InputStream.class), anyLong(), anyString());

        ResponseEntity<String> response = fileController.uploadFile(file);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(response.getBody().contains("Error uploading file to S3"));
    }

    @Test
    void testStreamUploadInvalidContentLength() {
        ResponseEntity<String> response = fileController.streamUpload(
                "large.bin", "application/octet-stream", 0L, httpServletRequest);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("Content-Length header must be specified"));
    }

    @Test
    void testStreamUploadSuccess() throws Exception {
        byte[] data = "streaming raw content".getBytes();
        DelegatingServletInputStream servletInputStream = new DelegatingServletInputStream(new ByteArrayInputStream(data));
        when(httpServletRequest.getInputStream()).thenReturn(servletInputStream);

        ResponseEntity<String> response = fileController.streamUpload(
                "streamed.bin", "application/octet-stream", (long) data.length, httpServletRequest);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertTrue(response.getBody().contains("File streamed and uploaded successfully: streamed.bin"));
        verify(s3Service).uploadFile(eq("streamed.bin"), eq(servletInputStream), eq((long) data.length), eq("application/octet-stream"));
    }

    @Test
    void testDownloadFileSuccess() {
        GetObjectResponse getResponse = GetObjectResponse.builder()
                .contentLength(12L)
                .contentType("text/plain")
                .build();
        ResponseInputStream<GetObjectResponse> responseStream = new ResponseInputStream<>(
                getResponse, new ByteArrayInputStream("download data".getBytes()));

        when(s3Service.downloadFile("doc.txt")).thenReturn(responseStream);

        ResponseEntity<InputStreamResource> response = fileController.downloadFile("doc.txt");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(12L, response.getHeaders().getContentLength());
        assertNotNull(response.getBody());
    }

    @Test
    void testDownloadFileNoSuchKeyReturns404() {
        when(s3Service.downloadFile("missing.pdf")).thenThrow(NoSuchKeyException.builder().message("Key not found").build());

        ResponseEntity<InputStreamResource> response = fileController.downloadFile("missing.pdf");

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testDownloadFileGeneralExceptionReturns500() {
        when(s3Service.downloadFile("error.pdf")).thenThrow(new RuntimeException("Network timeout"));

        ResponseEntity<InputStreamResource> response = fileController.downloadFile("error.pdf");

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void testStreamDownloadSuccess() throws Exception {
        byte[] expectedBytes = "chunked binary response".getBytes();
        GetObjectResponse getResponse = GetObjectResponse.builder()
                .contentLength((long) expectedBytes.length)
                .contentType("application/octet-stream")
                .build();
        ResponseInputStream<GetObjectResponse> responseStream = new ResponseInputStream<>(
                getResponse, new ByteArrayInputStream(expectedBytes));

        when(s3Service.downloadFile("stream.dat")).thenReturn(responseStream);

        ResponseEntity<StreamingResponseBody> response = fileController.streamDownload("stream.dat");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        response.getBody().writeTo(baos);
        assertArrayEquals(expectedBytes, baos.toByteArray());
    }

    @Test
    void testStreamDownloadNoSuchKeyReturns404() {
        when(s3Service.downloadFile("missing.dat")).thenThrow(NoSuchKeyException.builder().message("Key not found").build());

        ResponseEntity<StreamingResponseBody> response = fileController.streamDownload("missing.dat");

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    private static class DelegatingServletInputStream extends ServletInputStream {
        private final InputStream sourceStream;

        public DelegatingServletInputStream(InputStream sourceStream) {
            this.sourceStream = sourceStream;
        }

        @Override
        public boolean isFinished() {
            try {
                return sourceStream.available() == 0;
            } catch (IOException e) {
                return true;
            }
        }

        @Override
        public boolean isReady() {
            return true;
        }

        @Override
        public void setReadListener(jakarta.servlet.ReadListener readListener) {
        }

        @Override
        public int read() throws IOException {
            return sourceStream.read();
        }
    }
}
