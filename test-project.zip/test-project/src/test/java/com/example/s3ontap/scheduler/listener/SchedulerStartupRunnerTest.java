package com.example.s3ontap.scheduler.listener;

import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchedulerStartupRunnerTest {

    @Mock
    private QuartzSchedulerService quartzSchedulerService;

    @InjectMocks
    private SchedulerStartupRunner runner;

    @Test
    void testOnApplicationReadySuccess() {
        when(quartzSchedulerService.syncAllActiveSchedulesFromDb()).thenReturn(5);

        assertDoesNotThrow(() -> runner.onApplicationReady());

        verify(quartzSchedulerService, times(1)).syncAllActiveSchedulesFromDb();
    }

    @Test
    void testOnApplicationReadyHandlesExceptionGracefully() {
        when(quartzSchedulerService.syncAllActiveSchedulesFromDb()).thenThrow(new RuntimeException("DB offline"));

        assertDoesNotThrow(() -> runner.onApplicationReady());

        verify(quartzSchedulerService, times(1)).syncAllActiveSchedulesFromDb();
    }
}
