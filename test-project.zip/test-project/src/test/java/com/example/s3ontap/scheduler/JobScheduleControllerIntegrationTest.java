package com.example.s3ontap.scheduler;

import com.example.s3ontap.scheduler.dto.ScheduleRequestDto;
import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JobScheduleControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private QuartzSchedulerService quartzSchedulerService;

    @Autowired
    private ReportScheduleDetailMapper reportScheduleDetailMapper;

    @Autowired
    private ReportScheduleRequestMapper reportScheduleRequestMapper;

    @Autowired
    private ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;

    @Autowired
    private Scheduler scheduler;

    private RestTemplate restTemplate;

    private String getBaseUrl() {
        return "http://localhost:" + port + "/api/schedules";
    }

    @BeforeEach
    void setUp() throws SchedulerException {
        restTemplate = new RestTemplate();
        scheduleReportExecutionLogMapper.deleteAll();
        reportScheduleRequestMapper.deleteAll();
        reportScheduleDetailMapper.deleteAll();
        scheduler.clear();
    }

    @Test
    void testCreateScheduleEndpoint() {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        dto.setUserId("user_web_01");
        dto.setCronExpression("0 0/15 * * * ?");
        dto.setReportName("ApiCreatedReport");
        dto.setReportType("FINANCIAL");
        dto.setOutputFormat("PDF");
        dto.setRptCriteriaPayload("{\"filter\":\"active\"}");

        ResponseEntity<Map> response = restTemplate.postForEntity(getBaseUrl(), dto, Map.class);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().get("scheduleId"));

        Long createdId = Long.valueOf(response.getBody().get("scheduleId").toString());

        // Verify it was persisted in DB via MyBatis
        ReportScheduleDetail saved = reportScheduleDetailMapper.findById(createdId);
        assertNotNull(saved);
        assertEquals("user_web_01", saved.getUserId());
        assertNotNull(saved.getRequest());
        assertEquals("ApiCreatedReport", saved.getRequest().getReportName());
    }

    @Test
    void testTriggerAndPauseResumeEndpoints() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("user_web_02", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("ControllerReport", "TEST", null);

        ReportScheduleDetail saved = quartzSchedulerService.createAndSchedule(schedule, request);
        Long id = saved.getScheduleId();

        // Trigger on-demand
        ResponseEntity<Map> triggerResp = restTemplate.postForEntity(getBaseUrl() + "/" + id + "/trigger", null, Map.class);
        assertEquals(HttpStatus.OK, triggerResp.getStatusCode());
        assertTrue(((String) triggerResp.getBody().get("message")).contains("triggered successfully"));
        Thread.sleep(1000);

        // Pause
        ResponseEntity<Map> pauseResp = restTemplate.postForEntity(getBaseUrl() + "/" + id + "/pause", null, Map.class);
        assertEquals(HttpStatus.OK, pauseResp.getStatusCode());
        assertEquals("PAUSED", reportScheduleDetailMapper.findById(id).getStatus());

        // Resume
        ResponseEntity<Map> resumeResp = restTemplate.postForEntity(getBaseUrl() + "/" + id + "/resume", null, Map.class);
        assertEquals(HttpStatus.OK, resumeResp.getStatusCode());
        assertEquals("ACTIVE", reportScheduleDetailMapper.findById(id).getStatus());

        // Sync from DB
        ResponseEntity<Map> syncResp = restTemplate.postForEntity(getBaseUrl() + "/sync", null, Map.class);
        assertEquals(HttpStatus.OK, syncResp.getStatusCode());
        assertNotNull(syncResp.getBody().get("jobsScheduledCount"));
    }

    @Test
    void testBackfillEndpoint() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("user_web_bf", "0 0 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("HourlyWebReport", "FINANCIAL", null);

        ReportScheduleDetail saved = quartzSchedulerService.createAndSchedule(schedule, request);
        Long id = saved.getScheduleId();

        com.example.s3ontap.scheduler.dto.BackfillRequestDto dto = new com.example.s3ontap.scheduler.dto.BackfillRequestDto();
        dto.setFrom(java.time.LocalDateTime.of(2026, 10, 20, 1, 0, 0));
        dto.setTo(java.time.LocalDateTime.of(2026, 10, 20, 4, 30, 0));
        dto.setCustomPayload("{\"backfill\":true}");

        ResponseEntity<Map> backfillResp = restTemplate.postForEntity(getBaseUrl() + "/" + id + "/backfill", dto, Map.class);
        assertEquals(HttpStatus.OK, backfillResp.getStatusCode());
        assertNotNull(backfillResp.getBody());
        assertEquals("Backfill completed successfully", backfillResp.getBody().get("message"));
        assertEquals(3, ((Number) backfillResp.getBody().get("slicesExecutedCount")).intValue());

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(id);
        assertEquals(3, logs.size());
    }

    @Test
    void testSummaryAndFilteredLogsEndpoints() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("user_summary_test", "0 0 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("SummaryReport", "AUDIT", null);
        ReportScheduleDetail saved = quartzSchedulerService.createAndSchedule(schedule, request);
        Long id = saved.getScheduleId();

        // Insert 3 execution logs directly
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        ScheduleReportExecutionLog log1 = new ScheduleReportExecutionLog(id, "REF-001", now);
        log1.setStatus("SUCCESS");
        log1.setFileStatus("UPLOADED");
        scheduleReportExecutionLogMapper.insert(log1);

        ScheduleReportExecutionLog log2 = new ScheduleReportExecutionLog(id, "REF-002", now);
        log2.setStatus("SUCCESS");
        log2.setFileStatus("UPLOADED");
        scheduleReportExecutionLogMapper.insert(log2);

        ScheduleReportExecutionLog log3 = new ScheduleReportExecutionLog(id, "REF-003", now);
        log3.setStatus("FAILED");
        log3.setFileStatus("FAILED");
        scheduleReportExecutionLogMapper.insert(log3);

        // Test Summary Endpoint
        ResponseEntity<Map> summaryResp = restTemplate.getForEntity(getBaseUrl() + "/summary", Map.class);
        assertEquals(HttpStatus.OK, summaryResp.getStatusCode());
        Map<?, ?> summary = summaryResp.getBody();
        assertNotNull(summary);
        assertEquals("UP", summary.get("status"));
        assertEquals(1, ((Number) summary.get("totalSchedules")).intValue());
        assertEquals(1, ((Number) summary.get("activeSchedules")).intValue());
        assertEquals(3, ((Number) summary.get("totalExecutions")).intValue());
        assertEquals(2, ((Number) summary.get("successfulExecutions")).intValue());
        assertEquals(1, ((Number) summary.get("failedExecutions")).intValue());

        // Test Filtered Logs Endpoint
        ResponseEntity<List> filteredResp = restTemplate.getForEntity(
                getBaseUrl() + "/" + id + "/logs?status=SUCCESS&limit=1", List.class);
        assertEquals(HttpStatus.OK, filteredResp.getStatusCode());
        assertNotNull(filteredResp.getBody());
        assertEquals(1, filteredResp.getBody().size());

        ResponseEntity<List> allSuccessResp = restTemplate.getForEntity(
                getBaseUrl() + "/" + id + "/logs?status=SUCCESS", List.class);
        assertEquals(HttpStatus.OK, allSuccessResp.getStatusCode());
        assertNotNull(allSuccessResp.getBody());
        assertEquals(2, allSuccessResp.getBody().size());
    }
}
