package com.example.s3ontap.scheduler.handler;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.job.JobRequestDispatcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JobHandlersTest {

    @Mock
    private JobRequestDispatcher jobRequestDispatcher;

    @Mock
    private ApplicationContext applicationContext;

    public static class SampleTestService {
        public String executeNoParam() {
            return "SUCCESS_NO_PARAM";
        }

        public String executeWithParam(String payload) {
            return "SUCCESS_WITH_PARAM: " + payload;
        }
    }

    @Test
    void testReportJobHandlerSupportsAndExecute() throws Exception {
        ReportJobHandler handler = new ReportJobHandler(jobRequestDispatcher);

        assertTrue(handler.supports("REPORT"));
        assertTrue(handler.supports("FINANCIAL"));
        assertTrue(handler.supports("AUDIT"));
        assertTrue(handler.supports("CUSTOM_REPORT"));
        assertTrue(handler.supports(null), "Null job type should be supported as default fallback");
        assertFalse(handler.supports("HTTP"));
        assertFalse(handler.supports("BEAN"));

        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(1L);
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setReportName("TestReport");

        JobRequestDispatcher.ReportExecutionResult result = new JobRequestDispatcher.ReportExecutionResult();
        result.status = "SUCCESS";
        result.generatedReportId = "GEN_100";
        result.recordCount = 200L;
        result.storageProvider = "S3";
        result.s3Bucket = "bucket";
        result.s3ObjectKey = "key";
        result.fileName = "file.pdf";
        result.fileFormat = "PDF";
        result.fileSizeBytes = 1000L;
        result.fileStatus = "UPLOADED";

        when(jobRequestDispatcher.dispatchReport(any(), any())).thenReturn(result);

        JobExecutionOutcome outcome = handler.execute(schedule, request);

        assertEquals("SUCCESS", outcome.getStatus());
        assertEquals("GEN_100", outcome.getExecutionReferenceId());
        assertEquals(200L, outcome.getRecordCount());
        assertEquals("S3", outcome.getStorageProvider());
        assertEquals("UPLOADED", outcome.getFileStatus());
    }

    @Test
    void testHttpWebhookJobHandlerSupportsAndExecute() throws Exception {
        HttpWebhookJobHandler handler = new HttpWebhookJobHandler();

        assertTrue(handler.supports("HTTP"));
        assertTrue(handler.supports("WEBHOOK"));
        assertTrue(handler.supports("REST"));
        assertTrue(handler.supports("HTTPS_API"));
        assertFalse(handler.supports("REPORT"));
        assertFalse(handler.supports(null));

        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(2L);
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setReportName("WebhookCall");
        request.setRptCriteriaPayload("{\"url\":\"http://api.test\"}");

        JobExecutionOutcome outcome = handler.execute(schedule, request);

        assertEquals("SUCCESS", outcome.getStatus());
        assertEquals("NONE", outcome.getStorageProvider());
        assertEquals("NOT_APPLICABLE", outcome.getFileStatus());
        assertTrue(outcome.getExecutionReferenceId().startsWith("HTTP_"));
        assertTrue(outcome.getResponsePayload().contains("200"));
    }

    @Test
    void testCustomBeanJobHandlerSupports() {
        CustomBeanJobHandler handler = new CustomBeanJobHandler(applicationContext);

        assertTrue(handler.supports("BEAN"));
        assertTrue(handler.supports("SERVICE"));
        assertTrue(handler.supports("CUSTOM"));
        assertTrue(handler.supports("DATA_SYNC"));
        assertFalse(handler.supports("REPORT"));
        assertFalse(handler.supports(null));
    }

    @Test
    void testCustomBeanJobHandlerExecuteNoParamMethod() throws Exception {
        CustomBeanJobHandler handler = new CustomBeanJobHandler(applicationContext);
        SampleTestService sampleService = new SampleTestService();

        when(applicationContext.containsBean("sampleService")).thenReturn(true);
        when(applicationContext.getBean("sampleService")).thenReturn(sampleService);

        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(3L);
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setRptCriteriaHeader("sampleService");
        request.setReportName("executeNoParam");

        JobExecutionOutcome outcome = handler.execute(schedule, request);

        assertEquals("SUCCESS", outcome.getStatus());
        assertEquals("NOT_APPLICABLE", outcome.getFileStatus());
        assertEquals("SUCCESS_NO_PARAM", outcome.getResponsePayload());
    }

    @Test
    void testCustomBeanJobHandlerExecuteWithParamMethod() throws Exception {
        CustomBeanJobHandler handler = new CustomBeanJobHandler(applicationContext);
        SampleTestService sampleService = new SampleTestService();

        when(applicationContext.containsBean("sampleService")).thenReturn(true);
        when(applicationContext.getBean("sampleService")).thenReturn(sampleService);

        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(4L);
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setRptCriteriaHeader("sampleService");
        request.setReportName("executeWithParam");
        request.setRptCriteriaPayload("hello-payload");

        JobExecutionOutcome outcome = handler.execute(schedule, request);

        assertEquals("SUCCESS", outcome.getStatus());
        assertEquals("SUCCESS_WITH_PARAM: hello-payload", outcome.getResponsePayload());
    }

    @Test
    void testCustomBeanJobHandlerSimulatedFallbackWhenBeanMissing() throws Exception {
        CustomBeanJobHandler handler = new CustomBeanJobHandler(applicationContext);
        when(applicationContext.containsBean("missingBean")).thenReturn(false);

        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(5L);
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setRptCriteriaHeader("missingBean");
        request.setReportName("runTask");

        JobExecutionOutcome outcome = handler.execute(schedule, request);

        assertEquals("SUCCESS", outcome.getStatus());
        assertTrue(outcome.getResponsePayload().contains("Simulated execution"));
    }

    @Test
    void testJobTaskHandlerRegistryResolution() {
        ReportJobHandler reportHandler = new ReportJobHandler(jobRequestDispatcher);
        HttpWebhookJobHandler webhookHandler = new HttpWebhookJobHandler();
        CustomBeanJobHandler beanHandler = new CustomBeanJobHandler(applicationContext);

        List<JobTaskHandler> handlers = Arrays.asList(reportHandler, webhookHandler, beanHandler);
        JobTaskHandlerRegistry registry = new JobTaskHandlerRegistry(handlers, reportHandler);

        assertSame(webhookHandler, registry.getHandler("HTTP"));
        assertSame(webhookHandler, registry.getHandler("WEBHOOK"));
        assertSame(beanHandler, registry.getHandler("BEAN"));
        assertSame(reportHandler, registry.getHandler("FINANCIAL"));
        assertSame(reportHandler, registry.getHandler("UNKNOWN_TYPE"));
        assertSame(reportHandler, registry.getHandler(null));

        List<String> names = registry.getRegisteredHandlerNames();
        assertEquals(3, names.size());
        assertTrue(names.contains("ReportJobHandler"));
        assertTrue(names.contains("HttpWebhookJobHandler"));
        assertTrue(names.contains("CustomBeanJobHandler"));
    }
}
