package com.example.s3ontap.scheduler.job;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.handler.JobExecutionOutcome;
import com.example.s3ontap.scheduler.handler.JobTaskHandler;
import com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DynamicDatabaseJobUnitTest {

    @Mock
    private ReportScheduleDetailMapper reportScheduleDetailMapper;

    @Mock
    private ReportScheduleRequestMapper reportScheduleRequestMapper;

    @Mock
    private ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;

    @Mock
    private JobTaskHandlerRegistry jobTaskHandlerRegistry;

    @Mock
    private JobExecutionContext jobExecutionContext;

    @Mock
    private JobDetail jobDetail;

    @Mock
    private Scheduler scheduler;

    @InjectMocks
    private DynamicDatabaseJob dynamicDatabaseJob;

    private JobDataMap jobDataMap;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(dynamicDatabaseJob, "instanceId", "test-node");
        ReflectionTestUtils.setField(dynamicDatabaseJob, "lockLeaseMinutes", 10);

        jobDataMap = new JobDataMap();
        jobDataMap.put("scheduleId", 100L);
        jobDataMap.put("manualTrigger", false);

        when(jobExecutionContext.getMergedJobDataMap()).thenReturn(jobDataMap);
        when(jobExecutionContext.getJobDetail()).thenReturn(jobDetail);
        when(jobDetail.getKey()).thenReturn(JobKey.jobKey("TEST_JOB", "TEST_GROUP"));
    }

    @Test
    void testExecuteScheduleNotFoundBailsOutSafely() throws JobExecutionException {
        when(reportScheduleDetailMapper.findById(100L)).thenReturn(null);

        assertDoesNotThrow(() -> dynamicDatabaseJob.execute(jobExecutionContext));

        verify(reportScheduleRequestMapper, never()).claimExecutionLockWithTimeout(any(), any());
    }

    @Test
    void testExecuteInactiveScheduleSkips() throws JobExecutionException {
        ReportScheduleDetail schedule = new ReportScheduleDetail("u1", "0 0/10 * * * ?", "PAUSED");
        when(reportScheduleDetailMapper.findById(100L)).thenReturn(schedule);

        assertDoesNotThrow(() -> dynamicDatabaseJob.execute(jobExecutionContext));

        verify(reportScheduleRequestMapper, never()).claimExecutionLockWithTimeout(any(), any());
    }

    @Test
    void testExecuteMissingRequestRecordSkipsWithoutLockLeak() throws JobExecutionException {
        ReportScheduleDetail schedule = new ReportScheduleDetail("u1", "0 0/10 * * * ?", "ACTIVE");
        when(reportScheduleDetailMapper.findById(100L)).thenReturn(schedule);
        when(reportScheduleRequestMapper.findByScheduleId(100L)).thenReturn(null);

        assertDoesNotThrow(() -> dynamicDatabaseJob.execute(jobExecutionContext));

        verify(reportScheduleRequestMapper, never()).claimExecutionLockWithTimeout(any(), any());
    }

    @Test
    void testExecuteLockClaimZeroSkips() throws JobExecutionException {
        ReportScheduleDetail schedule = new ReportScheduleDetail("u1", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("Rpt", "REPORT", 100L);
        schedule.setRequest(request);

        when(reportScheduleDetailMapper.findById(100L)).thenReturn(schedule);
        when(reportScheduleRequestMapper.claimExecutionLockWithTimeout(eq(100L), any())).thenReturn(0);

        assertDoesNotThrow(() -> dynamicDatabaseJob.execute(jobExecutionContext));

        verify(scheduleReportExecutionLogMapper, never()).insert(any());
    }

    @Test
    void testExecuteSuccessfulFlow() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("u1", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("Rpt", "REPORT", 100L);
        schedule.setRequest(request);

        when(reportScheduleDetailMapper.findById(100L)).thenReturn(schedule);
        when(reportScheduleRequestMapper.claimExecutionLockWithTimeout(eq(100L), any())).thenReturn(1);

        JobTaskHandler handler = mock(JobTaskHandler.class);
        when(jobTaskHandlerRegistry.getHandler(anyString())).thenReturn(handler);

        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus("SUCCESS");
        outcome.setStorageProvider("S3");
        outcome.setFileStatus("UPLOADED");
        outcome.setExecutionReferenceId("REF_SUCCESS");
        outcome.setRecordCount(50L);
        when(handler.execute(any(), any())).thenReturn(outcome);

        doAnswer(invocation -> {
            ScheduleReportExecutionLog execLog = invocation.getArgument(0);
            execLog.setExecutionId(1L);
            return 1;
        }).when(scheduleReportExecutionLogMapper).insert(any(ScheduleReportExecutionLog.class));

        assertDoesNotThrow(() -> dynamicDatabaseJob.execute(jobExecutionContext));

        verify(scheduleReportExecutionLogMapper, times(1)).insert(any(ScheduleReportExecutionLog.class));
        verify(scheduleReportExecutionLogMapper).updateStatusAndFileStatus(1L, "PROCESSING", "PREPARING");
        verify(scheduleReportExecutionLogMapper).updateStatusAndFileStatus(1L, "GENERATING", "GENERATING");
        verify(scheduleReportExecutionLogMapper).updateStatusAndFileStatus(1L, "UPLOADING", "UPLOADING");
        verify(scheduleReportExecutionLogMapper).updateExecutionOutcome(any(ScheduleReportExecutionLog.class));

        verify(reportScheduleRequestMapper).updateStatusAndFileStatus(100L, "TRIGGERED", "PENDING");
        verify(reportScheduleRequestMapper).updateStatusAndFileStatus(100L, "PROCESSING", "PREPARING");
        verify(reportScheduleRequestMapper).updateStatusAndFileStatus(100L, "GENERATING", "GENERATING");
        verify(reportScheduleRequestMapper).updateStatusAndFileStatus(100L, "UPLOADING", "UPLOADING");
        verify(reportScheduleRequestMapper).updateStatusAndFileStatus(100L, "READY", "UPLOADED");
        verify(reportScheduleRequestMapper).releaseExecutionLock(100L, "SUCCESS");
    }
}
