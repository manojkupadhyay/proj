package com.example.s3ontap.scheduler.job;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JobRequestDispatcherTest {

    private final JobRequestDispatcher dispatcher = new JobRequestDispatcher();

    @Test
    void testDispatchReportDefaults() {
        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(42L);

        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setReportName("Sales & Revenue / Q3!");
        request.setReportType("FINANCIAL");
        request.setOutputFormat("CSV");
        request.setRptCriteriaPayload("{\"region\":\"EMEA\"}");

        JobRequestDispatcher.ReportExecutionResult result = dispatcher.dispatchReport(schedule, request);

        assertNotNull(result);
        assertEquals("RPT_42", result.reportId);
        assertTrue(result.generatedReportId.startsWith("GEN_"));
        assertEquals("CSV", result.fileFormat);
        assertEquals("S3", result.storageProvider);
        assertEquals("reports-bucket", result.s3Bucket);
        assertTrue(result.fileName.startsWith("Sales___Revenue___Q3__"));
        assertTrue(result.fileName.endsWith(".csv"));
        assertTrue(result.s3ObjectKey.startsWith("scheduled-reports/FINANCIAL/"));
        assertEquals("SUCCESS", result.status);
        assertEquals("UPLOADED", result.fileStatus);
        assertEquals(150L, result.recordCount);
        assertTrue(result.fileSizeBytes > 0);
    }

    @Test
    void testDispatchReportWithNullRequestFallback() {
        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setScheduleId(99L);

        JobRequestDispatcher.ReportExecutionResult result = dispatcher.dispatchReport(schedule, null);

        assertNotNull(result);
        assertEquals("RPT_99", result.reportId);
        assertEquals("PDF", result.fileFormat);
        assertTrue(result.fileName.startsWith("Report_99_"));
        assertTrue(result.fileName.endsWith(".pdf"));
    }
}
