package com.example.s3ontap.scheduler.controller;

import com.example.s3ontap.scheduler.dto.BackfillRequestDto;
import com.example.s3ontap.scheduler.dto.ScheduleRequestDto;
import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.SchedulerException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JobScheduleControllerUnitTest {

    @Mock
    private QuartzSchedulerService quartzSchedulerService;

    @Mock
    private ReportScheduleDetailMapper reportScheduleDetailMapper;

    @Mock
    private ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;

    @Mock
    private JobTaskHandlerRegistry jobTaskHandlerRegistry;

    private JobScheduleController controller;

    @BeforeEach
    void setUp() {
        controller = new JobScheduleController(
                quartzSchedulerService,
                reportScheduleDetailMapper,
                scheduleReportExecutionLogMapper,
                jobTaskHandlerRegistry
        );
    }

    @Test
    void testCreateScheduleSuccess() throws Exception {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        dto.setCronExpression("0 0/10 * * * ?");
        ReportScheduleDetail created = new ReportScheduleDetail("u1", "0 0/10 * * * ?", "ACTIVE");
        created.setScheduleId(1L);

        when(quartzSchedulerService.createAndSchedule(any(), any())).thenReturn(created);

        ResponseEntity<?> response = controller.createSchedule(dto);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertSame(created, response.getBody());
    }

    @Test
    void testCreateScheduleIllegalArgumentReturns400() throws Exception {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        when(quartzSchedulerService.createAndSchedule(any(), any())).thenThrow(new IllegalArgumentException("Invalid cron"));

        ResponseEntity<?> response = controller.createSchedule(dto);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void testCreateScheduleSchedulerExceptionReturns500() throws Exception {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        when(quartzSchedulerService.createAndSchedule(any(), any())).thenThrow(new SchedulerException("Quartz engine error"));

        ResponseEntity<?> response = controller.createSchedule(dto);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void testGetAllSchedules() {
        when(reportScheduleDetailMapper.findAll()).thenReturn(Collections.emptyList());
        ResponseEntity<List<ReportScheduleDetail>> response = controller.getAllSchedules();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isEmpty());
    }

    @Test
    void testGetScheduleByIdFoundAndNotFound() {
        ReportScheduleDetail detail = new ReportScheduleDetail();
        detail.setScheduleId(10L);
        when(reportScheduleDetailMapper.findById(10L)).thenReturn(detail);
        when(reportScheduleDetailMapper.findById(99L)).thenReturn(null);

        ResponseEntity<?> found = controller.getScheduleById(10L);
        assertEquals(HttpStatus.OK, found.getStatusCode());

        ResponseEntity<?> notFound = controller.getScheduleById(99L);
        assertEquals(HttpStatus.NOT_FOUND, notFound.getStatusCode());
    }

    @Test
    void testUpdateScheduleSuccessAndExceptions() throws Exception {
        ScheduleRequestDto dto = new ScheduleRequestDto();
        ReportScheduleDetail updated = new ReportScheduleDetail();
        when(quartzSchedulerService.updateAndReschedule(eq(5L), any(), any())).thenReturn(updated);

        ResponseEntity<?> success = controller.updateSchedule(5L, dto);
        assertEquals(HttpStatus.OK, success.getStatusCode());

        when(quartzSchedulerService.updateAndReschedule(eq(6L), any(), any())).thenThrow(new IllegalArgumentException("Schedule not found"));
        ResponseEntity<?> badRequest = controller.updateSchedule(6L, dto);
        assertEquals(HttpStatus.BAD_REQUEST, badRequest.getStatusCode());

        when(quartzSchedulerService.updateAndReschedule(eq(7L), any(), any())).thenThrow(new SchedulerException("Update failed"));
        ResponseEntity<?> error = controller.updateSchedule(7L, dto);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, error.getStatusCode());
    }

    @Test
    void testPauseAndResumeSchedule() throws Exception {
        doNothing().when(quartzSchedulerService).pauseJob(1L);
        ResponseEntity<?> pauseResp = controller.pauseSchedule(1L);
        assertEquals(HttpStatus.OK, pauseResp.getStatusCode());

        doThrow(new RuntimeException("Error")).when(quartzSchedulerService).pauseJob(2L);
        ResponseEntity<?> pauseErr = controller.pauseSchedule(2L);
        assertEquals(HttpStatus.BAD_REQUEST, pauseErr.getStatusCode());

        doNothing().when(quartzSchedulerService).resumeJob(1L);
        ResponseEntity<?> resumeResp = controller.resumeSchedule(1L);
        assertEquals(HttpStatus.OK, resumeResp.getStatusCode());

        doThrow(new RuntimeException("Error")).when(quartzSchedulerService).resumeJob(2L);
        ResponseEntity<?> resumeErr = controller.resumeSchedule(2L);
        assertEquals(HttpStatus.BAD_REQUEST, resumeErr.getStatusCode());
    }

    @Test
    void testTriggerJobNowAndDeleteSchedule() throws Exception {
        doNothing().when(quartzSchedulerService).triggerJobNow(1L);
        ResponseEntity<?> triggerResp = controller.triggerJobNow(1L);
        assertEquals(HttpStatus.OK, triggerResp.getStatusCode());

        doThrow(new RuntimeException("Trigger failed")).when(quartzSchedulerService).triggerJobNow(2L);
        ResponseEntity<?> triggerErr = controller.triggerJobNow(2L);
        assertEquals(HttpStatus.BAD_REQUEST, triggerErr.getStatusCode());

        doNothing().when(quartzSchedulerService).deleteJob(1L);
        ResponseEntity<?> deleteResp = controller.deleteSchedule(1L);
        assertEquals(HttpStatus.OK, deleteResp.getStatusCode());

        doThrow(new RuntimeException("Delete failed")).when(quartzSchedulerService).deleteJob(2L);
        ResponseEntity<?> deleteErr = controller.deleteSchedule(2L);
        assertEquals(HttpStatus.BAD_REQUEST, deleteErr.getStatusCode());
    }

    @Test
    void testSyncSchedulesAndJobLogsAndJobTypes() {
        when(quartzSchedulerService.syncAllActiveSchedulesFromDb()).thenReturn(3);
        ResponseEntity<?> syncResp = controller.syncSchedulesFromDb();
        assertEquals(HttpStatus.OK, syncResp.getStatusCode());
        assertEquals(3, ((Map<?, ?>) syncResp.getBody()).get("jobsScheduledCount"));

        when(scheduleReportExecutionLogMapper.findByScheduleId(1L)).thenReturn(Collections.emptyList());
        ResponseEntity<List<ScheduleReportExecutionLog>> logsResp = controller.getJobLogs(1L);
        assertEquals(HttpStatus.OK, logsResp.getStatusCode());

        when(scheduleReportExecutionLogMapper.findByScheduleIdWithFilters(1L, "SUCCESS", "UPLOADED", 10))
                .thenReturn(Collections.emptyList());
        ResponseEntity<List<ScheduleReportExecutionLog>> filteredLogs = controller.getJobLogs(1L, "SUCCESS", "UPLOADED", 10);
        assertEquals(HttpStatus.OK, filteredLogs.getStatusCode());

        when(jobTaskHandlerRegistry.getRegisteredHandlerNames()).thenReturn(List.of("ReportJobHandler"));
        ResponseEntity<List<String>> typesResp = controller.getRegisteredJobTypes();
        assertEquals(HttpStatus.OK, typesResp.getStatusCode());
        assertEquals(1, typesResp.getBody().size());
    }

    @Test
    void testGetSchedulerSummary() {
        when(reportScheduleDetailMapper.countTotal()).thenReturn(10L);
        when(reportScheduleDetailMapper.countByStatus("ACTIVE")).thenReturn(8L);
        when(reportScheduleDetailMapper.countByStatus("PAUSED")).thenReturn(2L);
        when(scheduleReportExecutionLogMapper.countTotal()).thenReturn(50L);
        when(scheduleReportExecutionLogMapper.countByStatus("SUCCESS")).thenReturn(45L);
        when(scheduleReportExecutionLogMapper.countByStatus("FAILED")).thenReturn(5L);

        ResponseEntity<Map<String, Object>> response = controller.getSchedulerSummary();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertNotNull(body);
        assertEquals("UP", body.get("status"));
        assertEquals(10L, body.get("totalSchedules"));
        assertEquals(8L, body.get("activeSchedules"));
        assertEquals(2L, body.get("pausedSchedules"));
        assertEquals(50L, body.get("totalExecutions"));
        assertEquals(45L, body.get("successfulExecutions"));
        assertEquals(5L, body.get("failedExecutions"));
        assertEquals(90.0, body.get("successRatePercent"));
    }

    @Test
    void testGetSchedulerSummaryZeroExecutions() {
        when(reportScheduleDetailMapper.countTotal()).thenReturn(0L);
        when(reportScheduleDetailMapper.countByStatus(anyString())).thenReturn(0L);
        when(scheduleReportExecutionLogMapper.countTotal()).thenReturn(0L);
        when(scheduleReportExecutionLogMapper.countByStatus(anyString())).thenReturn(0L);

        ResponseEntity<Map<String, Object>> response = controller.getSchedulerSummary();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertNotNull(body);
        assertEquals(100.0, body.get("successRatePercent"));
    }

    @Test
    void testBackfillScheduleSuccessAndErrors() throws Exception {
        BackfillRequestDto dto = new BackfillRequestDto();
        dto.setFrom(LocalDateTime.now().minusHours(2));
        dto.setTo(LocalDateTime.now());

        when(quartzSchedulerService.backfillSchedule(eq(1L), any(), any(), any())).thenReturn(List.of("REF_1", "REF_2"));
        ResponseEntity<?> success = controller.backfillSchedule(1L, dto);
        assertEquals(HttpStatus.OK, success.getStatusCode());
        assertEquals(2, ((Map<?, ?>) success.getBody()).get("slicesExecutedCount"));

        when(quartzSchedulerService.backfillSchedule(eq(2L), any(), any(), any())).thenThrow(new IllegalArgumentException("Invalid window"));
        ResponseEntity<?> badReq = controller.backfillSchedule(2L, dto);
        assertEquals(HttpStatus.BAD_REQUEST, badReq.getStatusCode());

        when(quartzSchedulerService.backfillSchedule(eq(3L), any(), any(), any())).thenThrow(new Exception("Internal failure"));
        ResponseEntity<?> serverErr = controller.backfillSchedule(3L, dto);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, serverErr.getStatusCode());
    }
}
