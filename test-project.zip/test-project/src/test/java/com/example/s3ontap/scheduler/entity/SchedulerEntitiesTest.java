package com.example.s3ontap.scheduler.entity;

import com.example.s3ontap.scheduler.handler.JobExecutionOutcome;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class SchedulerEntitiesTest {

    @Test
    void testReportScheduleDetailProperties() {
        ReportScheduleDetail detail = new ReportScheduleDetail("usr_test", "0 0/10 * * * ?", "ACTIVE");
        detail.setScheduleId(101L);
        LocalDateTime now = LocalDateTime.now();
        detail.setNextRunTime(now.plusMinutes(10));
        detail.setStartAt(now);
        detail.setExpiresAt(now.plusDays(7));
        detail.setCreatedDate(now);
        detail.setCreatedBy("creator");
        detail.setUpdatedBy("modifier");
        detail.setCreatedAt(now);
        detail.setUpdatedAt(now);
        detail.setPreviousScheduleId(100L);
        detail.setSystemDefined("Y");
        detail.setLastUpdatedTs(now);

        ReportScheduleRequest request = new ReportScheduleRequest();
        detail.setRequest(request);

        assertEquals(101L, detail.getScheduleId());
        assertEquals("usr_test", detail.getUserId());
        assertEquals("0 0/10 * * * ?", detail.getCronExpression());
        assertEquals("ACTIVE", detail.getStatus());
        assertEquals(now.plusMinutes(10), detail.getNextRunTime());
        assertEquals(now, detail.getStartAt());
        assertEquals(now.plusDays(7), detail.getExpiresAt());
        assertEquals(now, detail.getCreatedDate());
        assertEquals("creator", detail.getCreatedBy());
        assertEquals("modifier", detail.getUpdatedBy());
        assertEquals(now, detail.getCreatedAt());
        assertEquals(now, detail.getUpdatedAt());
        assertEquals(100L, detail.getPreviousScheduleId());
        assertEquals("Y", detail.getSystemDefined());
        assertEquals(now, detail.getLastUpdatedTs());
        assertSame(request, detail.getRequest());
    }

    @Test
    void testReportScheduleRequestProperties() {
        ReportScheduleRequest req = new ReportScheduleRequest("SummaryRpt", "FINANCIAL", 101L);
        req.setRequestId(501L);
        req.setOlbId("OLB_1");
        req.setUserId("usr_1");
        req.setClientId("cli_1");
        req.setPageId("pg_1");
        req.setRptCriteriaPayload("{\"key\":\"val\"}");
        req.setRptCriteriaHeader("Header1");
        req.setOutputFormat("CSV");
        req.setStatus("READY");
        req.setFileStatus("READY");
        req.setProcessingStatus("QUEUED");
        LocalDateTime now = LocalDateTime.now();
        req.setCreatedAt(now);
        req.setUpdatedAt(now);
        req.setCreatedBy("admin");
        req.setUpdatedBy("admin");
        req.setPreviousRequestId(500L);

        assertEquals(501L, req.getRequestId());
        assertEquals("SummaryRpt", req.getReportName());
        assertEquals("FINANCIAL", req.getReportType());
        assertEquals(101L, req.getScheduleId());
        assertEquals("OLB_1", req.getOlbId());
        assertEquals("usr_1", req.getUserId());
        assertEquals("cli_1", req.getClientId());
        assertEquals("pg_1", req.getPageId());
        assertEquals("{\"key\":\"val\"}", req.getRptCriteriaPayload());
        assertEquals("Header1", req.getRptCriteriaHeader());
        assertEquals("CSV", req.getOutputFormat());
        assertEquals("READY", req.getStatus());
        assertEquals("READY", req.getFileStatus());
        assertEquals("QUEUED", req.getProcessingStatus());
        assertEquals(now, req.getCreatedAt());
        assertEquals(now, req.getUpdatedAt());
        assertEquals("admin", req.getCreatedBy());
        assertEquals("admin", req.getUpdatedBy());
        assertEquals(500L, req.getPreviousRequestId());
    }

    @Test
    void testScheduleReportExecutionLogProperties() {
        LocalDateTime start = LocalDateTime.now();
        ScheduleReportExecutionLog log = new ScheduleReportExecutionLog(201L, "RPT_201", start);
        log.setExecutionId(999L);
        LocalDateTime end = start.plusSeconds(3);
        log.setEndTime(end);
        log.setStatus("SUCCESS");
        log.setFileStatus("UPLOADED");
        log.setGeneratedReportId("GEN_201_xyz");
        log.setRecordCount(1500L);
        log.setStorageProvider("S3");
        log.setS3Bucket("my-bucket");
        log.setS3ObjectKey("scheduled-reports/FINANCIAL/report.pdf");
        log.setFileName("report.pdf");
        log.setFileFormat("PDF");
        log.setFileSizeBytes(45000L);
        log.setReportType("FINANCIAL");
        log.setOlbId("OLB_201");
        log.setUserId("usr_201");
        log.setClientId("cli_201");
        log.setPageId("pg_201");
        log.setRetryCount(1);
        log.setErrorMessage(null);
        LocalDateTime now = LocalDateTime.now();
        log.setCreateAt(now);
        log.setUpdatedAt(now);

        assertEquals(999L, log.getExecutionId());
        assertEquals(201L, log.getScheduleId());
        assertEquals("RPT_201", log.getReportId());
        assertEquals(start, log.getStartTime());
        assertEquals(end, log.getEndTime());
        assertEquals("SUCCESS", log.getStatus());
        assertEquals("UPLOADED", log.getFileStatus());
        assertEquals("GEN_201_xyz", log.getGeneratedReportId());
        assertEquals(1500L, log.getRecordCount());
        assertEquals("S3", log.getStorageProvider());
        assertEquals("my-bucket", log.getS3Bucket());
        assertEquals("scheduled-reports/FINANCIAL/report.pdf", log.getS3ObjectKey());
        assertEquals("report.pdf", log.getFileName());
        assertEquals("PDF", log.getFileFormat());
        assertEquals(45000L, log.getFileSizeBytes());
        assertEquals("FINANCIAL", log.getReportType());
        assertEquals("OLB_201", log.getOlbId());
        assertEquals("usr_201", log.getUserId());
        assertEquals("cli_201", log.getClientId());
        assertEquals("pg_201", log.getPageId());
        assertEquals(1, log.getRetryCount());
        assertNull(log.getErrorMessage());
        assertEquals(now, log.getCreateAt());
        assertEquals(now, log.getUpdatedAt());
    }

    @Test
    void testJobExecutionOutcomeProperties() {
        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus("SUCCESS");
        outcome.setExecutionReferenceId("REF_123");
        outcome.setRecordCount(50L);
        outcome.setStorageProvider("S3");
        outcome.setS3Bucket("bucket1");
        outcome.setS3ObjectKey("key1");
        outcome.setFileName("file1.pdf");
        outcome.setFileFormat("PDF");
        outcome.setFileSizeBytes(1024L);
        outcome.setFileStatus("UPLOADED");
        outcome.setErrorMessage("No error");
        outcome.setResponsePayload("{\"ok\":true}");

        assertEquals("SUCCESS", outcome.getStatus());
        assertEquals("REF_123", outcome.getExecutionReferenceId());
        assertEquals(50L, outcome.getRecordCount());
        assertEquals("S3", outcome.getStorageProvider());
        assertEquals("bucket1", outcome.getS3Bucket());
        assertEquals("key1", outcome.getS3ObjectKey());
        assertEquals("file1.pdf", outcome.getFileName());
        assertEquals("PDF", outcome.getFileFormat());
        assertEquals(1024L, outcome.getFileSizeBytes());
        assertEquals("UPLOADED", outcome.getFileStatus());
        assertEquals("No error", outcome.getErrorMessage());
        assertEquals("{\"ok\":true}", outcome.getResponsePayload());
    }
}
