package com.example.s3ontap.scheduler.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.SqlSessionTemplate;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.spi.OperableTrigger;
import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.quartz.autoconfigure.SchedulerFactoryBeanCustomizer;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import javax.sql.DataSource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SchedulerConfigTest {

    public static class TestSampleJob implements Job {
        @Override
        public void execute(JobExecutionContext context) throws JobExecutionException {
        }
    }

    @Test
    void testAutowiringSpringBeanJobFactory() throws Exception {
        AutowiringSpringBeanJobFactory factory = new AutowiringSpringBeanJobFactory();
        ApplicationContext applicationContext = mock(ApplicationContext.class);
        AutowireCapableBeanFactory beanFactory = mock(AutowireCapableBeanFactory.class);

        when(applicationContext.getAutowireCapableBeanFactory()).thenReturn(beanFactory);
        factory.setApplicationContext(applicationContext);

        JobDetail jobDetail = mock(JobDetail.class);
        doReturn(TestSampleJob.class).when(jobDetail).getJobClass();

        OperableTrigger trigger = mock(OperableTrigger.class);

        TriggerFiredBundle bundle = new TriggerFiredBundle(
                jobDetail, trigger, null, false, null, null, null, null
        );

        Object jobInstance = factory.createJobInstance(bundle);
        assertNotNull(jobInstance);
        assertTrue(jobInstance instanceof TestSampleJob);
        verify(beanFactory, times(1)).autowireBean(jobInstance);
    }

    @Test
    void testQuartzConfigCustomizer() {
        AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
        QuartzConfig quartzConfig = new QuartzConfig(jobFactory);

        SchedulerFactoryBeanCustomizer customizer = quartzConfig.schedulerFactoryBeanCustomizer();
        assertNotNull(customizer);

        SchedulerFactoryBean schedulerFactoryBean = mock(SchedulerFactoryBean.class);
        customizer.customize(schedulerFactoryBean);

        verify(schedulerFactoryBean).setJobFactory(jobFactory);
        verify(schedulerFactoryBean).setOverwriteExistingJobs(true);
        verify(schedulerFactoryBean).setAutoStartup(true);
        verify(schedulerFactoryBean).setWaitForJobsToCompleteOnShutdown(true);
    }

    @Test
    void testMyBatisConfigBeans() throws Exception {
        MyBatisConfig myBatisConfig = new MyBatisConfig();
        DataSource dataSource = new DriverManagerDataSource("jdbc:h2:mem:configdb", "sa", "");

        SqlSessionFactory sessionFactory = myBatisConfig.sqlSessionFactory(dataSource);
        assertNotNull(sessionFactory, "SqlSessionFactory should be created");
        assertTrue(sessionFactory.getConfiguration().isMapUnderscoreToCamelCase());

        SqlSessionTemplate sessionTemplate = myBatisConfig.sqlSessionTemplate(sessionFactory);
        assertNotNull(sessionTemplate, "SqlSessionTemplate should be created");
        assertSame(sessionFactory, sessionTemplate.getSqlSessionFactory());
    }
}
