package com.example.s3ontap.scheduler;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class QuartzDatabaseSchedulerIntegrationTest {

    @Autowired
    private QuartzSchedulerService quartzSchedulerService;

    @Autowired
    private ReportScheduleDetailMapper reportScheduleDetailMapper;

    @Autowired
    private ReportScheduleRequestMapper reportScheduleRequestMapper;

    @Autowired
    private ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;

    @Autowired
    private Scheduler scheduler;

    @BeforeEach
    void setUp() throws SchedulerException {
        scheduleReportExecutionLogMapper.deleteAll();
        reportScheduleRequestMapper.deleteAll();
        reportScheduleDetailMapper.deleteAll();
        scheduler.clear();
    }

    @Test
    void testCreateAndScheduleJobFromDatabase() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("usr_test_01", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("FinancialSummary", "FINANCIAL", null);
        request.setRptCriteriaPayload("{\"fiscalYear\":2026,\"quarter\":\"Q3\"}");
        request.setOutputFormat("PDF");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        assertNotNull(created.getScheduleId());
        assertEquals("ACTIVE", created.getStatus());

        // Verify scheduled in Quartz
        JobKey jobKey = JobKey.jobKey("REPORT_JOB_" + created.getScheduleId(), "FINANCIAL");
        TriggerKey triggerKey = TriggerKey.triggerKey("REPORT_JOB_" + created.getScheduleId() + "_trigger", "FINANCIAL");

        assertTrue(scheduler.checkExists(jobKey), "Report Job must exist in Quartz Scheduler");
        assertTrue(scheduler.checkExists(triggerKey), "Trigger must exist in Quartz Scheduler");

        Trigger trigger = scheduler.getTrigger(triggerKey);
        assertTrue(trigger instanceof CronTrigger);
        assertEquals("0 0/10 * * * ?", ((CronTrigger) trigger).getCronExpression());
    }

    @Test
    void testTriggerJobNowAndVerifyExecutionLog() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("usr_test_02", "0 0/5 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("TransactionAudit", "AUDIT", null);
        request.setRptCriteriaPayload("{\"startDate\":\"2026-10-01\"}");
        request.setOutputFormat("CSV");
        request.setOlbId("OLB_888");
        request.setUserId("usr_test_02");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);

        // Trigger job execution immediately on-demand
        quartzSchedulerService.triggerJobNow(created.getScheduleId());

        // Wait for Quartz worker thread to complete execution
        Thread.sleep(1500);

        // Verify execution log in SCHEDULE_REPORT_EXECUTION_LOG via MyBatis
        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(created.getScheduleId());
        assertFalse(logs.isEmpty(), "Execution log should be recorded in SCHEDULE_REPORT_EXECUTION_LOG table");

        ScheduleReportExecutionLog latestLog = logs.get(0);
        assertEquals("SUCCESS", latestLog.getStatus());
        assertEquals("UPLOADED", latestLog.getFileStatus());
        assertEquals("S3", latestLog.getStorageProvider());
        assertNotNull(latestLog.getS3ObjectKey());
        assertTrue(latestLog.getS3ObjectKey().contains("AUDIT"));
        assertEquals("CSV", latestLog.getFileFormat());
        assertTrue(latestLog.getFileSizeBytes() > 0);

        // Verify LAST_UPDATED_TS updated in REPORT_SCHEDULE_DETAIL table
        ReportScheduleDetail reloaded = reportScheduleDetailMapper.findById(created.getScheduleId());
        assertNotNull(reloaded.getLastUpdatedTs(), "LAST_UPDATED_TS should be updated after execution");
    }

    @Test
    void testPauseAndResumeJob() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("usr_test_03", "0 0/2 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("InventoryReport", "INVENTORY", null);

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);

        TriggerKey triggerKey = TriggerKey.triggerKey("REPORT_JOB_" + created.getScheduleId() + "_trigger", "INVENTORY");

        // Pause
        quartzSchedulerService.pauseJob(created.getScheduleId());
        Trigger.TriggerState pausedState = scheduler.getTriggerState(triggerKey);
        assertEquals(Trigger.TriggerState.PAUSED, pausedState);

        ReportScheduleDetail pausedSchedule = reportScheduleDetailMapper.findById(created.getScheduleId());
        assertEquals("PAUSED", pausedSchedule.getStatus());

        // Resume
        quartzSchedulerService.resumeJob(created.getScheduleId());
        Trigger.TriggerState resumedState = scheduler.getTriggerState(triggerKey);
        assertEquals(Trigger.TriggerState.NORMAL, resumedState);

        ReportScheduleDetail resumedSchedule = reportScheduleDetailMapper.findById(created.getScheduleId());
        assertEquals("ACTIVE", resumedSchedule.getStatus());
    }

    @Test
    void testUpdateAndReschedule() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("usr_test_04", "0 0/5 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("OriginalReport", "REPORTS", null);

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);

        // Update cron expression
        ReportScheduleDetail updateInfo = new ReportScheduleDetail();
        updateInfo.setCronExpression("0 0/30 * * * ?");

        ReportScheduleRequest updateRequest = new ReportScheduleRequest();
        updateRequest.setReportName("UpdatedReportName");
        updateRequest.setOutputFormat("EXCEL");

        quartzSchedulerService.updateAndReschedule(created.getScheduleId(), updateInfo, updateRequest);

        TriggerKey triggerKey = TriggerKey.triggerKey("REPORT_JOB_" + created.getScheduleId() + "_trigger", "REPORTS");
        CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
        assertEquals("0 0/30 * * * ?", trigger.getCronExpression());

        ReportScheduleDetail reloaded = reportScheduleDetailMapper.findById(created.getScheduleId());
        assertEquals("0 0/30 * * * ?", reloaded.getCronExpression());
        assertEquals("UpdatedReportName", reloaded.getRequest().getReportName());
    }

    @Test
    void testSyncAllActiveSchedulesFromDb() throws Exception {
        // Direct DB insert via MyBatis without scheduling
        ReportScheduleDetail s1 = new ReportScheduleDetail("u1", "0 0 1 * * ?", "ACTIVE");
        reportScheduleDetailMapper.insert(s1);
        ReportScheduleRequest r1 = new ReportScheduleRequest("BatchReport1", "BATCH", s1.getScheduleId());
        reportScheduleRequestMapper.insert(r1);

        ReportScheduleDetail s2 = new ReportScheduleDetail("u2", "0 0 2 * * ?", "ACTIVE");
        reportScheduleDetailMapper.insert(s2);
        ReportScheduleRequest r2 = new ReportScheduleRequest("BatchReport2", "BATCH", s2.getScheduleId());
        reportScheduleRequestMapper.insert(r2);

        // Run sync
        int count = quartzSchedulerService.syncAllActiveSchedulesFromDb();
        assertTrue(count >= 2);

        assertTrue(scheduler.checkExists(JobKey.jobKey("REPORT_JOB_" + s1.getScheduleId(), "BATCH")));
        assertTrue(scheduler.checkExists(JobKey.jobKey("REPORT_JOB_" + s2.getScheduleId(), "BATCH")));
    }

    @Test
    void testMultiInstanceExecutionLockMutualExclusion() throws Exception {
        // 1. Create schedule and request
        ReportScheduleDetail schedule = new ReportScheduleDetail("multi_user", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("ClusterReport", "CLUSTER_TEST", null);
        request.setProcessingStatus("QUEUED");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // 2. Instance A claims execution lock
        int instanceALock = reportScheduleRequestMapper.claimExecutionLock(scheduleId);
        assertEquals(1, instanceALock, "Instance A must successfully claim the execution lock");

        // Verify status in DB is now PROCESSING
        assertEquals("PROCESSING", reportScheduleRequestMapper.findByScheduleId(scheduleId).getProcessingStatus());

        // 3. Instance B (concurrent running instance) attempts to claim lock for the same job
        int instanceBLock = reportScheduleRequestMapper.claimExecutionLock(scheduleId);
        assertEquals(0, instanceBLock, "Instance B must NOT be able to claim lock while Instance A is executing");

        // 4. Instance A completes call and releases lock
        reportScheduleRequestMapper.releaseExecutionLock(scheduleId, "SUCCESS");
        assertEquals("SUCCESS", reportScheduleRequestMapper.findByScheduleId(scheduleId).getProcessingStatus());

        // 5. Subsequent run can claim the lock again
        int nextCycleLock = reportScheduleRequestMapper.claimExecutionLock(scheduleId);
        assertEquals(1, nextCycleLock, "Next scheduled cycle should be able to claim lock after release");
        reportScheduleRequestMapper.releaseExecutionLock(scheduleId, "SUCCESS");
    }

    @Test
    void testConcurrentTriggerOnlyOneInstanceInitiatesCall() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("cluster_user", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("ConcurrentReport", "CONCURRENT", null);
        request.setRptCriteriaPayload("{\"batch\":1}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // Simulate two instances triggering simultaneously using two threads
        java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(2);
        java.util.concurrent.CountDownLatch startLatch = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch finishLatch = new java.util.concurrent.CountDownLatch(2);

        for (int i = 0; i < 2; i++) {
            executor.submit(() -> {
                try {
                    startLatch.await();
                    quartzSchedulerService.triggerJobNow(scheduleId);
                } catch (Exception e) {
                    // ignore
                } finally {
                    finishLatch.countDown();
                }
            });
        }

        // Release both threads simultaneously
        startLatch.countDown();
        finishLatch.await();
        executor.shutdown();

        // Wait for execution to settle
        Thread.sleep(1500);

        // Verify only ONE execution log was recorded because the second instance was locked out
        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertEquals(1, logs.size(), "Exactly ONE service instance should initiate the call and execute the report");
        assertEquals("SUCCESS", logs.get(0).getStatus());
    }

    @Test
    void testJobRecoveryFlagAndMisfirePolicyConfiguration() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("failover_user", "0 0/15 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("FailoverReport", "FAILOVER", null);

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        JobKey jobKey = JobKey.jobKey("REPORT_JOB_" + scheduleId, "FAILOVER");
        TriggerKey triggerKey = TriggerKey.triggerKey("REPORT_JOB_" + scheduleId + "_trigger", "FAILOVER");

        JobDetail jobDetail = scheduler.getJobDetail(jobKey);
        assertNotNull(jobDetail);
        assertTrue(jobDetail.requestsRecovery(), "JobDetail must have requestsRecovery=true for node crash recovery");

        CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
        assertNotNull(trigger);
        assertEquals(CronTrigger.MISFIRE_INSTRUCTION_FIRE_ONCE_NOW, trigger.getMisfireInstruction(),
                "Trigger must have MISFIRE_INSTRUCTION_FIRE_ONCE_NOW for zero job loss during restarts");
    }

    @Test
    void testStaleLockFailoverRecoveryAfterNodeCrash() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("crash_user", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("CrashRecoveryReport", "CRASH_TEST", null);
        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // 1. Dead pod claimed lock
        reportScheduleRequestMapper.claimExecutionLock(scheduleId);
        assertEquals("PROCESSING", reportScheduleRequestMapper.findByScheduleId(scheduleId).getProcessingStatus());

        // 2. Active pod checks lock with recent lease threshold (lock is fresh, so should be rejected)
        java.time.LocalDateTime recentThreshold = java.time.LocalDateTime.now().minusMinutes(10);
        int lockAttemptWhileActive = reportScheduleRequestMapper.claimExecutionLockWithTimeout(scheduleId, recentThreshold);
        assertEquals(0, lockAttemptWhileActive, "Should not claim lock if active instance is within lease window");

        // 3. Simulate lock is older than staleThreshold (dead pod abandoned lock)
        java.time.LocalDateTime staleThreshold = java.time.LocalDateTime.now().plusMinutes(1);
        int lockRecovered = reportScheduleRequestMapper.claimExecutionLockWithTimeout(scheduleId, staleThreshold);
        assertEquals(1, lockRecovered, "Surviving instance must break stale lease and acquire lock after node crash");

        // 4. Test Quartz failover force-claim execution lock
        int forceClaim = reportScheduleRequestMapper.forceClaimExecutionLock(scheduleId);
        assertEquals(1, forceClaim, "Quartz failover recovery must be able to force-claim execution lock");
        reportScheduleRequestMapper.releaseExecutionLock(scheduleId, "SUCCESS");
    }

    @Test
    void testGenericHttpWebhookJobExecution() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("webhook_user", "0 0/5 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("NotificationWebhook", "HTTP", null);
        request.setRptCriteriaPayload("{\"url\":\"https://internal.service/api/notify\",\"method\":\"POST\"}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        quartzSchedulerService.triggerJobNow(created.getScheduleId());

        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(created.getScheduleId());
        assertFalse(logs.isEmpty(), "Execution log must be recorded for generic HTTP webhook job");
        assertEquals("SUCCESS", logs.get(0).getStatus());
        assertEquals("NONE", logs.get(0).getStorageProvider());
        assertTrue(logs.get(0).getGeneratedReportId().startsWith("HTTP_"));
    }

    @Test
    void testGenericBeanJobExecution() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("bean_user", "0 0/5 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("CustomTask", "BEAN", null);
        request.setRptCriteriaHeader("quartzSchedulerService");
        request.setRptCriteriaPayload("{\"action\":\"test\"}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        quartzSchedulerService.triggerJobNow(created.getScheduleId());

        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(created.getScheduleId());
        assertFalse(logs.isEmpty(), "Execution log must be recorded for generic Spring bean job");
        assertEquals("SUCCESS", logs.get(0).getStatus());
        assertTrue(logs.get(0).getGeneratedReportId().startsWith("BEAN_"));
    }

    @Test
    void testExpiredScheduleHandling() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("expired_user", "0 0/5 * * * ?", "ACTIVE");
        schedule.setExpiresAt(java.time.LocalDateTime.now().minusDays(1)); // expired yesterday
        ReportScheduleRequest request = new ReportScheduleRequest("ExpiredReport", "REPORT", null);

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        ReportScheduleDetail reloaded = reportScheduleDetailMapper.findById(created.getScheduleId());

        assertEquals("EXPIRED", reloaded.getStatus(), "Expired schedule must be marked EXPIRED without throwing in Quartz");
        assertFalse(scheduler.checkExists(JobKey.jobKey("REPORT_JOB_" + created.getScheduleId(), "REPORT")));
    }

    @Test
    void testBackfillDiscreteMissedSlices() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("backfill_user", "0 0 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("HourlyAudit", "AUDIT", null);
        request.setRptCriteriaPayload("{\"metric\":\"backfill_test\"}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        java.time.LocalDateTime from = java.time.LocalDateTime.of(2026, 10, 20, 10, 0, 0);
        java.time.LocalDateTime to = java.time.LocalDateTime.of(2026, 10, 20, 13, 30, 0);

        List<String> replayed = quartzSchedulerService.backfillSchedule(scheduleId, from, to, "{\"backfillSlice\":true}");

        assertEquals(3, replayed.size(), "Should have replayed exactly 3 missed hourly slices (11:00, 12:00, 13:00)");

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertEquals(3, logs.size(), "Every replayed slice must have an entry in SCHEDULE_REPORT_EXECUTION_LOG");

        for (ScheduleReportExecutionLog logEntry : logs) {
            assertEquals("SUCCESS", logEntry.getStatus());
            assertTrue(logEntry.getGeneratedReportId().contains("backfill"));
        }

        ReportScheduleDetail reloaded = reportScheduleDetailMapper.findById(scheduleId);
        assertEquals(to, reloaded.getLastUpdatedTs());
    }

    @Test
    void testAutoGapCatchupWindowDetection() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("gap_user", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("GapReport", "REPORT", null);
        request.setRptCriteriaPayload("{\"base\":\"data\"}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // Simulate last execution occurred 2 hours ago (downtime gap)
        java.time.LocalDateTime previousRun = java.time.LocalDateTime.now().minusHours(2);
        reportScheduleDetailMapper.updateExecutionTimes(scheduleId, previousRun, null);

        // Trigger job now (simulating restart catch-up)
        quartzSchedulerService.triggerJobNow(scheduleId);
        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertFalse(logs.isEmpty());
        assertEquals("SUCCESS", logs.get(0).getStatus());

        // Verify LAST_UPDATED_TS updated to recent time
        ReportScheduleDetail reloaded = reportScheduleDetailMapper.findById(scheduleId);
        assertTrue(reloaded.getLastUpdatedTs().isAfter(previousRun));
    }

    @Test
    void testImmediateEntryAndFileStatusLifecycleOnJobTrigger() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("user_file_status", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("HourlyReportLifecycle", "REPORT", null);
        request.setOutputFormat("PDF");
        request.setRptCriteriaPayload("{\"segment\":\"enterprise\"}");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // 1. First trigger (e.g. Hour 1)
        quartzSchedulerService.triggerJobNow(scheduleId);
        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logsRun1 = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertEquals(1, logsRun1.size(), "First trigger must record exactly 1 execution log entry");
        ScheduleReportExecutionLog firstRunLog = logsRun1.get(0);
        assertEquals("SUCCESS", firstRunLog.getStatus(), "Status must progress to SUCCESS on completion");
        assertEquals("UPLOADED", firstRunLog.getFileStatus(), "File status must be UPLOADED for generated S3 report");
        assertNotNull(firstRunLog.getStartTime(), "Start time must be recorded upon trigger");
        assertNotNull(firstRunLog.getEndTime(), "End time must be recorded upon completion");

        // Verify request file status is also synchronized
        ReportScheduleRequest reqAfterRun1 = reportScheduleRequestMapper.findByScheduleId(scheduleId);
        assertEquals("UPLOADED", reqAfterRun1.getFileStatus(), "Request file status must be updated on completion");

        // 2. Second trigger (e.g. Hour 2 - simulating subsequent hourly runs)
        // Reset lastUpdatedTs slightly so debounce window doesn't block second run
        reportScheduleDetailMapper.updateExecutionTimes(scheduleId, java.time.LocalDateTime.now().minusSeconds(10), null);
        quartzSchedulerService.triggerJobNow(scheduleId);
        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logsRun2 = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertEquals(2, logsRun2.size(), "Second trigger must append a 2nd distinct entry (e.g. 24 entries per day for hourly runs)");
        assertEquals("SUCCESS", logsRun2.get(0).getStatus());
        assertEquals("UPLOADED", logsRun2.get(0).getFileStatus());
        assertEquals("SUCCESS", logsRun2.get(1).getStatus());
        assertEquals("UPLOADED", logsRun2.get(1).getFileStatus());
        assertNotEquals(logsRun2.get(0).getExecutionId(), logsRun2.get(1).getExecutionId(), "Each triggering must have its own unique execution ID");
    }

    @org.springframework.boot.test.context.TestConfiguration
    static class TestEdgeCaseConfig {
        @org.springframework.context.annotation.Bean
        public TestFailingService failingService() {
            return new TestFailingService();
        }
    }

    public static class TestFailingService {
        public void throwHugeException() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 500; i++) {
                sb.append("CRITICAL_FAILURE_SEGMENT_");
            }
            throw new RuntimeException(sb.toString());
        }
    }

    @Test
    void testHugeErrorMessageTruncationAndLockReleaseOnFailure() throws Exception {
        ReportScheduleDetail schedule = new ReportScheduleDetail("fail_user", "0 0/10 * * * ?", "ACTIVE");
        ReportScheduleRequest request = new ReportScheduleRequest("throwHugeException", "BEAN", null);
        request.setRptCriteriaHeader("failingService");

        ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, request);
        Long scheduleId = created.getScheduleId();

        // Trigger job execution that fails with huge exception
        quartzSchedulerService.triggerJobNow(scheduleId);
        Thread.sleep(1500);

        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertFalse(logs.isEmpty(), "Execution log must be created even on failure");
        ScheduleReportExecutionLog failLog = logs.get(0);
        assertEquals("FAILED", failLog.getStatus());
        assertEquals("FAILED", failLog.getFileStatus());
        assertNotNull(failLog.getErrorMessage());
        assertTrue(failLog.getErrorMessage().length() <= 3900, "Error message must be safely truncated under DB column limit");
        assertTrue(failLog.getErrorMessage().contains("CRITICAL_FAILURE_SEGMENT_"));

        // Verify request table is marked FAILED / FAILED
        ReportScheduleRequest req = reportScheduleRequestMapper.findByScheduleId(scheduleId);
        assertEquals("FAILED", req.getStatus());
        assertEquals("FAILED", req.getFileStatus());

        // Verify distributed lock was released so another instance/run can acquire it
        int lockCanBeClaimedAgain = reportScheduleRequestMapper.claimExecutionLock(scheduleId);
        assertEquals(1, lockCanBeClaimedAgain, "Execution lock MUST be released in finally block even after failure");
        reportScheduleRequestMapper.releaseExecutionLock(scheduleId, "FAILED");
    }

    @Test
    void testMissingRequestRecordHandledGracefullyWithoutLockLeak() throws Exception {
        // Create schedule detail ONLY, without any request record
        ReportScheduleDetail schedule = new ReportScheduleDetail("orphan_user", "0 0/10 * * * ?", "ACTIVE");
        reportScheduleDetailMapper.insert(schedule);
        Long scheduleId = schedule.getScheduleId();

        // Trigger job - should safely abort without leaking locks or throwing uncaught exceptions
        assertDoesNotThrow(() -> {
            quartzSchedulerService.triggerJobNow(scheduleId);
            Thread.sleep(1000);
        });

        // No execution logs should be created for non-existent request
        List<ScheduleReportExecutionLog> logs = scheduleReportExecutionLogMapper.findByScheduleId(scheduleId);
        assertTrue(logs.isEmpty());
    }
}

