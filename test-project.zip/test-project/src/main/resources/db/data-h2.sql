-- =============================================================================
-- Sample Database Seed & Test Records for H2 (Dev & Testing Environment)
-- Tables: REPORT_SCHEDULE_DETAIL, REPORT_SCHEDULE_REQUEST, SCHEDULE_REPORT_EXECUTION_LOG
-- =============================================================================

-- Clean up existing sample data if re-running
DELETE FROM SCHEDULE_REPORT_EXECUTION_LOG;
DELETE FROM REPORT_SCHEDULE_REQUEST;
DELETE FROM REPORT_SCHEDULE_DETAIL;

-- -----------------------------------------------------------------------------
-- 1. Table: REPORT_SCHEDULE_DETAIL (10 diverse schedule configurations)
-- -----------------------------------------------------------------------------
INSERT INTO REPORT_SCHEDULE_DETAIL (
    SCHEDULE_ID, USER_ID, CRON_EXPRESSION, STATUS, NEXT_RUN_TIME, START_AT, EXPIRES_AT,
    CREATED_DATE, CREATED_BY, UPDATED_BY, CREATED_AT, UPDATED_AT, PREVIOUS_SCHEDULE_ID,
    SYSTEM_DEFINED, LAST_UPDATED_TS
) VALUES 
-- 1) Active 15-minute recurring transaction summary
(1, 'usr_admin_01', '0 0/15 * * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'admin', 'admin', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 2) Active 5-minute security and compliance audit
(2, 'usr_sec_audit', '0 0/5 * * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'security_lead', 'security_lead', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 3) Active monthly financial statement (1st of month at 1:00 AM)
(3, 'usr_controller', '0 0 1 1 * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'finance_dept', 'finance_dept', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 4) Active 30-minute generic HTTP webhook dispatcher
(4, 'usr_integration_04', '0 0/30 * * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'integration_team', 'integration_team', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 5) Active hourly Spring Bean job handler
(5, 'usr_devops_05', '0 0 * * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'devops', 'devops', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 6) Paused schedule (for testing pause/resume state management)
(6, 'usr_analyst_06', '0 0 8 * * ?', 'PAUSED', NULL, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'analyst_bob', 'analyst_bob', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 7) Expired schedule (historical date window in the past)
(7, 'usr_contractor_07', '0 0/10 * * * ?', 'EXPIRED', NULL, TIMESTAMP '2026-08-01 00:00:00', TIMESTAMP '2026-09-01 00:00:00',
 TIMESTAMP '2026-08-01 00:00:00', 'contractor_07', 'scheduler_service', TIMESTAMP '2026-08-01 00:00:00', TIMESTAMP '2026-09-01 00:00:00', NULL, 'N', TIMESTAMP '2026-08-31 23:55:00'),

-- 8) Active high-volume report (used to test concurrent execution locking)
(8, 'usr_cluster_nodeA', '0 0/10 * * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'node_admin', 'node-1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 9) Active schedule with recent failed execution and retry logs
(9, 'usr_settlement_09', '0 0 4 * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'settlement_ops', 'scheduler_service', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'N', CURRENT_TIMESTAMP),

-- 10) Active system-defined periodic maintenance & cleanup daemon
(10, 'system_daemon', '0 0 3 * * ?', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL,
 CURRENT_TIMESTAMP, 'system', 'system', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL, 'Y', CURRENT_TIMESTAMP);


-- -----------------------------------------------------------------------------
-- 2. Table: REPORT_SCHEDULE_REQUEST (Associated parameters, payloads & file status)
-- -----------------------------------------------------------------------------
INSERT INTO REPORT_SCHEDULE_REQUEST (
    REQUEST_ID, REPORT_NAME, REPORT_TYPE, OLB_ID, USER_ID, CLIENT_ID, PAGE_ID,
    RPT_CRITERIA_PAYLOAD, RPT_CRITERIA_HEADER, OUTPUT_FORMAT, STATUS, FILE_STATUS, CREATED_AT,
    UPDATED_BY, CREATED_BY, UPDATED_AT, PREVIOUS_REQUEST_ID, SCHEDULE_ID, PROCESSING_STATUS
) VALUES
-- 1) Transaction Summary (PDF, Queued, FileStatus: READY)
(1, 'Daily Transaction Summary', 'TRANSACTION_SUMMARY', 'OLB_1001', 'usr_admin_01', 'CL_5001', 'PG_TRANSACTIONS',
 '{"accountType":"CHECKING","minAmount":100,"currency":"USD"}',
 '{"Title":"Daily Transaction Report","Department":"Retail Banking"}',
 'PDF', 'READY', 'READY', CURRENT_TIMESTAMP, 'admin', 'admin', CURRENT_TIMESTAMP, NULL, 1, 'QUEUED'),

-- 2) Security Access Audit Log (CSV, Queued, FileStatus: READY)
(2, 'Security Access Audit Log', 'AUDIT', 'OLB_2002', 'usr_sec_audit', 'CL_9002', 'PG_SECURITY_AUDIT',
 '{"eventTypes":["LOGIN_FAILURE","PRIVILEGE_ESCALATION"],"severity":"HIGH"}',
 '{"ComplianceStandard":"SOC2-Type2","Classification":"CONFIDENTIAL"}',
 'CSV', 'READY', 'READY', CURRENT_TIMESTAMP, 'security_lead', 'security_lead', CURRENT_TIMESTAMP, NULL, 2, 'QUEUED'),

-- 3) Monthly General Ledger & Balance Sheet (EXCEL, Queued, FileStatus: READY)
(3, 'Monthly Balance Sheet & Ledger', 'FINANCIAL', 'OLB_3003', 'usr_controller', 'CL_3003', 'PG_GL_RECON',
 '{"fiscalYear":2026,"period":"M10","includeAdjustments":true}',
 '{"CostCenter":"CORP_FINANCE","Auditor":"External"}',
 'EXCEL', 'READY', 'READY', CURRENT_TIMESTAMP, 'finance_dept', 'finance_dept', CURRENT_TIMESTAMP, NULL, 3, 'QUEUED'),

-- 4) Generic HTTP Webhook (JSON, Queued, FileStatus: NOT_APPLICABLE)
(4, 'ERP Sync Webhook Dispatch', 'HTTP', 'OLB_4004', 'usr_integration_04', 'CL_4004', 'PG_ERP_SYNC',
 '{"url":"https://api.erp.internal/v1/settlements/notify","method":"POST","retryPolicy":{"maxRetries":3}}',
 '{"X-Gateway-Auth":"Bearer token_99xyz","Content-Type":"application/json"}',
 'JSON', 'READY', 'NOT_APPLICABLE', CURRENT_TIMESTAMP, 'integration_team', 'integration_team', CURRENT_TIMESTAMP, NULL, 4, 'QUEUED'),

-- 5) Generic Spring Bean Job Handler (JSON, Queued, FileStatus: NOT_APPLICABLE)
(5, 'syncAllActiveSchedulesFromDb', 'BEAN', 'OLB_5005', 'usr_devops_05', 'CL_5005', 'PG_SYSTEM_JOBS',
 '{"mode":"REFRESH","forceSync":false}',
 'quartzSchedulerService',
 'JSON', 'READY', 'NOT_APPLICABLE', CURRENT_TIMESTAMP, 'devops', 'devops', CURRENT_TIMESTAMP, NULL, 5, 'QUEUED'),

-- 6) Marketing Lead Report (PDF, Paused, FileStatus: PAUSED)
(6, 'Marketing Lead Conversion Report', 'INVENTORY', 'OLB_6006', 'usr_analyst_06', 'CL_6006', 'PG_MKTG_LEADS',
 '{"campaignId":"Q3_PROMO","region":"NA"}',
 '{"Status":"ON_HOLD"}',
 'PDF', 'PAUSED', 'PAUSED', CURRENT_TIMESTAMP, 'analyst_bob', 'analyst_bob', CURRENT_TIMESTAMP, NULL, 6, 'PAUSED'),

-- 7) Temporary Data Migration Audit (CSV, Expired/Completed, FileStatus: EXPIRED)
(7, 'Temporary Data Migration Audit', 'AUDIT', 'OLB_7007', 'usr_contractor_07', 'CL_7007', 'PG_MIGRATION',
 '{"batch":"MIG_PHASE_1","cutoffDate":"2026-08-31"}',
 '{"Project":"Oracle23cUpgrade"}',
 'CSV', 'EXPIRED', 'EXPIRED', TIMESTAMP '2026-08-01 00:00:00', 'scheduler_service', 'contractor_07', TIMESTAMP '2026-09-01 00:00:00', NULL, 7, 'COMPLETED'),

-- 8) End-of-Day Multi-Branch Settlement (PDF, Currently PROCESSING to test lock, FileStatus: GENERATING)
(8, 'End-of-Day Multi-Branch Settlement', 'REPORT', 'OLB_8008', 'usr_cluster_nodeA', 'CL_8008', 'PG_BRANCH_SETTLEMENT',
 '{"branches":["BR_01","BR_02","BR_03"],"reconcileMode":"PARALLEL"}',
 '{"LockedByNode":"node-1","LockLeaseMinutes":10}',
 'PDF', 'PROCESSING', 'GENERATING', CURRENT_TIMESTAMP, 'node-1', 'node_admin', CURRENT_TIMESTAMP, NULL, 8, 'PROCESSING'),

-- 9) Swift Interbank Wire Recon (PDF, Failed status with retry count, FileStatus: FAILED)
(9, 'Swift Interbank Wire Recon', 'FINANCIAL', 'OLB_9009', 'usr_settlement_09', 'CL_9009', 'PG_SWIFT_WIRE',
 '{"network":"SWIFT","messageType":"MT103","includeFailedOnly":true}',
 '{"TargetSwiftBic":"CHASUS33"}',
 'PDF', 'READY', 'FAILED', CURRENT_TIMESTAMP, 'scheduler_service', 'settlement_ops', CURRENT_TIMESTAMP, NULL, 9, 'FAILED'),

-- 10) Storage Pruning & S3 Archive Reconciler (JSON, Queued, FileStatus: READY)
(10, 'Storage Pruning and S3 Archive Reconciler', 'BATCH', 'OLB_SYSTEM', 'system_daemon', 'CL_SYSTEM', 'PG_SYSTEM_MAINTENANCE',
 '{"retentionDays":90,"purgeTemporaryReports":true,"archiveToGlacier":true}',
 '{"SystemModule":"StorageManager"}',
 'JSON', 'READY', 'READY', CURRENT_TIMESTAMP, 'system', 'system', CURRENT_TIMESTAMP, NULL, 10, 'QUEUED');


-- -----------------------------------------------------------------------------
-- 3. Table: SCHEDULE_REPORT_EXECUTION_LOG (Execution history, status & file status)
-- -----------------------------------------------------------------------------
INSERT INTO SCHEDULE_REPORT_EXECUTION_LOG (
    EXECUTION_ID, SCHEDULE_ID, REPORT_ID, START_TIME, END_TIME, STATUS, FILE_STATUS,
    GENERATED_REPORT_ID, RECORD_COUNT, STORAGE_PROVIDER, S3_BUCKET, S3_OBJECT_KEY,
    FILE_NAME, FILE_FORMAT, FILE_SIZE_BYTES, REPORT_TYPE, OLB_ID, USER_ID, CLIENT_ID,
    PAGE_ID, RETRY_COUNT, ERROR_MESSAGE, CREATE_AT, UPDATED_AT
) VALUES
-- 101) Successful S3 PDF upload for Transaction Summary
(101, 1, 'RPT_TXN_001', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'UPLOADED',
 'GEN_RPT_20261020_001', 1450, 'S3', 'test-bucket',
 'reports/TRANSACTION_SUMMARY/2026/10/Daily_Transaction_Summary_20261020_140000.pdf',
 'Daily_Transaction_Summary_20261020_140000.pdf', 'PDF', 1048576, 'TRANSACTION_SUMMARY',
 'OLB_1001', 'usr_admin_01', 'CL_5001', 'PG_TRANSACTIONS', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 102) Successful S3 CSV upload for Security Access Audit
(102, 2, 'RPT_AUDIT_002', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'UPLOADED',
 'GEN_AUDIT_20261020_002', 480, 'S3', 'test-bucket',
 'reports/AUDIT/2026/10/Security_Access_Audit_20261020_150000.csv',
 'Security_Access_Audit_20261020_150000.csv', 'CSV', 327680, 'AUDIT',
 'OLB_2002', 'usr_sec_audit', 'CL_9002', 'PG_SECURITY_AUDIT', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 103) Successful S3 Excel upload for Monthly Ledger
(103, 3, 'RPT_FIN_003', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'UPLOADED',
 'GEN_FIN_20261001_003', 12500, 'S3', 'test-bucket',
 'reports/FINANCIAL/2026/10/Monthly_Balance_Sheet_20261001.xlsx',
 'Monthly_Balance_Sheet_20261001.xlsx', 'EXCEL', 4194304, 'FINANCIAL',
 'OLB_3003', 'usr_controller', 'CL_3003', 'PG_GL_RECON', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 104) Successful HTTP Webhook invocation (Storage: NONE, FileStatus: NOT_APPLICABLE)
(104, 4, 'HTTP_DISPATCH_004', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'NOT_APPLICABLE',
 'HTTP_8a3f912c', 1, 'NONE', NULL, NULL,
 NULL, 'JSON', 128, 'HTTP',
 'OLB_4004', 'usr_integration_04', 'CL_4004', 'PG_ERP_SYNC', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 105) Successful Spring Bean task execution (Storage: NONE, FileStatus: NOT_APPLICABLE)
(105, 5, 'BEAN_TASK_005', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'NOT_APPLICABLE',
 'BEAN_c5d6e7f8', 1, 'NONE', NULL, NULL,
 NULL, 'JSON', 64, 'BEAN',
 'OLB_5005', 'usr_devops_05', 'CL_5005', 'PG_SYSTEM_JOBS', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 106) Previous run log for paused Marketing Lead report
(106, 6, 'RPT_LEADS_006', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'UPLOADED',
 'GEN_LEADS_20261019_006', 720, 'S3', 'test-bucket',
 'reports/INVENTORY/2026/10/Marketing_Lead_Conversion_20261019.pdf',
 'Marketing_Lead_Conversion_20261019.pdf', 'PDF', 655360, 'INVENTORY',
 'OLB_6006', 'usr_analyst_06', 'CL_6006', 'PG_MKTG_LEADS', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 107) Historical high-volume migration log for expired schedule
(107, 7, 'RPT_MIG_007', TIMESTAMP '2026-08-31 23:50:00', TIMESTAMP '2026-08-31 23:55:00', 'SUCCESS', 'UPLOADED',
 'GEN_MIG_20260831_007', 500000, 'S3', 'test-bucket',
 'reports/AUDIT/2026/08/Data_Migration_Final_20260831.csv',
 'Data_Migration_Final_20260831.csv', 'CSV', 15728640, 'AUDIT',
 'OLB_7007', 'usr_contractor_07', 'CL_7007', 'PG_MIGRATION', 0, NULL, TIMESTAMP '2026-08-31 23:55:00', TIMESTAMP '2026-08-31 23:55:00'),

-- 108) Currently in-progress execution record (testing concurrency lock, FileStatus: GENERATING)
(108, 8, 'RPT_SETTLE_008', CURRENT_TIMESTAMP, NULL, 'IN_PROGRESS', 'GENERATING',
 NULL, NULL, 'S3', 'test-bucket', NULL,
 NULL, 'PDF', NULL, 'REPORT',
 'OLB_8008', 'usr_cluster_nodeA', 'CL_8008', 'PG_BRANCH_SETTLEMENT', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 109) Failed execution record with retry count and error diagnostics
(109, 9, 'RPT_SWIFT_009', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'FAILED', 'FAILED',
 NULL, 0, 'S3', 'test-bucket', NULL,
 NULL, 'PDF', 0, 'FINANCIAL',
 'OLB_9009', 'usr_settlement_09', 'CL_9009', 'PG_SWIFT_WIRE', 3,
 'Connection to upstream NetApp ONTAP S3 gateway timed out after 30000ms: java.net.SocketTimeoutException: Read timed out',
 CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- 110) Successful system batch maintenance execution
(110, 10, 'RPT_SYS_CLEANUP_010', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'SUCCESS', 'UPLOADED',
 'GEN_SYS_20261020_010', 350, 'S3', 'test-bucket',
 'reports/BATCH/2026/10/Storage_Pruning_Report_20261020.json',
 'Storage_Pruning_Report_20261020.json', 'JSON', 49152, 'BATCH',
 'OLB_SYSTEM', 'system_daemon', 'CL_SYSTEM', 'PG_SYSTEM_MAINTENANCE', 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
