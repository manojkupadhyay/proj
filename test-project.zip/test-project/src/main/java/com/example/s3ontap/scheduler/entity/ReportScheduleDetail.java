package com.example.s3ontap.scheduler.entity;

import java.time.LocalDateTime;

public class ReportScheduleDetail {

    private Long scheduleId;
    private String userId;
    private String cronExpression;
    private String status = "ACTIVE";
    private LocalDateTime nextRunTime;
    private LocalDateTime startAt;
    private LocalDateTime expiresAt;
    private LocalDateTime createdDate;
    private String createdBy;
    private String updatedBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long previousScheduleId;
    private String systemDefined = "N";
    private LocalDateTime lastUpdatedTs;

    // Associated request details
    private ReportScheduleRequest request;

    public ReportScheduleDetail() {
    }

    public ReportScheduleDetail(String userId, String cronExpression, String status) {
        this.userId = userId;
        this.cronExpression = cronExpression;
        this.status = status != null ? status : "ACTIVE";
    }

    // Getters and Setters
    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getNextRunTime() {
        return nextRunTime;
    }

    public void setNextRunTime(LocalDateTime nextRunTime) {
        this.nextRunTime = nextRunTime;
    }

    public LocalDateTime getStartAt() {
        return startAt;
    }

    public void setStartAt(LocalDateTime startAt) {
        this.startAt = startAt;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getPreviousScheduleId() {
        return previousScheduleId;
    }

    public void setPreviousScheduleId(Long previousScheduleId) {
        this.previousScheduleId = previousScheduleId;
    }

    public String getSystemDefined() {
        return systemDefined;
    }

    public void setSystemDefined(String systemDefined) {
        this.systemDefined = systemDefined;
    }

    public LocalDateTime getLastUpdatedTs() {
        return lastUpdatedTs;
    }

    public void setLastUpdatedTs(LocalDateTime lastUpdatedTs) {
        this.lastUpdatedTs = lastUpdatedTs;
    }

    public ReportScheduleRequest getRequest() {
        return request;
    }

    public void setRequest(ReportScheduleRequest request) {
        this.request = request;
    }
}
