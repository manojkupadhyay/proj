package com.example.s3ontap.scheduler.mapper;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface ReportScheduleDetailMapper {

    @Insert("INSERT INTO REPORT_SCHEDULE_DETAIL (USER_ID, CRON_EXPRESSION, STATUS, NEXT_RUN_TIME, START_AT, EXPIRES_AT, " +
            "CREATED_DATE, CREATED_BY, UPDATED_BY, CREATED_AT, UPDATED_AT, PREVIOUS_SCHEDULE_ID, SYSTEM_DEFINED, LAST_UPDATED_TS) " +
            "VALUES (#{userId}, #{cronExpression}, #{status}, #{nextRunTime}, #{startAt}, #{expiresAt}, " +
            "CURRENT_TIMESTAMP, #{createdBy}, #{updatedBy}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, #{previousScheduleId}, #{systemDefined}, #{lastUpdatedTs})")
    @Options(useGeneratedKeys = true, keyProperty = "scheduleId", keyColumn = "SCHEDULE_ID")
    int insert(ReportScheduleDetail schedule);

    @Update("UPDATE REPORT_SCHEDULE_DETAIL SET CRON_EXPRESSION = #{cronExpression}, STATUS = #{status}, " +
            "NEXT_RUN_TIME = #{nextRunTime}, START_AT = #{startAt}, EXPIRES_AT = #{expiresAt}, UPDATED_BY = #{updatedBy}, " +
            "PREVIOUS_SCHEDULE_ID = #{previousScheduleId}, SYSTEM_DEFINED = #{systemDefined}, " +
            "UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int update(ReportScheduleDetail schedule);

    @Update("UPDATE REPORT_SCHEDULE_DETAIL SET LAST_UPDATED_TS = #{fireTime}, NEXT_RUN_TIME = #{nextRunTime}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int updateExecutionTimes(@Param("scheduleId") Long scheduleId, @Param("fireTime") LocalDateTime fireTime, @Param("nextRunTime") LocalDateTime nextRunTime);

    @Update("UPDATE REPORT_SCHEDULE_DETAIL SET STATUS = #{status}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int updateStatus(@Param("scheduleId") Long scheduleId, @Param("status") String status);

    @Delete("DELETE FROM REPORT_SCHEDULE_DETAIL WHERE SCHEDULE_ID = #{scheduleId}")
    int deleteById(Long scheduleId);

    @Delete("DELETE FROM REPORT_SCHEDULE_DETAIL")
    int deleteAll();

    @Select("SELECT * FROM REPORT_SCHEDULE_DETAIL WHERE SCHEDULE_ID = #{scheduleId}")
    @Results(id = "reportScheduleResultMap", value = {
        @Result(property = "scheduleId", column = "SCHEDULE_ID", id = true),
        @Result(property = "userId", column = "USER_ID"),
        @Result(property = "cronExpression", column = "CRON_EXPRESSION"),
        @Result(property = "status", column = "STATUS"),
        @Result(property = "nextRunTime", column = "NEXT_RUN_TIME"),
        @Result(property = "startAt", column = "START_AT"),
        @Result(property = "expiresAt", column = "EXPIRES_AT"),
        @Result(property = "createdDate", column = "CREATED_DATE"),
        @Result(property = "createdBy", column = "CREATED_BY"),
        @Result(property = "updatedBy", column = "UPDATED_BY"),
        @Result(property = "createdAt", column = "CREATED_AT"),
        @Result(property = "updatedAt", column = "UPDATED_AT"),
        @Result(property = "previousScheduleId", column = "PREVIOUS_SCHEDULE_ID"),
        @Result(property = "systemDefined", column = "SYSTEM_DEFINED"),
        @Result(property = "lastUpdatedTs", column = "LAST_UPDATED_TS"),
        @Result(property = "request", column = "SCHEDULE_ID",
                one = @One(select = "com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper.findByScheduleId"))
    })
    ReportScheduleDetail findById(Long scheduleId);

    @Select("SELECT * FROM REPORT_SCHEDULE_DETAIL ORDER BY SCHEDULE_ID ASC")
    @ResultMap("reportScheduleResultMap")
    List<ReportScheduleDetail> findAll();

    @Select("SELECT * FROM REPORT_SCHEDULE_DETAIL WHERE STATUS = 'ACTIVE' ORDER BY SCHEDULE_ID ASC")
    @ResultMap("reportScheduleResultMap")
    List<ReportScheduleDetail> findAllActive();

    @Select("SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM REPORT_SCHEDULE_DETAIL WHERE SCHEDULE_ID = #{scheduleId}")
    boolean existsById(Long scheduleId);

    @Select("SELECT COUNT(*) FROM REPORT_SCHEDULE_DETAIL")
    long countTotal();

    @Select("SELECT COUNT(*) FROM REPORT_SCHEDULE_DETAIL WHERE STATUS = #{status}")
    long countByStatus(@Param("status") String status);
}
