package com.example.s3ontap.scheduler.job;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import com.example.s3ontap.scheduler.handler.JobExecutionOutcome;
import com.example.s3ontap.scheduler.handler.JobTaskHandler;
import com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Component
@DisallowConcurrentExecution
public class DynamicDatabaseJob implements Job {

    private static final Logger log = LoggerFactory.getLogger(DynamicDatabaseJob.class);

    @Value("${service.instance.id:default-node}")
    private String instanceId;

    @Value("${service.scheduler.lock-lease-minutes:10}")
    private int lockLeaseMinutes;

    @Autowired
    private ReportScheduleDetailMapper reportScheduleDetailMapper;

    @Autowired
    private ReportScheduleRequestMapper reportScheduleRequestMapper;

    @Autowired
    private ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;

    @Autowired
    private JobTaskHandlerRegistry jobTaskHandlerRegistry;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LocalDateTime fireTime = LocalDateTime.now();
        Long scheduleId = context.getMergedJobDataMap().getLong("scheduleId");
        String jobName = context.getJobDetail().getKey().getName();
        String jobGroup = context.getJobDetail().getKey().getGroup();
        boolean manualTrigger = context.getMergedJobDataMap().getBoolean("manualTrigger");

        log.info(">>> Quartz Report Triggered on instance [{}]: Job [{} / {}] for scheduleId: {} at {}", 
                instanceId, jobGroup, jobName, scheduleId, fireTime);

        // Read runtime schedule details from DB table via MyBatis
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            log.warn("Job [{}] triggered on [{}] but scheduleId {} not found in REPORT_SCHEDULE_DETAIL! Skipping.", 
                    jobName, instanceId, scheduleId);
            return;
        }

        // Check if schedule is active
        if (!"ACTIVE".equalsIgnoreCase(schedule.getStatus())) {
            log.info("Job [{}] scheduleId {} status is '{}'. Skipping execution.", 
                    jobName, scheduleId, schedule.getStatus());
            return;
        }

        // De-duplicate rapid concurrent/overlapping triggers across multi-instances within debounce window (5 seconds)
        if (schedule.getLastUpdatedTs() != null && 
            schedule.getLastUpdatedTs().isAfter(fireTime.minusSeconds(5))) {
            log.warn(">>> [Multi-Instance Mutual Exclusion] Job [{}] scheduleId {} was already executed recently at {}. Skipping duplicate trigger.", 
                    jobName, scheduleId, schedule.getLastUpdatedTs());
            return;
        }

        // Read runtime request details from DB table via MyBatis
        ReportScheduleRequest request = schedule.getRequest() != null 
                ? schedule.getRequest() 
                : reportScheduleRequestMapper.findByScheduleId(scheduleId);

        if (request == null) {
            log.error("Job [{}] triggered on [{}] but scheduleId {} has no corresponding REPORT_SCHEDULE_REQUEST record! Cannot execute.", 
                    jobName, instanceId, scheduleId);
            return;
        }

        // -------------------------------------------------------------------------
        // MULTI-INSTANCE DISTRIBUTED COORDINATION & FAILOVER RECOVERY:
        // Atomically claim the execution lock in the database so ONLY ONE instance initiates the call.
        // Handles Quartz failover recovery and stale lock lease reclaiming if a pod crashed mid-flight.
        // -------------------------------------------------------------------------
        boolean isRecovery = context.isRecovering();
        int lockClaimed;
        LocalDateTime staleThreshold = fireTime.minusMinutes(lockLeaseMinutes > 0 ? lockLeaseMinutes : 10);
        if (isRecovery) {
            log.info(">>> [Quartz Failover Recovery] Instance [{}] is recovering Job [{} / {}] for scheduleId {} after previous instance failure.", 
                    instanceId, jobGroup, jobName, scheduleId);
            lockClaimed = reportScheduleRequestMapper.forceClaimExecutionLock(scheduleId);
            try {
                scheduleReportExecutionLogMapper.markStaleExecutionsAsFailed(
                        scheduleId, fireTime.minusMinutes(1), "Execution abandoned due to node crash; recovered via failover by " + instanceId);
            } catch (Exception ignored) {}
        } else {
            lockClaimed = reportScheduleRequestMapper.claimExecutionLockWithTimeout(scheduleId, staleThreshold);
            if (lockClaimed > 0) {
                try {
                    scheduleReportExecutionLogMapper.markStaleExecutionsAsFailed(
                            scheduleId, staleThreshold, "Execution timed out (stale lease broken by " + instanceId + ")");
                } catch (Exception ignored) {}
            }
        }

        if (lockClaimed == 0) {
            log.warn(">>> [Multi-Instance Mutual Exclusion] Instance [{}] could not acquire execution lock for scheduleId {}. Another instance is already initiating/processing this job. Bailing out.", 
                    instanceId, scheduleId);
            return;
        }

        log.info(">>> [Multi-Instance Mutual Exclusion] Instance [{}] successfully claimed execution lock for scheduleId {}. Only this instance is initiating the call.", 
                instanceId, scheduleId);

        // Prepare execution log model
        ScheduleReportExecutionLog executionLog = new ScheduleReportExecutionLog(
                scheduleId, 
                "RPT_" + scheduleId, 
                fireTime
        );
        executionLog.setStatus("TRIGGERED");
        executionLog.setFileStatus("PENDING");
        executionLog.setReportType(request.getReportType());
        executionLog.setOlbId(request.getOlbId());
        executionLog.setUserId(request.getUserId());
        executionLog.setClientId(request.getClientId());
        executionLog.setPageId(request.getPageId());
        executionLog.setRetryCount(context.getRefireCount());

        // Entire execution is guarded by try-finally to guarantee lock release under all failure scenarios
        try {
            // -------------------------------------------------------------------------
            // STEP 1: INITIAL LOG ENTRY CREATION ON TRIGGER
            // Immediately record an entry in SCHEDULE_REPORT_EXECUTION_LOG with status TRIGGERED
            // and fileStatus PENDING so in-flight executions are visible immediately in the DB.
            // -------------------------------------------------------------------------
            try {
                scheduleReportExecutionLogMapper.insert(executionLog);
                reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "TRIGGERED", "PENDING");
                log.info(">>> [Step 1/5 - TRIGGERED] Created initial execution log #{} for scheduleId: {}, status: TRIGGERED, fileStatus: PENDING", 
                        executionLog.getExecutionId(), scheduleId);
            } catch (Exception ex) {
                log.error("Failed to insert initial execution log on trigger for scheduleId {}", scheduleId, ex);
            }

            // Auto-gap downtime detection: If the last execution occurred > 10 minutes ago,
            // tag the request criteria payload with the missed window [windowStart, windowEnd]
            if (schedule.getLastUpdatedTs() != null && schedule.getLastUpdatedTs().isBefore(fireTime.minusMinutes(10))) {
                log.info(">>> [Auto-Gap Catch-Up Detection] Schedule #{} last executed at {}, detected downtime gap of >10 minutes before fire time {}. Tagging window [{} to {}].",
                        scheduleId, schedule.getLastUpdatedTs(), fireTime, schedule.getLastUpdatedTs(), fireTime);
                String existingPayload = request.getRptCriteriaPayload() != null ? request.getRptCriteriaPayload() : "{}";
                request.setRptCriteriaPayload(existingPayload + " [windowStart: " + schedule.getLastUpdatedTs() + ", windowEnd: " + fireTime + "]");
            }

            // -------------------------------------------------------------------------
            // STEP 2: TRANSITION TO PROCESSING
            // Pre-execution tasks & criteria evaluation
            // -------------------------------------------------------------------------
            executionLog.setStatus("PROCESSING");
            executionLog.setFileStatus("PREPARING");
            if (executionLog.getExecutionId() != null) {
                scheduleReportExecutionLogMapper.updateStatusAndFileStatus(executionLog.getExecutionId(), "PROCESSING", "PREPARING");
            }
            reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "PROCESSING", "PREPARING");
            log.info(">>> [Step 2/5 - PROCESSING] Log #{} updated to status: PROCESSING, fileStatus: PREPARING", 
                    executionLog.getExecutionId());

            // -------------------------------------------------------------------------
            // STEP 3: TRANSITION TO GENERATING & EXECUTE TASK HANDLER
            // -------------------------------------------------------------------------
            String jobType = request.getReportType() != null ? request.getReportType() : "REPORT";
            boolean isReportJob = !"HTTP".equalsIgnoreCase(jobType) && !"BEAN".equalsIgnoreCase(jobType);
            String generatingFileStatus = isReportJob ? "GENERATING" : "NOT_APPLICABLE";

            executionLog.setStatus("GENERATING");
            executionLog.setFileStatus(generatingFileStatus);
            if (executionLog.getExecutionId() != null) {
                scheduleReportExecutionLogMapper.updateStatusAndFileStatus(executionLog.getExecutionId(), "GENERATING", generatingFileStatus);
            }
            reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "GENERATING", generatingFileStatus);
            log.info(">>> [Step 3/5 - GENERATING] Log #{} updated to status: GENERATING, fileStatus: {}", 
                    executionLog.getExecutionId(), generatingFileStatus);

            JobTaskHandler handler = jobTaskHandlerRegistry.getHandler(jobType);
            JobExecutionOutcome outcome = handler.execute(schedule, request);

            boolean outcomeSuccess = outcome != null && "SUCCESS".equalsIgnoreCase(outcome.getStatus());

            if (outcomeSuccess) {
                // -------------------------------------------------------------------------
                // STEP 4: TRANSITION TO UPLOADING (IF STORAGE PROVIDER IS S3)
                // -------------------------------------------------------------------------
                if ("S3".equalsIgnoreCase(outcome.getStorageProvider())) {
                    executionLog.setStatus("UPLOADING");
                    executionLog.setFileStatus("UPLOADING");
                    if (executionLog.getExecutionId() != null) {
                        scheduleReportExecutionLogMapper.updateStatusAndFileStatus(executionLog.getExecutionId(), "UPLOADING", "UPLOADING");
                    }
                    reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "UPLOADING", "UPLOADING");
                    log.info(">>> [Step 4/5 - UPLOADING] Log #{} updated to status: UPLOADING, fileStatus: UPLOADING", 
                            executionLog.getExecutionId());
                }

                // -------------------------------------------------------------------------
                // STEP 5: FINAL COMPLETION (SUCCESS)
                // -------------------------------------------------------------------------
                executionLog.setEndTime(LocalDateTime.now());
                executionLog.setStatus("SUCCESS");
                String finalFileStatus = outcome.getFileStatus() != null 
                        ? outcome.getFileStatus() 
                        : ("S3".equalsIgnoreCase(outcome.getStorageProvider()) ? "UPLOADED" : "NOT_APPLICABLE");
                executionLog.setFileStatus(finalFileStatus);
                executionLog.setGeneratedReportId(outcome.getExecutionReferenceId() + "_" + instanceId);
                executionLog.setRecordCount(outcome.getRecordCount());
                executionLog.setStorageProvider(outcome.getStorageProvider());
                executionLog.setS3Bucket(outcome.getS3Bucket());
                executionLog.setS3ObjectKey(outcome.getS3ObjectKey());
                executionLog.setFileName(outcome.getFileName());
                executionLog.setFileFormat(outcome.getFileFormat());
                executionLog.setFileSizeBytes(outcome.getFileSizeBytes());

                if (executionLog.getExecutionId() != null) {
                    scheduleReportExecutionLogMapper.updateExecutionOutcome(executionLog);
                } else {
                    scheduleReportExecutionLogMapper.insert(executionLog);
                }

                reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "READY", finalFileStatus);

                log.info("<<< Scheduled Job [{} / {}] completed successfully on instance [{}] via handler [{}], final status: SUCCESS, fileStatus: {}", 
                        jobGroup, jobName, instanceId, handler.getClass().getSimpleName(), finalFileStatus);
            } else {
                // Handler returned non-success outcome (e.g., FAILED, ERROR)
                String failureStatus = outcome != null && outcome.getStatus() != null ? outcome.getStatus() : "FAILED";
                String finalFileStatus = outcome != null && outcome.getFileStatus() != null ? outcome.getFileStatus() : "FAILED";

                executionLog.setEndTime(LocalDateTime.now());
                executionLog.setStatus(failureStatus);
                executionLog.setFileStatus(finalFileStatus);

                String errorMsg = outcome != null && outcome.getErrorMessage() != null 
                        ? outcome.getErrorMessage() 
                        : "Handler returned non-success outcome status: " + failureStatus;
                executionLog.setErrorMessage(safeFormatErrorMessage(errorMsg, instanceId));

                if (executionLog.getExecutionId() != null) {
                    scheduleReportExecutionLogMapper.updateExecutionOutcome(executionLog);
                } else {
                    scheduleReportExecutionLogMapper.insert(executionLog);
                }

                reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, failureStatus, finalFileStatus);

                log.warn("<<< Scheduled Job [{} / {}] finished with non-success status [{}] on instance [{}]: {}", 
                        jobGroup, jobName, failureStatus, instanceId, executionLog.getErrorMessage());
            }
        } catch (Exception e) {
            executionLog.setEndTime(LocalDateTime.now());
            executionLog.setStatus("FAILED");
            executionLog.setFileStatus("FAILED");
            Throwable root = e;
            while (root.getCause() != null && root.getCause() != root) {
                root = root.getCause();
            }
            String rawErrorMsg = root.getMessage() != null ? root.getMessage() : root.getClass().getName();
            executionLog.setErrorMessage(safeFormatErrorMessage(rawErrorMsg, instanceId));

            try {
                if (executionLog.getExecutionId() != null) {
                    scheduleReportExecutionLogMapper.updateExecutionOutcome(executionLog);
                } else {
                    scheduleReportExecutionLogMapper.insert(executionLog);
                }
            } catch (Exception logEx) {
                log.error("Failed to persist execution log outcome during error handling", logEx);
                // Safe fallback with minimal message in case DB column length/encoding caused failure
                try {
                    executionLog.setErrorMessage("Execution failed: " + e.getClass().getSimpleName());
                    if (executionLog.getExecutionId() != null) {
                        scheduleReportExecutionLogMapper.updateExecutionOutcome(executionLog);
                    }
                } catch (Exception ignored) {}
            }

            try {
                reportScheduleRequestMapper.updateStatusAndFileStatus(scheduleId, "FAILED", "FAILED");
            } catch (Exception reqEx) {
                log.error("Failed to update request status to FAILED for scheduleId {}", scheduleId, reqEx);
            }

            log.error("<<< Scheduled Job [{} / {}] failed on instance [{}]: {}", jobGroup, jobName, instanceId, executionLog.getErrorMessage(), e);
        } finally {
            // 1. Release the distributed execution lock in DB
            try {
                String releaseStatus = executionLog.getStatus() != null ? executionLog.getStatus() : "FAILED";
                reportScheduleRequestMapper.releaseExecutionLock(scheduleId, releaseStatus);
            } catch (Exception lockEx) {
                log.error("Failed to release execution lock for scheduleId {} on instance [{}]", scheduleId, instanceId, lockEx);
            }

            // 2. Compute next fire time and update execution times in DB
            try {
                Date nextFireDate = context.getNextFireTime();

                // If this was a manual trigger, the temporary one-shot trigger has no future fires;
                // retrieve the true next fire time from the persistent cron trigger.
                if (manualTrigger) {
                    try {
                        org.quartz.TriggerKey triggerKey = org.quartz.TriggerKey.triggerKey(jobName + "_trigger", jobGroup);
                        org.quartz.Trigger persistentTrigger = context.getScheduler().getTrigger(triggerKey);
                        if (persistentTrigger != null && persistentTrigger.getNextFireTime() != null) {
                            nextFireDate = persistentTrigger.getNextFireTime();
                        }
                    } catch (Exception ex) {
                        log.debug("Could not resolve persistent trigger next fire time: {}", ex.getMessage());
                    }
                }

                LocalDateTime nextRunTime = nextFireDate != null 
                        ? nextFireDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() 
                        : null;

                // Lifecycle completion: only transition to COMPLETED if this was an actual scheduled run that exhausted all fires
                if (!manualTrigger && nextRunTime == null) {
                    log.info("Schedule #{} has completed all scheduled executions. Updating status to COMPLETED.", scheduleId);
                    reportScheduleDetailMapper.updateStatus(scheduleId, "COMPLETED");
                }

                // Update last updated timestamp and next run time in REPORT_SCHEDULE_DETAIL table
                reportScheduleDetailMapper.updateExecutionTimes(scheduleId, fireTime, nextRunTime);
            } catch (Exception dbEx) {
                log.error("Failed to update schedule execution times for scheduleId {} on instance [{}]", scheduleId, instanceId, dbEx);
            }
        }
    }

    private String safeFormatErrorMessage(String rawMessage, String instanceId) {
        if (rawMessage == null) {
            rawMessage = "Unknown error";
        }
        String suffix = " (executed by: " + (instanceId != null ? instanceId : "unknown") + ")";
        int maxRawLen = 3500 - suffix.length();
        if (rawMessage.length() > maxRawLen) {
            rawMessage = rawMessage.substring(0, maxRawLen);
        }
        String combined = rawMessage + suffix;
        if (combined.length() > 3900) {
            combined = combined.substring(0, 3900);
        }
        return combined;
    }
}
