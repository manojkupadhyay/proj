package com.example.s3ontap.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;

import java.net.URI;

/**
 * Configuration class to bootstrap the AWS S3Client bean.
 * Configured specifically to support S3-compatible APIs such as NetApp ONTAP S3.
 */
@Configuration
public class S3Config {

    @Value("${s3.endpoint}")
    private String endpoint;

    @Value("${s3.access-key}")
    private String accessKey;

    @Value("${s3.secret-key}")
    private String secretKey;

    @Value("${s3.region}")
    private String region;

    @Bean
    public S3Client s3Client() {
        return S3Client.builder()
                // Override S3 service endpoint to point to NetApp ONTAP S3 IP/Host
                .endpointOverride(URI.create(endpoint))
                // Load access credentials
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(accessKey, secretKey)
                ))
                // Specify Region (required by the SDK, even if dummy)
                .region(Region.of(region))
                // Enable path-style access (e.g. http://endpoint/bucket rather than http://bucket.endpoint)
                // NetApp ONTAP S3 typically requires path-style access.
                .serviceConfiguration(S3Configuration.builder()
                        .pathStyleAccessEnabled(true)
                        .build())
                .build();
    }
}
