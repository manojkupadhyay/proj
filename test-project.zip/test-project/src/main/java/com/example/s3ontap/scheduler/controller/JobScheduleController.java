package com.example.s3ontap.scheduler.controller;

import com.example.s3ontap.scheduler.dto.BackfillRequestDto;
import com.example.s3ontap.scheduler.dto.ScheduleRequestDto;
import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import org.quartz.SchedulerException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/schedules")
public class JobScheduleController {

    private final QuartzSchedulerService quartzSchedulerService;
    private final ReportScheduleDetailMapper reportScheduleDetailMapper;
    private final ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;
    private final com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry jobTaskHandlerRegistry;

    public JobScheduleController(QuartzSchedulerService quartzSchedulerService,
                                 ReportScheduleDetailMapper reportScheduleDetailMapper,
                                 ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper,
                                 com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry jobTaskHandlerRegistry) {
        this.quartzSchedulerService = quartzSchedulerService;
        this.reportScheduleDetailMapper = reportScheduleDetailMapper;
        this.scheduleReportExecutionLogMapper = scheduleReportExecutionLogMapper;
        this.jobTaskHandlerRegistry = jobTaskHandlerRegistry;
    }

    /**
     * Persist report schedule & request details in DB via MyBatis and schedule in Quartz.
     */
    @PostMapping
    public ResponseEntity<?> createSchedule(@RequestBody ScheduleRequestDto dto) {
        try {
            ReportScheduleDetail schedule = dto.toScheduleEntity();
            ReportScheduleDetail created = quartzSchedulerService.createAndSchedule(schedule, dto.toRequestEntity());
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (SchedulerException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Quartz scheduling failed: " + e.getMessage()));
        }
    }

    /**
     * Read all report schedule details from the DB via MyBatis.
     */
    @GetMapping
    public ResponseEntity<List<ReportScheduleDetail>> getAllSchedules() {
        return ResponseEntity.ok(reportScheduleDetailMapper.findAll());
    }

    /**
     * Read a specific report schedule detail by ID via MyBatis.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getScheduleById(@PathVariable Long id) {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(id);
        if (schedule != null) {
            return ResponseEntity.ok(schedule);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Update schedule details / request details in DB via MyBatis and reschedule in Quartz.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateSchedule(@PathVariable Long id, @RequestBody ScheduleRequestDto dto) {
        try {
            ReportScheduleDetail updated = quartzSchedulerService.updateAndReschedule(id, dto.toScheduleEntity(), dto.toRequestEntity());
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (SchedulerException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Rescheduling failed: " + e.getMessage()));
        }
    }

    /**
     * Pause a scheduled job in Quartz and update DB status via MyBatis.
     */
    @PostMapping("/{id}/pause")
    public ResponseEntity<?> pauseSchedule(@PathVariable Long id) {
        try {
            quartzSchedulerService.pauseJob(id);
            return ResponseEntity.ok(Map.of("message", "Job paused successfully", "scheduleId", id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Resume a paused job in Quartz and update DB status via MyBatis.
     */
    @PostMapping("/{id}/resume")
    public ResponseEntity<?> resumeSchedule(@PathVariable Long id) {
        try {
            quartzSchedulerService.resumeJob(id);
            return ResponseEntity.ok(Map.of("message", "Job resumed successfully", "scheduleId", id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Trigger a job immediately at runtime on-demand.
     */
    @PostMapping("/{id}/trigger")
    public ResponseEntity<?> triggerJobNow(@PathVariable Long id) {
        try {
            quartzSchedulerService.triggerJobNow(id);
            return ResponseEntity.ok(Map.of("message", "Job execution triggered successfully", "scheduleId", id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Delete a job from Quartz and remove from DB via MyBatis.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSchedule(@PathVariable Long id) {
        try {
            quartzSchedulerService.deleteJob(id);
            return ResponseEntity.ok(Map.of("message", "Job deleted successfully", "scheduleId", id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Read all active report schedules from the DB table via MyBatis and re-sync with Quartz at runtime.
     */
    @PostMapping("/sync")
    public ResponseEntity<?> syncSchedulesFromDb() {
        int count = quartzSchedulerService.syncAllActiveSchedulesFromDb();
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Dynamic DB report schedules synced with Quartz");
        response.put("jobsScheduledCount", count);
        return ResponseEntity.ok(response);
    }

    /**
     * Read execution history logs for a specific schedule via MyBatis.
     * Supports optional filtering by execution status, file status, and row limit.
     */
    @GetMapping("/{id}/logs")
    public ResponseEntity<List<ScheduleReportExecutionLog>> getJobLogs(
            @PathVariable Long id,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "fileStatus", required = false) String fileStatus,
            @RequestParam(value = "limit", required = false) Integer limit) {
        if (status != null || fileStatus != null || limit != null) {
            return ResponseEntity.ok(scheduleReportExecutionLogMapper.findByScheduleIdWithFilters(id, status, fileStatus, limit));
        }
        return ResponseEntity.ok(scheduleReportExecutionLogMapper.findByScheduleId(id));
    }

    public ResponseEntity<List<ScheduleReportExecutionLog>> getJobLogs(Long id) {
        return getJobLogs(id, null, null, null);
    }

    /**
     * Operational summary endpoint returning scheduler health, schedule breakdown, and execution statistics.
     */
    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getSchedulerSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("status", "UP");
        summary.put("timestamp", java.time.LocalDateTime.now());

        // Schedule metrics
        long totalSchedules = reportScheduleDetailMapper.countTotal();
        long activeSchedules = reportScheduleDetailMapper.countByStatus("ACTIVE");
        long pausedSchedules = reportScheduleDetailMapper.countByStatus("PAUSED");
        summary.put("totalSchedules", totalSchedules);
        summary.put("activeSchedules", activeSchedules);
        summary.put("pausedSchedules", pausedSchedules);

        // Execution log metrics
        long totalExecutions = scheduleReportExecutionLogMapper.countTotal();
        long successfulExecutions = scheduleReportExecutionLogMapper.countByStatus("SUCCESS");
        long failedExecutions = scheduleReportExecutionLogMapper.countByStatus("FAILED");
        summary.put("totalExecutions", totalExecutions);
        summary.put("successfulExecutions", successfulExecutions);
        summary.put("failedExecutions", failedExecutions);

        double successRate = totalExecutions > 0 ? ((double) successfulExecutions / totalExecutions) * 100.0 : 100.0;
        summary.put("successRatePercent", Math.round(successRate * 100.0) / 100.0);

        return ResponseEntity.ok(summary);
    }

    /**
     * Read all registered generic job handlers supported by the scheduler.
     */
    @GetMapping("/job-types")
    public ResponseEntity<List<String>> getRegisteredJobTypes() {
        return ResponseEntity.ok(jobTaskHandlerRegistry.getRegisteredHandlerNames());
    }

    /**
     * Replay missed job executions across a historical downtime window.
     * Computes every discrete cron occurrence between 'from' and 'to', executes each slice,
     * and records individual logs in SCHEDULE_REPORT_EXECUTION_LOG.
     */
    @PostMapping("/{id}/backfill")
    public ResponseEntity<?> backfillSchedule(@PathVariable Long id, @RequestBody BackfillRequestDto dto) {
        try {
            List<String> replayed = quartzSchedulerService.backfillSchedule(id, dto.getFrom(), dto.getTo(), dto.getCustomPayload());
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Backfill completed successfully");
            response.put("scheduleId", id);
            response.put("slicesExecutedCount", replayed.size());
            response.put("executionReferenceIds", replayed);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Backfill failed: " + e.getMessage()));
        }
    }
}
