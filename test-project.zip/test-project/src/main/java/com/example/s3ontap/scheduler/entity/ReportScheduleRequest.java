package com.example.s3ontap.scheduler.entity;

import java.time.LocalDateTime;

public class ReportScheduleRequest {

    private Long requestId;
    private String reportName;
    private String reportType;
    private String olbId;
    private String userId;
    private String clientId;
    private String pageId;
    private String rptCriteriaPayload;
    private String rptCriteriaHeader;
    private String outputFormat = "PDF";
    private String status = "READY";
    private String fileStatus = "READY";
    private LocalDateTime createdAt;
    private String updatedBy;
    private String createdBy;
    private LocalDateTime updatedAt;
    private Long previousRequestId;
    private Long scheduleId;
    private String processingStatus = "QUEUED";

    public ReportScheduleRequest() {
    }

    public ReportScheduleRequest(String reportName, String reportType, Long scheduleId) {
        this.reportName = reportName;
        this.reportType = reportType;
        this.scheduleId = scheduleId;
    }

    // Getters and Setters
    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getOlbId() {
        return olbId;
    }

    public void setOlbId(String olbId) {
        this.olbId = olbId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPageId() {
        return pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }

    public String getRptCriteriaPayload() {
        return rptCriteriaPayload;
    }

    public void setRptCriteriaPayload(String rptCriteriaPayload) {
        this.rptCriteriaPayload = rptCriteriaPayload;
    }

    public String getRptCriteriaHeader() {
        return rptCriteriaHeader;
    }

    public void setRptCriteriaHeader(String rptCriteriaHeader) {
        this.rptCriteriaHeader = rptCriteriaHeader;
    }

    public String getOutputFormat() {
        return outputFormat;
    }

    public void setOutputFormat(String outputFormat) {
        this.outputFormat = outputFormat;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(String fileStatus) {
        this.fileStatus = fileStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getPreviousRequestId() {
        return previousRequestId;
    }

    public void setPreviousRequestId(Long previousRequestId) {
        this.previousRequestId = previousRequestId;
    }

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getProcessingStatus() {
        return processingStatus;
    }

    public void setProcessingStatus(String processingStatus) {
        this.processingStatus = processingStatus;
    }
}
