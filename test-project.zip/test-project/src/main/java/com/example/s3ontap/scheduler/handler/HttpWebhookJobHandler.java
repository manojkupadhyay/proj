package com.example.s3ontap.scheduler.handler;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Generic JobTaskHandler for HTTP webhooks, REST endpoint triggers, and microservice callbacks.
 * Configured via RPT_CRITERIA_PAYLOAD (e.g. {"url": "https://api.example.com/sync", "method": "POST"}).
 */
@Component
public class HttpWebhookJobHandler implements JobTaskHandler {

    private static final Logger log = LoggerFactory.getLogger(HttpWebhookJobHandler.class);

    @Override
    public boolean supports(String jobType) {
        if (jobType == null) return false;
        String upper = jobType.toUpperCase();
        return upper.equals("HTTP") || upper.equals("WEBHOOK") || upper.equals("REST") || upper.contains("HTTP");
    }

    @Override
    public JobExecutionOutcome execute(ReportScheduleDetail schedule, ReportScheduleRequest request) throws Exception {
        String payload = request != null ? request.getRptCriteriaPayload() : "{}";
        String headers = request != null ? request.getRptCriteriaHeader() : "{}";
        String jobName = request != null && request.getReportName() != null ? request.getReportName() : "HttpJob_" + schedule.getScheduleId();

        log.info("Executing Generic HTTP Webhook Job: scheduleId={}, jobName={}, payload={}, headers={}", 
                schedule.getScheduleId(), jobName, payload, headers);

        // Simulated HTTP call invocation
        String executionRef = "HTTP_" + UUID.randomUUID().toString().substring(0, 8);
        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus("SUCCESS");
        outcome.setExecutionReferenceId(executionRef);
        outcome.setRecordCount(1L);
        outcome.setStorageProvider("NONE");
        outcome.setFileStatus("NOT_APPLICABLE");
        outcome.setResponsePayload("{\"status\": 200, \"message\": \"Webhook dispatched successfully\"}");

        log.info("HTTP Webhook Job completed successfully: ref={}", executionRef);
        return outcome;
    }
}
