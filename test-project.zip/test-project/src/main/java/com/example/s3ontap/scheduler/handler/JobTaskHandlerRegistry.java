package com.example.s3ontap.scheduler.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Registry that holds all available JobTaskHandler beans.
 * Routes execution dynamically based on the jobType string.
 */
@Component
public class JobTaskHandlerRegistry {

    private static final Logger log = LoggerFactory.getLogger(JobTaskHandlerRegistry.class);

    private final List<JobTaskHandler> handlers;
    private final ReportJobHandler defaultHandler;

    public JobTaskHandlerRegistry(List<JobTaskHandler> handlers, ReportJobHandler defaultHandler) {
        this.handlers = handlers;
        this.defaultHandler = defaultHandler;
        log.info("Initialized JobTaskHandlerRegistry with {} registered handlers", handlers.size());
    }

    /**
     * Resolves the appropriate JobTaskHandler for the given job type.
     * Falls back to defaultHandler (ReportJobHandler) if no specialized handler matches.
     */
    public JobTaskHandler getHandler(String jobType) {
        if (jobType != null) {
            for (JobTaskHandler handler : handlers) {
                // Check non-default handlers first
                if (handler != defaultHandler && handler.supports(jobType)) {
                    log.debug("Resolved handler [{}] for jobType [{}]", handler.getClass().getSimpleName(), jobType);
                    return handler;
                }
            }
        }
        log.debug("Falling back to default handler [{}] for jobType [{}]", defaultHandler.getClass().getSimpleName(), jobType);
        return defaultHandler;
    }

    /**
     * Returns a list of supported job handler names.
     */
    public List<String> getRegisteredHandlerNames() {
        List<String> names = new ArrayList<>();
        for (JobTaskHandler handler : handlers) {
            names.add(handler.getClass().getSimpleName());
        }
        return names;
    }
}
