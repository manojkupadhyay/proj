package com.example.s3ontap.scheduler.handler;

/**
 * Generic execution result returned by any JobTaskHandler.
 * Mapped to SCHEDULE_REPORT_EXECUTION_LOG for auditing.
 */
public class JobExecutionOutcome {

    private String status = "SUCCESS";
    private String executionReferenceId;
    private Long recordCount = 0L;
    private String storageProvider = "NONE";
    private String s3Bucket;
    private String s3ObjectKey;
    private String fileName;
    private String fileFormat;
    private Long fileSizeBytes = 0L;
    private String fileStatus;
    private String errorMessage;
    private String responsePayload;

    public static JobExecutionOutcome success(String referenceId) {
        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus("SUCCESS");
        outcome.setExecutionReferenceId(referenceId);
        return outcome;
    }

    public static JobExecutionOutcome failed(String errorMessage) {
        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus("FAILED");
        outcome.setErrorMessage(errorMessage);
        return outcome;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExecutionReferenceId() {
        return executionReferenceId;
    }

    public void setExecutionReferenceId(String executionReferenceId) {
        this.executionReferenceId = executionReferenceId;
    }

    public Long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Long recordCount) {
        this.recordCount = recordCount;
    }

    public String getStorageProvider() {
        return storageProvider;
    }

    public void setStorageProvider(String storageProvider) {
        this.storageProvider = storageProvider;
    }

    public String getS3Bucket() {
        return s3Bucket;
    }

    public void setS3Bucket(String s3Bucket) {
        this.s3Bucket = s3Bucket;
    }

    public String getS3ObjectKey() {
        return s3ObjectKey;
    }

    public void setS3ObjectKey(String s3ObjectKey) {
        this.s3ObjectKey = s3ObjectKey;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public Long getFileSizeBytes() {
        return fileSizeBytes;
    }

    public void setFileSizeBytes(Long fileSizeBytes) {
        this.fileSizeBytes = fileSizeBytes;
    }

    public String getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(String fileStatus) {
        this.fileStatus = fileStatus;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getResponsePayload() {
        return responsePayload;
    }

    public void setResponsePayload(String responsePayload) {
        this.responsePayload = responsePayload;
    }
}
