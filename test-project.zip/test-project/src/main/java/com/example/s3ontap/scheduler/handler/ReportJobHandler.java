package com.example.s3ontap.scheduler.handler;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.job.JobRequestDispatcher;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * JobTaskHandler implementation for document & report generation jobs.
 */
@Component
public class ReportJobHandler implements JobTaskHandler {

    private static final List<String> SUPPORTED_TYPES = Arrays.asList(
            "REPORT", "FINANCIAL", "AUDIT", "BATCH", "INVENTORY", "STANDARD", "CONCURRENT", "FAILOVER", "TEST", "CLUSTER_TEST"
    );

    private final JobRequestDispatcher jobRequestDispatcher;

    public ReportJobHandler(JobRequestDispatcher jobRequestDispatcher) {
        this.jobRequestDispatcher = jobRequestDispatcher;
    }

    @Override
    public boolean supports(String jobType) {
        if (jobType == null) {
            return true; // default fallback handler
        }
        return SUPPORTED_TYPES.contains(jobType.toUpperCase()) || jobType.toUpperCase().endsWith("REPORT");
    }

    @Override
    public JobExecutionOutcome execute(ReportScheduleDetail schedule, ReportScheduleRequest request) throws Exception {
        JobRequestDispatcher.ReportExecutionResult result = jobRequestDispatcher.dispatchReport(schedule, request);

        JobExecutionOutcome outcome = new JobExecutionOutcome();
        outcome.setStatus(result.status);
        outcome.setExecutionReferenceId(result.generatedReportId);
        outcome.setRecordCount(result.recordCount);
        outcome.setStorageProvider(result.storageProvider);
        outcome.setS3Bucket(result.s3Bucket);
        outcome.setS3ObjectKey(result.s3ObjectKey);
        outcome.setFileName(result.fileName);
        outcome.setFileFormat(result.fileFormat);
        outcome.setFileSizeBytes(result.fileSizeBytes);
        outcome.setFileStatus(result.fileStatus != null ? result.fileStatus : "UPLOADED");
        outcome.setErrorMessage(result.errorMessage);

        return outcome;
    }
}
