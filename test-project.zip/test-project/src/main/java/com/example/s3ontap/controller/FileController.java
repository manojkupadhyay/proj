package com.example.s3ontap.controller;

import com.example.s3ontap.service.S3Service;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;

import java.io.IOException;

/**
 * REST controller for file upload and download endpoints.
 * Interacts with S3Service to store and retrieve binary files.
 */
@RestController
@RequestMapping("/api/files")
public class FileController {

    private final S3Service s3Service;

    public FileController(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    /**
     * Upload endpoint for multipart files.
     * Maps to POST /api/files/upload
     *
     * @param file Multipart file content uploaded by client
     * @return Success message or error message
     */
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Uploaded file is empty");
        }

        try {
            String fileName = file.getOriginalFilename();
            if (fileName == null || fileName.trim().isEmpty()) {
                fileName = "uploaded-file-" + System.currentTimeMillis();
            }

            // Stream upload directly to S3
            s3Service.uploadFile(
                    fileName,
                    file.getInputStream(),
                    file.getSize(),
                    file.getContentType()
            );

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("File uploaded successfully: " + fileName);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to read upload file input stream: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error uploading file to S3: " + e.getMessage());
        }
    }

    /**
     * Upload endpoint that streams raw request body directly to S3.
     * Bypasses multipart parsing overhead, ideal for large files.
     * Maps to POST /api/files/stream-upload
     *
     * @param fileName      Name of the file to save as on S3
     * @param contentType   Optional request content type header (defaults to binary octet stream)
     * @param contentLength Optional request content length header
     * @param request       HttpServletRequest to extract the raw input stream
     * @return Success message or error message
     */
    @PostMapping("/stream-upload")
    public ResponseEntity<String> streamUpload(
            @RequestParam("fileName") String fileName,
            @RequestHeader(value = HttpHeaders.CONTENT_TYPE, defaultValue = MediaType.APPLICATION_OCTET_STREAM_VALUE) String contentType,
            @RequestHeader(value = HttpHeaders.CONTENT_LENGTH, required = false) Long contentLength,
            HttpServletRequest request) {
        
        try {
            long length = (contentLength != null && contentLength >= 0) ? contentLength : request.getContentLengthLong();
            if (length <= 0) {
                return ResponseEntity.badRequest().body("Content-Length header must be specified and greater than 0");
            }

            s3Service.uploadFile(
                    fileName,
                    request.getInputStream(),
                    length,
                    contentType
            );

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("File streamed and uploaded successfully: " + fileName);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to read raw request input stream: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error streaming upload to S3: " + e.getMessage());
        }
    }

    /**
     * Download endpoint to fetch files from S3.
     * Maps to GET /api/files/download/{fileName}
     *
     * @param fileName Name of the file stored in S3
     * @return Binary stream with appropriate media-type and headers
     */
    @GetMapping("/download/{fileName}")
    public ResponseEntity<InputStreamResource> downloadFile(@PathVariable("fileName") String fileName) {
        try {
            ResponseInputStream<GetObjectResponse> s3Stream = s3Service.downloadFile(fileName);
            GetObjectResponse s3Response = s3Stream.response();

            // Set file response headers based on metadata retrieved from S3
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
            
            // Map S3 Content-Type header or default to Octet Stream
            String contentType = s3Response.contentType();
            MediaType mediaType = MediaType.APPLICATION_OCTET_STREAM;
            if (contentType != null) {
                try {
                    mediaType = MediaType.parseMediaType(contentType);
                } catch (Exception ignored) {
                }
            }

            InputStreamResource resource = new InputStreamResource(s3Stream);

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(s3Response.contentLength())
                    .contentType(mediaType)
                    .body(resource);

        } catch (NoSuchKeyException e) {
            // Return 404 if file is not found in the S3 bucket
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            // Return 500 for other network or S3 related exceptions
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Download endpoint utilizing Spring's StreamingResponseBody to pipe S3 bytes
     * directly to the HTTP response output stream chunk-by-chunk.
     * Maps to GET /api/files/stream-download/{fileName}
     *
     * @param fileName Name of the file stored in S3
     * @return StreamingResponseBody stream response
     */
    @GetMapping("/stream-download/{fileName}")
    public ResponseEntity<StreamingResponseBody> streamDownload(@PathVariable("fileName") String fileName) {
        try {
            ResponseInputStream<GetObjectResponse> s3Stream = s3Service.downloadFile(fileName);
            GetObjectResponse s3Response = s3Stream.response();

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");

            String contentType = s3Response.contentType();
            MediaType mediaType = MediaType.APPLICATION_OCTET_STREAM;
            if (contentType != null) {
                try {
                    mediaType = MediaType.parseMediaType(contentType);
                } catch (Exception ignored) {
                }
            }

            // Create asynchronous streaming callback to write bytes directly to HTTP response output stream
            StreamingResponseBody responseBody = outputStream -> {
                try (s3Stream) {
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = s3Stream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }
                    outputStream.flush();
                }
            };

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(s3Response.contentLength())
                    .contentType(mediaType)
                    .body(responseBody);

        } catch (NoSuchKeyException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
