package com.example.s3ontap.scheduler.dto;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;

import java.time.LocalDateTime;

public class ScheduleRequestDto {

    // Schedule fields
    private String userId;
    private String cronExpression;
    private String status = "ACTIVE";
    private LocalDateTime startAt;
    private LocalDateTime expiresAt;
    private String systemDefined = "N";
    private String createdBy;
    private String updatedBy;

    // Report Request fields
    private String reportName;
    private String reportType = "STANDARD";
    private String olbId;
    private String clientId;
    private String pageId;
    private String rptCriteriaPayload;
    private String rptCriteriaHeader;
    private String outputFormat = "PDF";

    public ScheduleRequestDto() {
    }

    public ReportScheduleDetail toScheduleEntity() {
        ReportScheduleDetail schedule = new ReportScheduleDetail();
        schedule.setUserId(this.userId);
        schedule.setCronExpression(this.cronExpression);
        schedule.setStatus(this.status != null ? this.status : "ACTIVE");
        schedule.setStartAt(this.startAt);
        schedule.setExpiresAt(this.expiresAt);
        schedule.setSystemDefined(this.systemDefined != null ? this.systemDefined : "N");
        schedule.setCreatedBy(this.createdBy);
        schedule.setUpdatedBy(this.updatedBy);
        return schedule;
    }

    public ReportScheduleRequest toRequestEntity() {
        ReportScheduleRequest request = new ReportScheduleRequest();
        request.setReportName(this.reportName != null ? this.reportName : "Report_" + this.reportType);
        request.setReportType(this.reportType != null ? this.reportType : "STANDARD");
        request.setOlbId(this.olbId);
        request.setUserId(this.userId);
        request.setClientId(this.clientId);
        request.setPageId(this.pageId);
        request.setRptCriteriaPayload(this.rptCriteriaPayload);
        request.setRptCriteriaHeader(this.rptCriteriaHeader);
        request.setOutputFormat(this.outputFormat != null ? this.outputFormat : "PDF");
        request.setStatus("READY");
        request.setFileStatus("READY");
        request.setProcessingStatus("QUEUED");
        request.setCreatedBy(this.createdBy);
        request.setUpdatedBy(this.updatedBy);
        return request;
    }

    // Getters and Setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartAt() {
        return startAt;
    }

    public void setStartAt(LocalDateTime startAt) {
        this.startAt = startAt;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public String getSystemDefined() {
        return systemDefined;
    }

    public void setSystemDefined(String systemDefined) {
        this.systemDefined = systemDefined;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getOlbId() {
        return olbId;
    }

    public void setOlbId(String olbId) {
        this.olbId = olbId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPageId() {
        return pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }

    public String getRptCriteriaPayload() {
        return rptCriteriaPayload;
    }

    public void setRptCriteriaPayload(String rptCriteriaPayload) {
        this.rptCriteriaPayload = rptCriteriaPayload;
    }

    public String getRptCriteriaHeader() {
        return rptCriteriaHeader;
    }

    public void setRptCriteriaHeader(String rptCriteriaHeader) {
        this.rptCriteriaHeader = rptCriteriaHeader;
    }

    public String getOutputFormat() {
        return outputFormat;
    }

    public void setOutputFormat(String outputFormat) {
        this.outputFormat = outputFormat;
    }
}
