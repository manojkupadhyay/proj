package com.example.s3ontap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S3OntapServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(S3OntapServiceApplication.class, args);
	}

}
