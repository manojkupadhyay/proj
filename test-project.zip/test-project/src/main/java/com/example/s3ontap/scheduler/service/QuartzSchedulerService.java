package com.example.s3ontap.scheduler.service;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import com.example.s3ontap.scheduler.handler.JobExecutionOutcome;
import com.example.s3ontap.scheduler.handler.JobTaskHandler;
import com.example.s3ontap.scheduler.handler.JobTaskHandlerRegistry;
import com.example.s3ontap.scheduler.job.DynamicDatabaseJob;
import com.example.s3ontap.scheduler.mapper.ReportScheduleDetailMapper;
import com.example.s3ontap.scheduler.mapper.ReportScheduleRequestMapper;
import com.example.s3ontap.scheduler.mapper.ScheduleReportExecutionLogMapper;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class QuartzSchedulerService {

    private static final Logger log = LoggerFactory.getLogger(QuartzSchedulerService.class);

    private final Scheduler scheduler;
    private final ReportScheduleDetailMapper reportScheduleDetailMapper;
    private final ReportScheduleRequestMapper reportScheduleRequestMapper;
    private final ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper;
    private final JobTaskHandlerRegistry jobTaskHandlerRegistry;

    public QuartzSchedulerService(Scheduler scheduler, 
                                  ReportScheduleDetailMapper reportScheduleDetailMapper,
                                  ReportScheduleRequestMapper reportScheduleRequestMapper,
                                  ScheduleReportExecutionLogMapper scheduleReportExecutionLogMapper,
                                  JobTaskHandlerRegistry jobTaskHandlerRegistry) {
        this.scheduler = scheduler;
        this.reportScheduleDetailMapper = reportScheduleDetailMapper;
        this.reportScheduleRequestMapper = reportScheduleRequestMapper;
        this.scheduleReportExecutionLogMapper = scheduleReportExecutionLogMapper;
        this.jobTaskHandlerRegistry = jobTaskHandlerRegistry;
    }

    /**
     * Reads all active schedules from the REPORT_SCHEDULE_DETAIL table via MyBatis and registers them in Quartz.
     */
    @Transactional(readOnly = true)
    public int syncAllActiveSchedulesFromDb() {
        log.info("Reading active report schedules from DB via MyBatis to sync with Quartz...");
        List<ReportScheduleDetail> activeSchedules = reportScheduleDetailMapper.findAllActive();
        int count = 0;

        for (ReportScheduleDetail schedule : activeSchedules) {
            try {
                scheduleInQuartz(schedule);
                count++;
            } catch (Exception e) {
                log.error("Failed to schedule report job (scheduleId: {}) from DB into Quartz", 
                        schedule.getScheduleId(), e);
            }
        }

        log.info("Successfully synced {} active report jobs into Quartz Scheduler", count);
        return count;
    }

    /**
     * Persists report schedule and request details via MyBatis, then schedules in Quartz.
     */
    @Transactional
    public ReportScheduleDetail createAndSchedule(ReportScheduleDetail schedule, ReportScheduleRequest request) throws SchedulerException {
        reportScheduleDetailMapper.insert(schedule);

        if (request != null) {
            request.setScheduleId(schedule.getScheduleId());
            reportScheduleRequestMapper.insert(request);
            schedule.setRequest(request);
        }

        if ("ACTIVE".equalsIgnoreCase(schedule.getStatus())) {
            scheduleInQuartz(schedule);
        }

        return schedule;
    }

    /**
     * Updates schedule and request details in DB via MyBatis and reschedules in Quartz.
     */
    @Transactional
    public ReportScheduleDetail updateAndReschedule(Long scheduleId, ReportScheduleDetail updatedDetails, ReportScheduleRequest updatedRequest) throws SchedulerException {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        if (updatedDetails.getCronExpression() != null) {
            schedule.setCronExpression(updatedDetails.getCronExpression());
        }
        if (updatedDetails.getStatus() != null) {
            schedule.setStatus(updatedDetails.getStatus());
        }
        if (updatedDetails.getStartAt() != null) {
            schedule.setStartAt(updatedDetails.getStartAt());
        }
        if (updatedDetails.getExpiresAt() != null) {
            schedule.setExpiresAt(updatedDetails.getExpiresAt());
        }
        if (updatedDetails.getUpdatedBy() != null) {
            schedule.setUpdatedBy(updatedDetails.getUpdatedBy());
        }

        reportScheduleDetailMapper.update(schedule);

        if (updatedRequest != null) {
            ReportScheduleRequest req = reportScheduleRequestMapper.findByScheduleId(scheduleId);
            if (req == null) {
                updatedRequest.setScheduleId(scheduleId);
                reportScheduleRequestMapper.insert(updatedRequest);
                schedule.setRequest(updatedRequest);
            } else {
                if (updatedRequest.getReportName() != null) req.setReportName(updatedRequest.getReportName());
                if (updatedRequest.getReportType() != null) req.setReportType(updatedRequest.getReportType());
                if (updatedRequest.getOlbId() != null) req.setOlbId(updatedRequest.getOlbId());
                if (updatedRequest.getClientId() != null) req.setClientId(updatedRequest.getClientId());
                if (updatedRequest.getPageId() != null) req.setPageId(updatedRequest.getPageId());
                if (updatedRequest.getRptCriteriaPayload() != null) req.setRptCriteriaPayload(updatedRequest.getRptCriteriaPayload());
                if (updatedRequest.getRptCriteriaHeader() != null) req.setRptCriteriaHeader(updatedRequest.getRptCriteriaHeader());
                if (updatedRequest.getOutputFormat() != null) req.setOutputFormat(updatedRequest.getOutputFormat());
                if (updatedRequest.getStatus() != null) req.setStatus(updatedRequest.getStatus());
                if (updatedRequest.getFileStatus() != null) req.setFileStatus(updatedRequest.getFileStatus());
                if (updatedRequest.getUpdatedBy() != null) req.setUpdatedBy(updatedRequest.getUpdatedBy());
                reportScheduleRequestMapper.update(req);
                schedule.setRequest(req);
            }
        }

        if ("ACTIVE".equalsIgnoreCase(schedule.getStatus())) {
            scheduleInQuartz(schedule);
        } else if ("PAUSED".equalsIgnoreCase(schedule.getStatus())) {
            pauseJob(scheduleId);
        } else {
            // If INACTIVE, COMPLETED, or CANCELLED, unschedule the Quartz trigger so dormant jobs don't wake workers
            String fallbackGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                    ? schedule.getRequest().getReportType() 
                    : "REPORT_GROUP";
            JobKey jobKey = resolveJobKey(scheduleId, fallbackGroup);
            TriggerKey triggerKey = TriggerKey.triggerKey(jobKey.getName() + "_trigger", jobKey.getGroup());
            if (scheduler.checkExists(triggerKey)) {
                scheduler.unscheduleJob(triggerKey);
                log.info("Unscheduled Quartz trigger for scheduleId {} due to status '{}'", scheduleId, schedule.getStatus());
            }
        }

        return schedule;
    }

    /**
     * Registers or updates a job in the Quartz Scheduler engine using DB schedule details.
     */
    public void scheduleInQuartz(ReportScheduleDetail schedule) throws SchedulerException {
        // Edge Case: If schedule has an expiration date in the past, do not schedule in Quartz
        if (schedule.getExpiresAt() != null && schedule.getExpiresAt().isBefore(java.time.LocalDateTime.now())) {
            log.warn("Schedule #{} has already expired at {}. Marking status as EXPIRED.", 
                    schedule.getScheduleId(), schedule.getExpiresAt());
            reportScheduleDetailMapper.updateStatus(schedule.getScheduleId(), "EXPIRED");
            return;
        }

        // Clean & trim cron expression
        String cron = schedule.getCronExpression() != null ? schedule.getCronExpression().trim() : "";
        schedule.setCronExpression(cron);

        if (!CronExpression.isValidExpression(cron)) {
            throw new IllegalArgumentException("Invalid Cron expression: " + cron);
        }

        String jobName = "REPORT_JOB_" + schedule.getScheduleId();
        String jobGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                ? schedule.getRequest().getReportType() 
                : "REPORT_GROUP";

        JobKey jobKey = JobKey.jobKey(jobName, jobGroup);
        TriggerKey triggerKey = TriggerKey.triggerKey(jobName + "_trigger", jobGroup);

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("scheduleId", schedule.getScheduleId());
        jobDataMap.put("jobName", jobName);
        jobDataMap.put("jobGroup", jobGroup);

        JobDetail jobDetail = JobBuilder.newJob(DynamicDatabaseJob.class)
                .withIdentity(jobKey)
                .withDescription("Report Schedule #" + schedule.getScheduleId())
                .usingJobData(jobDataMap)
                .storeDurably()
                .requestRecovery(true)
                .build();

        TriggerBuilder<CronTrigger> triggerBuilder = TriggerBuilder.newTrigger()
                .withIdentity(triggerKey)
                .withDescription("Trigger for " + jobName)
                .withSchedule(CronScheduleBuilder.cronSchedule(cron)
                        .withMisfireHandlingInstructionFireAndProceed());

        if (schedule.getStartAt() != null) {
            triggerBuilder.startAt(Date.from(schedule.getStartAt().atZone(ZoneId.systemDefault()).toInstant()));
        }
        if (schedule.getExpiresAt() != null) {
            triggerBuilder.endAt(Date.from(schedule.getExpiresAt().atZone(ZoneId.systemDefault()).toInstant()));
        }

        CronTrigger trigger = triggerBuilder.build();

        if (scheduler.checkExists(jobKey)) {
            log.info("Job {} already exists in Quartz. Updating trigger and job...", jobKey);
            scheduler.addJob(jobDetail, true, true);
            if (scheduler.checkExists(triggerKey)) {
                scheduler.rescheduleJob(triggerKey, trigger);
            } else {
                scheduler.scheduleJob(trigger);
            }
        } else {
            scheduler.scheduleJob(jobDetail, trigger);
            log.info("Scheduled new report job {} with cron '{}'", jobKey, cron);
        }
    }

    /**
     * Resolves the JobKey across all job groups in case job group was updated or altered.
     */
    private JobKey resolveJobKey(Long scheduleId, String fallbackGroup) throws SchedulerException {
        String jobName = "REPORT_JOB_" + scheduleId;
        JobKey key = JobKey.jobKey(jobName, fallbackGroup != null ? fallbackGroup : "REPORT_GROUP");
        if (scheduler.checkExists(key)) {
            return key;
        }
        for (String group : scheduler.getJobGroupNames()) {
            JobKey candidate = JobKey.jobKey(jobName, group);
            if (scheduler.checkExists(candidate)) {
                return candidate;
            }
        }
        return key;
    }

    /**
     * Pauses the Quartz job and updates DB status to PAUSED via MyBatis.
     */
    @Transactional
    public void pauseJob(Long scheduleId) throws SchedulerException {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        String fallbackGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                ? schedule.getRequest().getReportType() 
                : "REPORT_GROUP";

        JobKey jobKey = resolveJobKey(scheduleId, fallbackGroup);
        if (scheduler.checkExists(jobKey)) {
            scheduler.pauseJob(jobKey);
            log.info("Paused Quartz job: {}", jobKey);
        }

        reportScheduleDetailMapper.updateStatus(scheduleId, "PAUSED");
    }

    /**
     * Resumes a paused Quartz job and updates DB status to ACTIVE via MyBatis.
     */
    @Transactional
    public void resumeJob(Long scheduleId) throws SchedulerException {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        String fallbackGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                ? schedule.getRequest().getReportType() 
                : "REPORT_GROUP";

        JobKey jobKey = resolveJobKey(scheduleId, fallbackGroup);
        if (scheduler.checkExists(jobKey)) {
            scheduler.resumeJob(jobKey);
            log.info("Resumed Quartz job: {}", jobKey);
        } else {
            scheduleInQuartz(schedule);
        }

        reportScheduleDetailMapper.updateStatus(scheduleId, "ACTIVE");
    }

    /**
     * Triggers the job immediately at runtime on-demand.
     */
    public void triggerJobNow(Long scheduleId) throws SchedulerException {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        String fallbackGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                ? schedule.getRequest().getReportType() 
                : "REPORT_GROUP";

        JobKey jobKey = resolveJobKey(scheduleId, fallbackGroup);

        if (!scheduler.checkExists(jobKey)) {
            scheduleInQuartz(schedule);
        }

        JobDataMap dataMap = new JobDataMap();
        dataMap.put("scheduleId", schedule.getScheduleId());
        dataMap.put("manualTrigger", true);

        scheduler.triggerJob(jobKey, dataMap);
        log.info("Triggered immediate execution for report job: {}", jobKey);
    }

    /**
     * Deletes job from Quartz and removes records from DB via MyBatis.
     */
    @Transactional
    public void deleteJob(Long scheduleId) throws SchedulerException {
        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        String fallbackGroup = (schedule.getRequest() != null && schedule.getRequest().getReportType() != null) 
                ? schedule.getRequest().getReportType() 
                : "REPORT_GROUP";

        JobKey jobKey = resolveJobKey(scheduleId, fallbackGroup);
        TriggerKey triggerKey = TriggerKey.triggerKey(jobKey.getName() + "_trigger", jobKey.getGroup());

        if (scheduler.checkExists(triggerKey)) {
            scheduler.unscheduleJob(triggerKey);
        }
        if (scheduler.checkExists(jobKey)) {
            scheduler.deleteJob(jobKey);
        }

        reportScheduleRequestMapper.deleteByScheduleId(scheduleId);
        reportScheduleDetailMapper.deleteById(scheduleId);
        log.info("Deleted job {} and removed from DB via MyBatis", jobKey);
    }

    /**
     * Replays missed job execution slices for a schedule across a historical downtime window.
     * Calculates every discrete cron occurrence between 'from' and 'to', executes each slice,
     * and logs every execution in SCHEDULE_REPORT_EXECUTION_LOG.
     *
     * @param scheduleId the schedule ID to backfill
     * @param from start of the downtime window
     * @param to end of the downtime window
     * @param customPayload optional custom criteria payload override
     * @return list of replayed slice execution reference IDs
     */
    public List<String> backfillSchedule(Long scheduleId, LocalDateTime from, LocalDateTime to, String customPayload) throws Exception {
        if (from == null || to == null) {
            throw new IllegalArgumentException("'from' and 'to' timestamps must not be null for backfill.");
        }
        if (from.isAfter(to)) {
            throw new IllegalArgumentException("'from' timestamp must be before 'to' timestamp.");
        }

        ReportScheduleDetail schedule = reportScheduleDetailMapper.findById(scheduleId);
        if (schedule == null) {
            throw new IllegalArgumentException("Schedule not found with id: " + scheduleId);
        }

        ReportScheduleRequest request = schedule.getRequest() != null 
                ? schedule.getRequest() 
                : reportScheduleRequestMapper.findByScheduleId(scheduleId);

        String cronExpr = schedule.getCronExpression() != null ? schedule.getCronExpression().trim() : "";
        if (!CronExpression.isValidExpression(cronExpr)) {
            throw new IllegalArgumentException("Invalid cron expression for schedule: " + cronExpr);
        }

        CronExpression cron = new CronExpression(cronExpr);
        Date current = Date.from(from.atZone(ZoneId.systemDefault()).toInstant());
        Date end = Date.from(to.atZone(ZoneId.systemDefault()).toInstant());

        List<Date> sliceTimes = new ArrayList<>();
        while (current != null && current.before(end)) {
            Date next = cron.getNextValidTimeAfter(current);
            if (next != null && !next.after(end)) {
                sliceTimes.add(next);
                current = next;
            } else {
                break;
            }
        }

        log.info("Backfilling schedule #{} across window [{} to {}]. Found {} missed slices to replay.", 
                scheduleId, from, to, sliceTimes.size());

        List<String> executedRefs = new ArrayList<>();
        String jobType = request != null && request.getReportType() != null ? request.getReportType() : "REPORT";
        JobTaskHandler handler = jobTaskHandlerRegistry.getHandler(jobType);

        for (Date sliceDate : sliceTimes) {
            LocalDateTime sliceTime = sliceDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            log.info("Replaying missed slice at {} for schedule #{}", sliceTime, scheduleId);

            ReportScheduleRequest sliceRequest = new ReportScheduleRequest();
            if (request != null) {
                sliceRequest.setRequestId(request.getRequestId());
                sliceRequest.setScheduleId(request.getScheduleId());
                sliceRequest.setReportName(request.getReportName());
                sliceRequest.setReportType(request.getReportType());
                sliceRequest.setOlbId(request.getOlbId());
                sliceRequest.setUserId(request.getUserId());
                sliceRequest.setClientId(request.getClientId());
                sliceRequest.setPageId(request.getPageId());
                sliceRequest.setOutputFormat(request.getOutputFormat());
                sliceRequest.setRptCriteriaHeader(request.getRptCriteriaHeader());
            }

            String payload = customPayload != null && !customPayload.isBlank() 
                    ? customPayload 
                    : (request != null && request.getRptCriteriaPayload() != null ? request.getRptCriteriaPayload() : "{}");
            sliceRequest.setRptCriteriaPayload(payload + " [slice: " + sliceTime + "]");

            ScheduleReportExecutionLog executionLog = new ScheduleReportExecutionLog(
                    scheduleId, 
                    "RPT_BF_" + scheduleId + "_" + sliceTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")), 
                    sliceTime
            );
            if (request != null) {
                executionLog.setReportType(request.getReportType());
                executionLog.setOlbId(request.getOlbId());
                executionLog.setUserId(request.getUserId());
                executionLog.setClientId(request.getClientId());
                executionLog.setPageId(request.getPageId());
            }

            try {
                JobExecutionOutcome outcome = handler.execute(schedule, sliceRequest);
                executionLog.setEndTime(sliceTime.plusSeconds(2));
                boolean outcomeSuccess = outcome != null && "SUCCESS".equalsIgnoreCase(outcome.getStatus());

                if (outcomeSuccess) {
                    executionLog.setStatus("SUCCESS");
                    executionLog.setGeneratedReportId(outcome.getExecutionReferenceId() + "_backfill");
                    executionLog.setRecordCount(outcome.getRecordCount());
                    executionLog.setStorageProvider(outcome.getStorageProvider());
                    executionLog.setS3Bucket(outcome.getS3Bucket());
                    executionLog.setS3ObjectKey(outcome.getS3ObjectKey());
                    executionLog.setFileName(outcome.getFileName());
                    executionLog.setFileFormat(outcome.getFileFormat());
                    executionLog.setFileSizeBytes(outcome.getFileSizeBytes());
                    executionLog.setFileStatus(outcome.getFileStatus() != null 
                            ? outcome.getFileStatus() 
                            : ("S3".equalsIgnoreCase(outcome.getStorageProvider()) ? "UPLOADED" : "NOT_APPLICABLE"));
                } else {
                    String failureStatus = outcome != null && outcome.getStatus() != null ? outcome.getStatus() : "FAILED";
                    executionLog.setStatus(failureStatus);
                    executionLog.setFileStatus(outcome != null && outcome.getFileStatus() != null ? outcome.getFileStatus() : "FAILED");
                    String errMsg = outcome != null && outcome.getErrorMessage() != null ? outcome.getErrorMessage() : "Backfill failure with status: " + failureStatus;
                    if (errMsg.length() > 3800) errMsg = errMsg.substring(0, 3800);
                    executionLog.setErrorMessage(errMsg);
                }
            } catch (Exception ex) {
                executionLog.setEndTime(sliceTime.plusSeconds(2));
                executionLog.setStatus("FAILED");
                executionLog.setFileStatus("FAILED");
                String rawMsg = "Backfill failure: " + (ex.getMessage() != null ? ex.getMessage() : ex.getClass().getName());
                if (rawMsg.length() > 3800) rawMsg = rawMsg.substring(0, 3800);
                executionLog.setErrorMessage(rawMsg);
            } finally {
                scheduleReportExecutionLogMapper.insert(executionLog);
                executedRefs.add(executionLog.getGeneratedReportId() != null 
                        ? executionLog.getGeneratedReportId() 
                        : executionLog.getReportId());
            }
        }

        // Update LAST_UPDATED_TS to 'to' timestamp
        reportScheduleDetailMapper.updateExecutionTimes(scheduleId, to, null);
        return executedRefs;
    }
}
