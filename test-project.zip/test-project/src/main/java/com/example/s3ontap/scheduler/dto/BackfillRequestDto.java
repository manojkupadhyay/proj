package com.example.s3ontap.scheduler.dto;

import java.time.LocalDateTime;

public class BackfillRequestDto {

    private LocalDateTime from;
    private LocalDateTime to;
    private String customPayload;

    public BackfillRequestDto() {
    }

    public BackfillRequestDto(LocalDateTime from, LocalDateTime to) {
        this.from = from;
        this.to = to;
    }

    public LocalDateTime getFrom() {
        return from;
    }

    public void setFrom(LocalDateTime from) {
        this.from = from;
    }

    public LocalDateTime getTo() {
        return to;
    }

    public void setTo(LocalDateTime to) {
        this.to = to;
    }

    public String getCustomPayload() {
        return customPayload;
    }

    public void setCustomPayload(String customPayload) {
        this.customPayload = customPayload;
    }
}
