package com.example.s3ontap.scheduler.mapper;

import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;

@Mapper
public interface ReportScheduleRequestMapper {

    @Insert("INSERT INTO REPORT_SCHEDULE_REQUEST (REPORT_NAME, REPORT_TYPE, OLB_ID, USER_ID, CLIENT_ID, PAGE_ID, " +
            "RPT_CRITERIA_PAYLOAD, RPT_CRITERIA_HEADER, OUTPUT_FORMAT, STATUS, FILE_STATUS, CREATED_AT, UPDATED_BY, CREATED_BY, " +
            "UPDATED_AT, PREVIOUS_REQUEST_ID, SCHEDULE_ID, PROCESSING_STATUS) " +
            "VALUES (#{reportName}, #{reportType}, #{olbId}, #{userId}, #{clientId}, #{pageId}, " +
            "#{rptCriteriaPayload}, #{rptCriteriaHeader}, #{outputFormat}, #{status}, #{fileStatus}, CURRENT_TIMESTAMP, #{updatedBy}, #{createdBy}, " +
            "CURRENT_TIMESTAMP, #{previousRequestId}, #{scheduleId}, #{processingStatus})")
    @Options(useGeneratedKeys = true, keyProperty = "requestId", keyColumn = "REQUEST_ID")
    int insert(ReportScheduleRequest request);

    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET REPORT_NAME = #{reportName}, REPORT_TYPE = #{reportType}, " +
            "OLB_ID = #{olbId}, USER_ID = #{userId}, CLIENT_ID = #{clientId}, PAGE_ID = #{pageId}, " +
            "RPT_CRITERIA_PAYLOAD = #{rptCriteriaPayload}, RPT_CRITERIA_HEADER = #{rptCriteriaHeader}, " +
            "OUTPUT_FORMAT = #{outputFormat}, STATUS = #{status}, FILE_STATUS = #{fileStatus}, UPDATED_BY = #{updatedBy}, " +
            "PROCESSING_STATUS = #{processingStatus}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int update(ReportScheduleRequest request);

    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET PROCESSING_STATUS = #{processingStatus}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int updateProcessingStatus(@Param("scheduleId") Long scheduleId, @Param("processingStatus") String processingStatus);

    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET FILE_STATUS = #{fileStatus}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int updateFileStatus(@Param("scheduleId") Long scheduleId, @Param("fileStatus") String fileStatus);

    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET STATUS = #{status}, FILE_STATUS = #{fileStatus}, UPDATED_AT = CURRENT_TIMESTAMP WHERE SCHEDULE_ID = #{scheduleId}")
    int updateStatusAndFileStatus(@Param("scheduleId") Long scheduleId, @Param("status") String status, @Param("fileStatus") String fileStatus);

    /**
     * Atomically claims execution lock on the request record.
     * Returns 1 if lock was successfully claimed by this instance, or 0 if another instance is already processing it.
     */
    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET PROCESSING_STATUS = 'PROCESSING', UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE SCHEDULE_ID = #{scheduleId} AND (PROCESSING_STATUS IS NULL OR PROCESSING_STATUS NOT IN ('PROCESSING'))")
    int claimExecutionLock(@Param("scheduleId") Long scheduleId);

    /**
     * Atomically claims execution lock on the request record with stale lease recovery.
     * If an instance crashed while processing and lock is older than staleThreshold, breaks stale lease and takes over.
     */
    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET PROCESSING_STATUS = 'PROCESSING', UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE SCHEDULE_ID = #{scheduleId} AND (" +
            "  PROCESSING_STATUS IS NULL " +
            "  OR PROCESSING_STATUS NOT IN ('PROCESSING') " +
            "  OR (PROCESSING_STATUS = 'PROCESSING' AND UPDATED_AT < #{staleThreshold})" +
            ")")
    int claimExecutionLockWithTimeout(@Param("scheduleId") Long scheduleId, @Param("staleThreshold") LocalDateTime staleThreshold);

    /**
     * Force-claims execution lock during Quartz failover recovery after a crashed node.
     */
    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET PROCESSING_STATUS = 'PROCESSING', UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE SCHEDULE_ID = #{scheduleId}")
    int forceClaimExecutionLock(@Param("scheduleId") Long scheduleId);

    /**
     * Releases execution lock with final completion status.
     */
    @Update("UPDATE REPORT_SCHEDULE_REQUEST SET PROCESSING_STATUS = #{status}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE SCHEDULE_ID = #{scheduleId}")
    int releaseExecutionLock(@Param("scheduleId") Long scheduleId, @Param("status") String status);

    @Select("SELECT * FROM REPORT_SCHEDULE_REQUEST WHERE SCHEDULE_ID = #{scheduleId}")
    @Results(id = "reportRequestResultMap", value = {
        @Result(property = "requestId", column = "REQUEST_ID", id = true),
        @Result(property = "reportName", column = "REPORT_NAME"),
        @Result(property = "reportType", column = "REPORT_TYPE"),
        @Result(property = "olbId", column = "OLB_ID"),
        @Result(property = "userId", column = "USER_ID"),
        @Result(property = "clientId", column = "CLIENT_ID"),
        @Result(property = "pageId", column = "PAGE_ID"),
        @Result(property = "rptCriteriaPayload", column = "RPT_CRITERIA_PAYLOAD"),
        @Result(property = "rptCriteriaHeader", column = "RPT_CRITERIA_HEADER"),
        @Result(property = "outputFormat", column = "OUTPUT_FORMAT"),
        @Result(property = "status", column = "STATUS"),
        @Result(property = "fileStatus", column = "FILE_STATUS"),
        @Result(property = "createdAt", column = "CREATED_AT"),
        @Result(property = "updatedBy", column = "UPDATED_BY"),
        @Result(property = "createdBy", column = "CREATED_BY"),
        @Result(property = "updatedAt", column = "UPDATED_AT"),
        @Result(property = "previousRequestId", column = "PREVIOUS_REQUEST_ID"),
        @Result(property = "scheduleId", column = "SCHEDULE_ID"),
        @Result(property = "processingStatus", column = "PROCESSING_STATUS")
    })
    ReportScheduleRequest findByScheduleId(Long scheduleId);

    @Delete("DELETE FROM REPORT_SCHEDULE_REQUEST WHERE SCHEDULE_ID = #{scheduleId}")
    int deleteByScheduleId(Long scheduleId);

    @Delete("DELETE FROM REPORT_SCHEDULE_REQUEST")
    int deleteAll();
}
