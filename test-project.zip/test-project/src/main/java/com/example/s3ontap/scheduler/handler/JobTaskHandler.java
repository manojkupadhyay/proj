package com.example.s3ontap.scheduler.handler;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;

/**
 * Strategy interface for executing any generic scheduled job.
 * Implementations are registered as Spring beans and automatically discovered.
 */
public interface JobTaskHandler {

    /**
     * Identifies if this handler supports the given job type (from REPORT_SCHEDULE_REQUEST.REPORT_TYPE).
     *
     * @param jobType the job type string (e.g. REPORT, HTTP, WEBHOOK, BEAN, DATA_SYNC)
     * @return true if this handler can execute this job type
     */
    boolean supports(String jobType);

    /**
     * Executes the job business logic.
     *
     * @param schedule the schedule metadata from REPORT_SCHEDULE_DETAIL
     * @param request the request criteria and payload from REPORT_SCHEDULE_REQUEST
     * @return execution outcome to be persisted in SCHEDULE_REPORT_EXECUTION_LOG
     * @throws Exception if job execution fails
     */
    JobExecutionOutcome execute(ReportScheduleDetail schedule, ReportScheduleRequest request) throws Exception;
}
