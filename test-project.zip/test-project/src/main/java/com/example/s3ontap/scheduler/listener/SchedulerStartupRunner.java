package com.example.s3ontap.scheduler.listener;

import com.example.s3ontap.scheduler.service.QuartzSchedulerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class SchedulerStartupRunner {

    private static final Logger log = LoggerFactory.getLogger(SchedulerStartupRunner.class);

    private final QuartzSchedulerService quartzSchedulerService;

    public SchedulerStartupRunner(QuartzSchedulerService quartzSchedulerService) {
        this.quartzSchedulerService = quartzSchedulerService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        log.info("Application started. Loading and scheduling dynamic jobs from Database into Quartz...");
        try {
            int scheduledCount = quartzSchedulerService.syncAllActiveSchedulesFromDb();
            log.info("Initialized {} jobs from DB on application startup", scheduledCount);
        } catch (Exception e) {
            log.error("Error initializing Quartz schedules from DB on startup", e);
        }
    }
}
