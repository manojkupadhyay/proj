package com.example.s3ontap.scheduler.job;

import com.example.s3ontap.scheduler.entity.ReportScheduleDetail;
import com.example.s3ontap.scheduler.entity.ReportScheduleRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Service
public class JobRequestDispatcher {

    private static final Logger log = LoggerFactory.getLogger(JobRequestDispatcher.class);

    public static class ReportExecutionResult {
        public String reportId;
        public String generatedReportId;
        public Long recordCount;
        public String storageProvider = "S3";
        public String s3Bucket = "reports-bucket";
        public String s3ObjectKey;
        public String fileName;
        public String fileFormat = "PDF";
        public Long fileSizeBytes = 0L;
        public String status = "SUCCESS";
        public String fileStatus = "UPLOADED";
        public String errorMessage;
    }

    public ReportExecutionResult dispatchReport(ReportScheduleDetail schedule, ReportScheduleRequest request) {
        String reportName = request != null && request.getReportName() != null ? request.getReportName() : "Report_" + schedule.getScheduleId();
        String reportType = request != null && request.getReportType() != null ? request.getReportType() : "STANDARD";
        String format = request != null && request.getOutputFormat() != null ? request.getOutputFormat().toUpperCase() : "PDF";

        log.info("Processing Report Job: scheduleId={}, reportName={}, type={}, format={}", 
                schedule.getScheduleId(), reportName, reportType, format);

        ReportExecutionResult result = new ReportExecutionResult();
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String reportUid = UUID.randomUUID().toString().substring(0, 8);

        result.reportId = "RPT_" + schedule.getScheduleId();
        result.generatedReportId = "GEN_" + reportUid;
        result.fileFormat = format;
        result.fileName = reportName.replaceAll("[^a-zA-Z0-9_-]", "_") + "_" + timestamp + "." + format.toLowerCase();
        result.s3ObjectKey = "scheduled-reports/" + reportType + "/" + result.fileName;
        result.storageProvider = "S3";
        result.s3Bucket = "reports-bucket";

        // Simulated record processing
        String criteria = request != null ? request.getRptCriteriaPayload() : "{}";
        log.info("Applying report criteria: {}", criteria);
        result.recordCount = 150L; // simulated records processed

        byte[] simulatedContent = ("Report: " + reportName + "\nCriteria: " + criteria).getBytes(StandardCharsets.UTF_8);
        result.fileSizeBytes = (long) simulatedContent.length;
        result.status = "SUCCESS";

        log.info("Report generated successfully: file={}, size={} bytes, s3Key={}", 
                result.fileName, result.fileSizeBytes, result.s3ObjectKey);
        return result;
    }
}
