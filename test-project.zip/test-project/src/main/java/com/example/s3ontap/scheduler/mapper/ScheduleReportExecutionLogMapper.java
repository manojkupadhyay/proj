package com.example.s3ontap.scheduler.mapper;

import com.example.s3ontap.scheduler.entity.ScheduleReportExecutionLog;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ScheduleReportExecutionLogMapper {

    @Insert("INSERT INTO SCHEDULE_REPORT_EXECUTION_LOG (SCHEDULE_ID, REPORT_ID, START_TIME, END_TIME, STATUS, FILE_STATUS, " +
            "GENERATED_REPORT_ID, RECORD_COUNT, STORAGE_PROVIDER, S3_BUCKET, S3_OBJECT_KEY, FILE_NAME, FILE_FORMAT, " +
            "FILE_SIZE_BYTES, REPORT_TYPE, OLB_ID, USER_ID, CLIENT_ID, PAGE_ID, RETRY_COUNT, ERROR_MESSAGE, CREATE_AT, UPDATED_AT) " +
            "VALUES (#{scheduleId}, #{reportId}, #{startTime}, #{endTime}, #{status}, #{fileStatus}, " +
            "#{generatedReportId}, #{recordCount}, #{storageProvider}, #{s3Bucket}, #{s3ObjectKey}, #{fileName}, #{fileFormat}, " +
            "#{fileSizeBytes}, #{reportType}, #{olbId}, #{userId}, #{clientId}, #{pageId}, #{retryCount}, #{errorMessage}, " +
            "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)")
    @Options(useGeneratedKeys = true, keyProperty = "executionId", keyColumn = "EXECUTION_ID")
    int insert(ScheduleReportExecutionLog log);

    @Update("UPDATE SCHEDULE_REPORT_EXECUTION_LOG SET STATUS = #{status}, FILE_STATUS = #{fileStatus}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE EXECUTION_ID = #{executionId}")
    int updateStatusAndFileStatus(@Param("executionId") Long executionId, @Param("status") String status, @Param("fileStatus") String fileStatus);

    @Update("UPDATE SCHEDULE_REPORT_EXECUTION_LOG SET STATUS = #{status}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE EXECUTION_ID = #{executionId}")
    int updateStatus(@Param("executionId") Long executionId, @Param("status") String status);

    @Update("UPDATE SCHEDULE_REPORT_EXECUTION_LOG SET FILE_STATUS = #{fileStatus}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE EXECUTION_ID = #{executionId}")
    int updateFileStatus(@Param("executionId") Long executionId, @Param("fileStatus") String fileStatus);

    @Update("UPDATE SCHEDULE_REPORT_EXECUTION_LOG SET " +
            "END_TIME = #{endTime}, STATUS = #{status}, FILE_STATUS = #{fileStatus}, " +
            "GENERATED_REPORT_ID = #{generatedReportId}, RECORD_COUNT = #{recordCount}, " +
            "STORAGE_PROVIDER = #{storageProvider}, S3_BUCKET = #{s3Bucket}, S3_OBJECT_KEY = #{s3ObjectKey}, " +
            "FILE_NAME = #{fileName}, FILE_FORMAT = #{fileFormat}, FILE_SIZE_BYTES = #{fileSizeBytes}, " +
            "ERROR_MESSAGE = #{errorMessage}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE EXECUTION_ID = #{executionId}")
    int updateExecutionOutcome(ScheduleReportExecutionLog log);

    @Select("SELECT * FROM SCHEDULE_REPORT_EXECUTION_LOG WHERE EXECUTION_ID = #{executionId}")
    @Results(id = "reportExecutionLogResultMap", value = {
        @Result(property = "executionId", column = "EXECUTION_ID", id = true),
        @Result(property = "scheduleId", column = "SCHEDULE_ID"),
        @Result(property = "reportId", column = "REPORT_ID"),
        @Result(property = "startTime", column = "START_TIME"),
        @Result(property = "endTime", column = "END_TIME"),
        @Result(property = "status", column = "STATUS"),
        @Result(property = "fileStatus", column = "FILE_STATUS"),
        @Result(property = "generatedReportId", column = "GENERATED_REPORT_ID"),
        @Result(property = "recordCount", column = "RECORD_COUNT"),
        @Result(property = "storageProvider", column = "STORAGE_PROVIDER"),
        @Result(property = "s3Bucket", column = "S3_BUCKET"),
        @Result(property = "s3ObjectKey", column = "S3_OBJECT_KEY"),
        @Result(property = "fileName", column = "FILE_NAME"),
        @Result(property = "fileFormat", column = "FILE_FORMAT"),
        @Result(property = "fileSizeBytes", column = "FILE_SIZE_BYTES"),
        @Result(property = "reportType", column = "REPORT_TYPE"),
        @Result(property = "olbId", column = "OLB_ID"),
        @Result(property = "userId", column = "USER_ID"),
        @Result(property = "clientId", column = "CLIENT_ID"),
        @Result(property = "pageId", column = "PAGE_ID"),
        @Result(property = "retryCount", column = "RETRY_COUNT"),
        @Result(property = "errorMessage", column = "ERROR_MESSAGE"),
        @Result(property = "createAt", column = "CREATE_AT"),
        @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    ScheduleReportExecutionLog findById(Long executionId);

    @Select("SELECT * FROM SCHEDULE_REPORT_EXECUTION_LOG WHERE SCHEDULE_ID = #{scheduleId} ORDER BY START_TIME DESC")
    @ResultMap("reportExecutionLogResultMap")
    List<ScheduleReportExecutionLog> findByScheduleId(Long scheduleId);

    @Select("<script>" +
            "SELECT * FROM SCHEDULE_REPORT_EXECUTION_LOG WHERE SCHEDULE_ID = #{scheduleId} " +
            "<if test='status != null and status != \"\"'> AND STATUS = #{status} </if>" +
            "<if test='fileStatus != null and fileStatus != \"\"'> AND FILE_STATUS = #{fileStatus} </if>" +
            "ORDER BY START_TIME DESC " +
            "<if test='limit != null and limit &gt; 0'> FETCH FIRST #{limit} ROWS ONLY </if>" +
            "</script>")
    @ResultMap("reportExecutionLogResultMap")
    List<ScheduleReportExecutionLog> findByScheduleIdWithFilters(
            @Param("scheduleId") Long scheduleId,
            @Param("status") String status,
            @Param("fileStatus") String fileStatus,
            @Param("limit") Integer limit);

    @Update("UPDATE SCHEDULE_REPORT_EXECUTION_LOG " +
            "SET STATUS = 'FAILED', FILE_STATUS = 'FAILED', END_TIME = CURRENT_TIMESTAMP, " +
            "ERROR_MESSAGE = #{errorMessage}, UPDATED_AT = CURRENT_TIMESTAMP " +
            "WHERE SCHEDULE_ID = #{scheduleId} AND END_TIME IS NULL AND START_TIME &lt; #{staleThreshold}")
    int markStaleExecutionsAsFailed(
            @Param("scheduleId") Long scheduleId,
            @Param("staleThreshold") java.time.LocalDateTime staleThreshold,
            @Param("errorMessage") String errorMessage);

    @Select("SELECT COUNT(*) FROM SCHEDULE_REPORT_EXECUTION_LOG")
    long countTotal();

    @Select("SELECT COUNT(*) FROM SCHEDULE_REPORT_EXECUTION_LOG WHERE STATUS = #{status}")
    long countByStatus(@Param("status") String status);

    @Select("SELECT * FROM SCHEDULE_REPORT_EXECUTION_LOG ORDER BY START_TIME DESC")
    @ResultMap("reportExecutionLogResultMap")
    List<ScheduleReportExecutionLog> findAll();

    @Delete("DELETE FROM SCHEDULE_REPORT_EXECUTION_LOG")
    int deleteAll();
}
